/* VEXO-GN - GameDistribution library.
   Loads GameDistribution's official game list in the browser, 100 games at a time.
   Every game is an official GameDistribution embed, so it plays inside VEXO-GN. */
(function () {
  'use strict';
  const { Store } = window.Vexo;
  const PER = 100;
  const FEED = (page, fmt) => 'https://catalog.api.gamedistribution.com/api/v2.0/rss/All/?collection=All&categories=All&tags=All&subType=All&type=All&mobile=All&rewarded=all'
    + '&amount=' + PER + '&page=' + page + '&format=' + (fmt || 'json');
  const CACHE = 'vexo_gd_cache', SAVED = 'vexo_gd_saved';
  const FEED_TTL = 12 * 3600e3, PASTE_TTL = 30 * 24 * 3600e3, MAX_KEEP = 1500;
  const state = { list: [], byId: new Map(), page: 0, loading: false, error: '', done: false, source: '' };

  const read = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };

  /* ---------- turning feed text into games ---------- */
  const CAT_WORDS = [['Racing', /rac|car\b|cars|drift|moto|bike|kart|driv|truck|parking/i], ['Sports', /sport|soccer|football|basket|golf|tennis|hockey|baseball|bowling|pool|billiard/i],
    ['Puzzle', /puzzle|match|logic|brain|word|mahjong|sudoku|quiz|merge|bejeweled|jigsaw|solitaire|card/i], ['Adventure', /adventure|rpg|escape|quest|explor/i],
    ['2 Player', /2 ?player|two ?player|\b2p\b/i], ['Multiplayer', /multiplayer|\.io\b|\bio\b/i],
    ['Action', /action|shoot|fight|war|battle|gun|zombie|sniper|stickman|platform/i], ['Arcade', /arcade|casual|clicker|hypercasual|runner|jump|idle/i]];
  function items(text) {
    text = String(text || '').trim();
    if (!text) return [];
    if (text[0] !== '<' && text[0] !== '[' && text[0] !== '{') {
      // copied from a browser JSON viewer: skip anything before the data
      const i = text.search(/[[{<]/); if (i < 0) return []; text = text.slice(i);
    }
    if (text[0] === '<') {
      const xml = new DOMParser().parseFromString(text, 'text/xml');
      return [...xml.querySelectorAll('item, game')].map((it) => {
        const o = {};
        [...it.children].forEach((c) => {
          const k = c.localName, v = c.getAttribute('url') || c.textContent;
          if (!(k in o)) o[k] = v; else o[k] = [].concat(o[k], v);
        });
        return o;
      });
    }
    let data;
    try { data = JSON.parse(text); } catch (e) { const j = text.lastIndexOf(text[0] === '[' ? ']' : '}'); data = JSON.parse(text.slice(0, j + 1)); }
    if (!Array.isArray(data)) data = data.items || data.games || data.data || data.result || (data.channel && data.channel.item) || Object.values(data);
    return Array.isArray(data) ? data : [];
  }
  const clean = (s) => String(s || '').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
  function toGame(it) {
    const pick = (...ks) => { for (const k of ks) { const v = it[k]; if (v != null && v !== '' && !(Array.isArray(v) && !v.length)) return v; } return ''; };
    const title = clean(pick('Title', 'title', 'name'));
    let md5 = String(pick('Md5', 'md5', 'gameMd5') || '').trim().toLowerCase();
    let url = String(pick('Url', 'url', 'link', 'Link') || '').trim();
    if (!md5) { const m = url.match(/gamedistribution\.com\/(?:[^/]+\/)?([0-9a-f]{32})/i); if (m) md5 = m[1].toLowerCase(); }
    if (!title || !/^[0-9a-f]{32}$/.test(md5)) return null;
    url = 'https://html5.gamedistribution.com/' + md5 + '/';
    let thumb = pick('Asset', 'asset', 'Assets', 'thumb', 'thumbnail', 'image');
    if (Array.isArray(thumb)) thumb = thumb.find((a) => /512x512/.test(a)) || thumb.find((a) => /512x384/.test(a)) || thumb[0];
    thumb = String(thumb || '').trim();
    if (!/^https:\/\//.test(thumb)) thumb = 'https://img.gamedistribution.com/' + md5 + '-512x512.jpeg';
    const catText = [].concat(pick('Category', 'category', 'categories')).concat(pick('Tag', 'tags', 'Tags')).join(' ');
    let cats = CAT_WORDS.filter(([, rx]) => rx.test(catText + ' ' + title)).map(([c]) => c).slice(0, 2);
    if (!cats.length) cats = ['Arcade'];
    const w = Number(pick('Width', 'width')), h = Number(pick('Height', 'height'));
    const r = w && h ? w / h : 16 / 9;
    const aspect = r > 1.6 ? '16:9' : r > 1.4 ? '3:2' : r > 1.15 ? '4:3' : r > 0.85 ? '1:1' : r > 0.65 ? '3:4' : '9:16';
    return {
      id: 'gd-' + md5, title: title.slice(0, 80), categories: cats, thumb, url, source: url, embed: true, aspect,
      description: clean(pick('Description', 'description')).slice(0, 220),
      controls: clean(pick('Instructions', 'instructions', 'controls')).slice(0, 180),
      author: 'GameDistribution', license: 'Official GameDistribution embed', library: true
    };
  }

  /* ---------- keeping the list ---------- */
  function add(games) {
    let n = 0;
    games.forEach((g) => { if (g && !state.byId.has(g.id)) { state.byId.set(g.id, g); state.list.push(g); n++; } });
    return n;
  }
  function saveCache() {
    const keep = state.list.slice(0, MAX_KEEP);
    if (!write(CACHE, { t: Date.now(), page: state.page, done: state.done, source: state.source, list: keep })) write(CACHE, { t: Date.now(), page: 0, source: state.source, list: keep.slice(0, 300) });
  }
  (function loadCache() {
    const c = read(CACHE, null);
    if (!c || !Array.isArray(c.list)) return;
    const ttl = c.source === 'paste' ? PASTE_TTL : FEED_TTL;
    if (Date.now() - (c.t || 0) > ttl) return;
    add(c.list); state.page = c.page || 0; state.done = !!c.done; state.source = c.source || 'feed';
  })();
  const emit = () => document.dispatchEvent(new CustomEvent('vexo:gd'));

  async function getText(url) {
    const r = await fetch(url, { credentials: 'omit' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  }
  async function loadMore() {
    if (state.loading || state.done) return;
    state.loading = true; state.error = ''; emit();
    const page = state.page + 1;
    try {
      let got = [];
      try { got = items(await getText(FEED(page, 'json'))).map(toGame).filter(Boolean); }
      catch (e) { got = items(await getText(FEED(page, 'xml'))).map(toGame).filter(Boolean); }
      const added = add(got);
      if (!got.length || !added) state.done = true;
      state.page = page; state.source = 'feed';
      saveCache();
    } catch (e) {
      state.error = 'blocked';
    }
    state.loading = false; emit();
  }
  function importText(text) {
    const got = items(text).map(toGame).filter(Boolean);
    const added = add(got);
    if (got.length) { state.source = 'paste'; state.error = ''; saveCache(); emit(); }
    return { found: got.length, added };
  }

  /* ---------- favorites / recently played keep working after a reload ---------- */
  const saved = read(SAVED, {});
  function remember(id) {
    const g = state.byId.get(id); if (!g) return;
    saved[id] = g;
    const ids = Object.keys(saved); if (ids.length > 300) delete saved[ids[0]];
    write(SAVED, saved);
  }
  const get = (id) => state.byId.get(id) || saved[id] || null;
  const baseGet = Store.get.bind(Store), basePush = Store.pushRecent.bind(Store), baseFav = Store.toggleFav.bind(Store);
  Store.get = (id) => baseGet(id) || (String(id).startsWith('gd-') ? get(id) : undefined);
  Store.pushRecent = (id) => { remember(id); return basePush(id); };
  Store.toggleFav = (id) => { remember(id); return baseFav(id); };

  window.VexoGD = { state, loadMore, importText, get, feedUrl: (p) => FEED(p || 1, 'json'), PER };
  // start loading as soon as the page is ready (skipped if a fresh copy is saved)
  const start = () => { if (!state.list.length || (state.source === 'feed' && state.page < 1)) loadMore(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else setTimeout(start, 0);
})();
