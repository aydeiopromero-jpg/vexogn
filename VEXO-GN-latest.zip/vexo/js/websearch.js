/* VEXO-GN - Vexo Search (#/web?q=...): search results shown right inside Vexo.
   - Quick answers: calculator, flip a coin, roll a die, random number, word meanings.
   - "Vexo AI says": a short answer from the free Vexo AI.
   - Games on VEXO-GN that match.
   - Web results and a fact box from Wikipedia (free, no key needed).
   - Buttons to open the same search on Google, Bing or DuckDuckGo in a new tab.
   Also: the clock and weather line on the home screen (weather from Open-Meteo, free, no key). */
(function () {
  'use strict';
  const { esc, Store, toast, search, thumbOf } = window.Vexo;
  let token = 0;

  /* ---------- small helpers ---------- */
  const text = (html) => { try { return new DOMParser().parseFromString(String(html || ''), 'text/html').body.textContent || ''; } catch (e) { return ''; } };
  function timeout(ms) { const c = new AbortController(); setTimeout(() => c.abort(), ms); return c.signal; }
  async function getJSON(url, ms = 12000) { const r = await fetch(url, { signal: timeout(ms) }); if (!r.ok) throw new Error('http ' + r.status); return r.json(); }
  const mark = (s, q) => {
    let out = esc(s);
    q.split(/\s+/).filter((w) => w.length > 2).slice(0, 5).map((w) => w.length > 4 ? w.replace(/s$/i, '') : w).forEach((w) => { out = out.replace(new RegExp('(' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi'), '<b>$1</b>'); });
    return out;
  };
  const SEARCH_IC = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>';
  const BOT = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/><circle cx="12" cy="3.5" r="1"/></svg>';
  const ENGINES = [
    { name: 'Google', url: 'https://www.google.com/search?q=' },
    { name: 'Bing', url: 'https://www.bing.com/search?q=' },
    { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=' },
    { name: 'YouTube', url: 'https://www.youtube.com/results?search_query=' }
  ];

  /* ---------- calculator (safe: reads the math itself, never runs code) ---------- */
  function calc(src) {
    let s = src.toLowerCase().replace(/^(what is|what's|whats|calculate|solve)\s+/, '').replace(/[=?]+\s*$/, '').replace(/×|x(?=\s*[\d(])/g, '*').replace(/÷/g, '/').replace(/,/g, '').trim();
    if (!/^[\d\s+\-*/().^%]+$/.test(s) || !/\d/.test(s) || !/[+\-*/^%]/.test(s.replace(/^-/, ''))) return null;
    let i = 0;
    const peek = () => { while (s[i] === ' ') i++; return s[i]; };
    function num() {
      const c = peek();
      if (c === '(') { i++; const v = add(); if (peek() !== ')') throw 0; i++; return v; }
      if (c === '-') { i++; return -pow(); }
      if (c === '+') { i++; return pow(); }
      const m = s.slice(i).match(/^\d*\.?\d+/); if (!m) throw 0; i += m[0].length;
      let v = parseFloat(m[0]);
      if (peek() === '%') { i++; v /= 100; }
      return v;
    }
    function pow() { const b = num(); if (peek() === '^') { i++; return Math.pow(b, pow()); } return b; }
    function mul() { let v = pow(); for (;;) { const c = peek(); if (c === '*') { i++; v *= pow(); } else if (c === '/') { i++; v /= pow(); } else return v; } }
    function add() { let v = mul(); for (;;) { const c = peek(); if (c === '+') { i++; v += mul(); } else if (c === '-') { i++; v -= mul(); } else return v; } }
    try { const v = add(); if (peek() !== undefined || !isFinite(v)) return null; return { expr: s, value: Math.round(v * 1e10) / 1e10 }; } catch (e) { return null; }
  }

  /* ---------- quick answers that need no internet ---------- */
  function instant(q) {
    const l = q.toLowerCase().trim();
    const c = calc(q);
    if (c) return `<div class="ws-card ws-calc"><small>${esc(c.expr)} =</small><b>${esc(c.value.toLocaleString(undefined, { maximumFractionDigits: 10 }))}</b></div>`;
    if (/^(flip a coin|coin flip|heads or tails)$/.test(l)) return `<div class="ws-card ws-calc"><small>Coin flip</small><b>${Math.random() < 0.5 ? 'Heads' : 'Tails'}</b><button type="button" class="mp-btn" data-ws-again>Flip again</button></div>`;
    if (/^(roll a (die|dice)|roll dice|dice roll)$/.test(l)) return `<div class="ws-card ws-calc"><small>You rolled</small><b>${1 + Math.floor(Math.random() * 6)}</b><button type="button" class="mp-btn" data-ws-again>Roll again</button></div>`;
    const rn = l.match(/^random number(?: (?:between|from) (-?\d+) (?:and|to) (-?\d+))?$/);
    if (rn) { const a = rn[1] ? +rn[1] : 1, b = rn[2] ? +rn[2] : 100, lo = Math.min(a, b), hi = Math.max(a, b); return `<div class="ws-card ws-calc"><small>Random number from ${lo} to ${hi}</small><b>${lo + Math.floor(Math.random() * (hi - lo + 1))}</b><button type="button" class="mp-btn" data-ws-again>Again</button></div>`; }
    if (/^(what time is it|time|current time|what's the time)$/.test(l)) return `<div class="ws-card ws-calc"><small>${esc(new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }))}</small><b>${esc(new Date().toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }))}</b></div>`;
    return '';
  }

  /* ---------- the page ---------- */
  function bar(q, big) {
    return `<form class="ws-bar${big ? ' is-big' : ''}" data-ws-form role="search">
      ${big ? '' : '<a class="ws-logo vx-logo" href="#/" aria-label="Vexo home">vexo</a>'}
      <label class="ws-input">${SEARCH_IC}<input id="wsInput" type="search" value="${esc(q)}" placeholder="Search the web" autocomplete="off" spellcheck="false" aria-label="Search the web"></label>
      <button type="submit" class="ws-go">Search</button>
    </form>`;
  }
  function page(q) {
    q = String(q || '').trim();
    if (!q) return `<div class="ws ws-empty"><h1 class="vx-logo ws-hero">vexo</h1><p class="ws-sub">Search the web</p>${bar('', true)}
      <div class="ws-tips">Try: <button type="button" data-ws-q="black holes">black holes</button><button type="button" data-ws-q="define curious">define curious</button><button type="button" data-ws-q="25*16+7">25*16+7</button><button type="button" data-ws-q="flip a coin">flip a coin</button><button type="button" data-ws-q="racing games">racing games</button></div></div>`;
    return `<div class="ws">${bar(q)}
      <div class="ws-body">
        <div class="ws-main">
          <div id="wsInstant">${instant(q)}</div>
          <div id="wsAi"></div>
          <div id="wsGames"></div>
          <div id="wsResults"><div class="ws-load"><i></i><i></i><i></i></div></div>
          <div class="ws-more"><span>More results for "${esc(q)}" on</span>${ENGINES.map((e) => `<a href="${esc(e.url + encodeURIComponent(q))}" target="_blank" rel="noopener">${esc(e.name)}</a>`).join('')}<small>These open in a new tab.</small></div>
        </div>
        <aside class="ws-side" id="wsSide"></aside>
      </div></div>`;
  }

  /* ---------- filling in the results ---------- */
  function gamesBox(q) {
    const res = search(q, Store.games()).slice(0, 6);
    if (!res.length) return '';
    return `<section class="ws-sec"><h2>Games on VEXO-GN</h2><div class="ws-games">${res.map((g) => `<a class="ws-game" href="#/play/${encodeURIComponent(g.id)}" data-open="${esc(g.id)}"><img src="${esc(thumbOf(g))}" alt="" loading="lazy" data-hide-err><span>${esc(g.title)}</span></a>`).join('')}</div></section>`;
  }
  async function wiki(q, my) {
    const box = document.getElementById('wsResults'); if (!box) return;
    try {
      const j = await getJSON('https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&origin=*&srlimit=10&srprop=snippet&srsearch=' + encodeURIComponent(q));
      if (my !== token) return;
      const list = (j.query && j.query.search) || [];
      if (!list.length) { box.innerHTML = `<p class="ws-none">No web results found for "<b>${esc(q)}</b>". Try other words, or use the buttons below.</p>`; return; }
      box.innerHTML = `<section class="ws-sec"><h2>Web results</h2>${list.map((r) => {
        const url = 'https://en.wikipedia.org/wiki/' + encodeURIComponent(r.title.replace(/ /g, '_'));
        return `<article class="ws-r"><a href="${esc(url)}" target="_blank" rel="noopener"><span class="ws-site"><img src="https://www.google.com/s2/favicons?domain=wikipedia.org&sz=32" alt="" data-hide-err>Wikipedia <small>en.wikipedia.org › wiki › ${esc(r.title)}</small></span><h3>${esc(r.title)}</h3></a><p>${mark(text(r.snippet), q)}...</p></article>`;
      }).join('')}</section>`;
      side(list[0].title, q, my);
    } catch (e) {
      if (my !== token) return;
      box.innerHTML = `<p class="ws-none">Couldn't load web results right now. The network might be blocking them. You can still use the buttons below.</p>`;
    }
  }
  async function side(title, q, my) {
    const el = document.getElementById('wsSide'); if (!el) return;
    try {
      const s = await getJSON('https://en.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(title.replace(/ /g, '_')));
      if (my !== token || !s || !s.extract || s.type === 'disambiguation') return;
      const url = (s.content_urls && s.content_urls.desktop && s.content_urls.desktop.page) || ('https://en.wikipedia.org/wiki/' + encodeURIComponent(title));
      el.insertAdjacentHTML('afterbegin', `<section class="ws-card ws-fact">${s.thumbnail ? `<img src="${esc(s.thumbnail.source)}" alt="" data-hide-err>` : ''}
        <h2>${esc(s.title)}</h2>${s.description ? `<small>${esc(s.description)}</small>` : ''}<p>${esc(s.extract)}</p>
        <a href="${esc(url)}" target="_blank" rel="noopener">Read more on Wikipedia</a></section>`);
    } catch (e) { /* the fact box is extra, so skip it */ }
  }
  async function define(q, my) {
    const m = q.trim().match(/^(?:define|meaning of|definition of|what does)\s+([a-z'-]+)(?:\s+mean)?\??$/i) || q.trim().match(/^([a-z'-]{3,})$/i);
    if (!m) return;
    try {
      const j = await getJSON('https://api.dictionaryapi.dev/api/v2/entries/en/' + encodeURIComponent(m[1].toLowerCase()));
      if (my !== token || !Array.isArray(j) || !j[0]) return;
      const w = j[0], ph = w.phonetic || ((w.phonetics || []).find((p) => p.text) || {}).text || '';
      const audio = ((w.phonetics || []).find((p) => p.audio) || {}).audio || '';
      const means = (w.meanings || []).slice(0, 3).map((mm) => `<div class="ws-mean"><i>${esc(mm.partOfSpeech || '')}</i><ol>${(mm.definitions || []).slice(0, 2).map((d) => `<li>${esc(d.definition)}${d.example ? `<em>"${esc(d.example)}"</em>` : ''}</li>`).join('')}</ol></div>`).join('');
      const el = document.getElementById('wsSide'); if (!el || !means) return;
      el.insertAdjacentHTML('afterbegin', `<section class="ws-card ws-dict"><h2>${esc(w.word)}${audio ? ` <button type="button" class="ws-say" data-ws-say="${esc(audio)}" aria-label="Hear it">&#128264;</button>` : ''}</h2>${ph ? `<small>${esc(ph)}</small>` : ''}${means}</section>`);
    } catch (e) { /* not a dictionary word */ }
  }
  async function ai(q, my) {
    const el = document.getElementById('wsAi');
    if (!el || !window.VexoAI || !window.VexoAI.answer || q.length < 3 || calc(q) || instant(q)) return;
    el.innerHTML = `<section class="ws-card ws-ai"><h2>${BOT}Vexo AI says</h2><div class="ai-typing"><i></i><i></i><i></i></div></section>`;
    try {
      const t = await window.VexoAI.answer(q);
      if (my !== token) return;
      el.innerHTML = `<section class="ws-card ws-ai"><h2>${BOT}Vexo AI says</h2><div class="ws-ai-t">${window.VexoAI.md(t)}</div>
        <button type="button" class="mp-btn" data-ws-chat="${esc(q)}">Keep chatting about this</button><small>AI can be wrong, so check important stuff.</small></section>`;
    } catch (e) { if (my === token) el.innerHTML = ''; }
  }
  function mounted(q) {
    q = String(q || '').trim();
    const my = ++token;
    const i = document.getElementById('wsInput');
    if (!q) { if (i && matchMedia('(pointer: fine)').matches) i.focus(); return; }
    saveRecent(q);
    document.dispatchEvent(new CustomEvent('vexo:search'));
    const g = document.getElementById('wsGames'); if (g) g.innerHTML = gamesBox(q);
    ai(q, my); wiki(q, my); define(q, my);
  }
  const saveRecent = (q) => { try { const k = 'vexo_searches', l = JSON.parse(localStorage.getItem(k) || '[]'); localStorage.setItem(k, JSON.stringify([q].concat((Array.isArray(l) ? l : []).filter((x) => typeof x === 'string' && x.toLowerCase() !== q.toLowerCase())).slice(0, 6))); } catch (e) {} };

  function go(q) {
    q = String(q || '').trim(); if (!q) return;
    const h = '#/web?q=' + encodeURIComponent(q);
    if (location.hash === h) { const w = document.querySelector('.ws'); if (w) { w.outerHTML = page(q); mounted(q); } }
    else location.hash = h;
  }
  document.addEventListener('submit', (e) => {
    if (!e.target.matches('[data-ws-form]')) return;
    e.preventDefault(); go(document.getElementById('wsInput').value);
  });
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-ws-q]'); if (t) { go(t.dataset.wsQ); return; }
    if (e.target.closest('[data-ws-again]')) { const el = document.getElementById('wsInput'); const box = document.getElementById('wsInstant'); if (el && box) box.innerHTML = instant(el.value); return; }
    const say = e.target.closest('[data-ws-say]'); if (say) { try { new Audio(say.dataset.wsSay).play(); } catch (x) {} return; }
    const ch = e.target.closest('[data-ws-chat]');
    if (ch && window.VexoAI) { const q = ch.dataset.wsChat; location.hash = '#/ai'; setTimeout(() => window.VexoAI.send(q), 60); }
  });

  /* ---------- clock and weather on the home screen ---------- */
  const W_KEY = 'vexo_weather';
  const wGet = () => { try { return JSON.parse(localStorage.getItem(W_KEY) || 'null'); } catch (e) { return null; } };
  const wPut = (v) => { try { v ? localStorage.setItem(W_KEY, JSON.stringify(v)) : localStorage.removeItem(W_KEY); } catch (e) {} };
  const useF = () => /^en-(US|LR)|^my/.test(navigator.language || 'en-US');
  const WCODE = (c) => c === 0 ? 'Clear' : c <= 2 ? 'Partly cloudy' : c === 3 ? 'Cloudy' : c <= 48 ? 'Foggy' : c <= 57 ? 'Drizzle' : c <= 67 ? 'Rain' : c <= 77 ? 'Snow' : c <= 82 ? 'Showers' : c <= 86 ? 'Snow showers' : 'Storms';
  function clock() {
    return `<div class="px-clock" id="pxClock"><span data-clock-t></span><span class="px-dot" aria-hidden="true">·</span><span data-clock-d></span><span class="px-dot" aria-hidden="true">·</span><button type="button" class="px-weather" data-weather>${weatherText()}</button></div>`;
  }
  function weatherText() {
    const w = wGet();
    if (!w || !w.name) return 'Add weather';
    if (w.temp == null) return esc(w.name);
    return `${Math.round(w.temp)}°${w.f ? 'F' : 'C'} ${esc(WCODE(w.code))}, ${esc(w.name)}`;
  }
  let clockTimer = 0;
  function tick() {
    const el = document.getElementById('pxClock'); if (!el) { clearInterval(clockTimer); clockTimer = 0; return; }
    const d = new Date();
    el.querySelector('[data-clock-t]').textContent = d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    el.querySelector('[data-clock-d]').textContent = d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  }
  async function refreshWeather(force) {
    const w = wGet(); if (!w || w.lat == null) return;
    const f = useF();
    if (!force && w.at && Date.now() - w.at < 30 * 60 * 1000 && w.f === f) return;
    try {
      const j = await getJSON(`https://api.open-meteo.com/v1/forecast?latitude=${w.lat}&longitude=${w.lon}&current=temperature_2m,weather_code${f ? '&temperature_unit=fahrenheit' : ''}`);
      if (!j.current) return;
      wPut(Object.assign(w, { temp: j.current.temperature_2m, code: j.current.weather_code, at: Date.now(), f }));
      const b = document.querySelector('[data-weather]'); if (b) b.innerHTML = weatherText();
    } catch (e) { /* keep the last weather */ }
  }
  function startClock() { tick(); if (!clockTimer) clockTimer = setInterval(tick, 10000); refreshWeather(false); }
  async function setCity() {
    const cur = wGet();
    const v = await window.Vexo.dialog({ title: 'Weather', ok: 'Save', text: 'Type your city to show its weather on the home screen. It\'s saved only on this device.', fields: [{ label: 'City', attrs: `placeholder="Chicago" value="${esc((cur && cur.name) || '')}" autocomplete="off"`, check: (x) => x.trim() ? '' : 'Type a city name' }] });
    if (!v) return;
    const name = v[0].trim();
    try {
      const j = await getJSON('https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=' + encodeURIComponent(name));
      const r = j.results && j.results[0];
      if (!r) { toast(`Couldn't find "${name}". Try a bigger city nearby.`); return; }
      wPut({ name: r.name, lat: r.latitude, lon: r.longitude });
      const b = document.querySelector('[data-weather]'); if (b) b.innerHTML = weatherText();
      refreshWeather(true);
    } catch (e) { toast("Couldn't load the weather right now. Try again later."); }
  }
  document.addEventListener('click', (e) => { if (e.target.closest('[data-weather]')) { e.preventDefault(); setCity(); } });

  window.VexoSearch = { page, mounted, go, clock, startClock, calc, instant };
})();
