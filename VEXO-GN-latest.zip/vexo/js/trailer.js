/* VEXO-GN - the Vexo Movies early release trailer.
   A full-screen hype trailer drawn live on a canvas, with its own beat made in the browser.
   Scenes: an old-school film countdown (3, 2, 1), "In a world..." opener, the beat drops, flying game cards,
   a music visualizer, a funny Vexo AI chat, joke reviews, warp speed, the big VEXO MOVIES title with a
   shockwave, a fast montage of the next big movies coming out (from the Movies page), and a post-credits joke.
   Music: real Lil Baby songs (clean versions, 30-second previews from Apple's free song search,
   with credit and a link to Apple Music), or the Vexo beat made right here. If the songs can't load,
   it plays the Vexo beat. No video file or copied footage. */
(function () {
  'use strict';
  const LEAD = 2.6;         // the 3-2-1 film countdown before everything else
  const BPM = 128, BEAT = 60 / BPM;
  const DROP1 = 8, BREAK = 27, DROP2 = 29.5;
  const MONT_A = DROP2 + 6 * BEAT;          // the movie montage starts on a beat after the title
  const MONT_B = MONT_A + 18 * BEAT;        // 9 movies, 2 beats each
  const DATE_A = MONT_B + 4 * BEAT;
  const END = DATE_A + 4;   // seconds (after the countdown) until the end card
  const STOP = END - 0.1;
  const BOOMS = [0.6, 3.9, DROP1, DROP2];
  let cur = null, starting = false, beatAmt = 1;

  /* ---------- trailer music: Lil Baby songs or the Vexo beat ---------- */
  const MODE_KEY = 'vexo_trailer_music';
  const getMode = () => { try { return localStorage.getItem(MODE_KEY) === 'beat' ? 'beat' : 'song'; } catch (e) { return 'song'; } };
  const setMode = (m) => { try { localStorage.setItem(MODE_KEY, m); } catch (e) {} };
  let songCache = null;
  function lilBaby() {
    if (songCache) return Promise.resolve(songCache);
    const M = window.VexoMusic; if (!M || !M.itunes) return Promise.reject(new Error('no music'));
    return M.itunes('lil baby', '&attribute=artistTerm&explicit=No').then((j) => {
      const seen = new Set();
      const list = ((j && j.results) || [])
        .filter((r) => /lil baby/i.test(r.artistName || '') && /^https:\/\//.test(r.previewUrl || '') && r.trackExplicitness !== 'explicit')
        .filter((r) => { const k = String(r.trackName || '').toLowerCase().replace(/\s*[([].*$/, ''); if (!k || seen.has(k)) return false; seen.add(k); return true; })
        .slice(0, 12)
        .map((r) => ({ title: String(r.trackName).slice(0, 80), artist: String(r.artistName).slice(0, 60), preview: r.previewUrl, link: /^https:\/\//.test(r.trackViewUrl || '') ? r.trackViewUrl : '' }));
      if (!list.length) throw new Error('none');
      songCache = list; return list;
    });
  }

  const relAt = (m) => { const [y, mo, d] = m.date.split('-').map(Number); return new Date(y, mo - 1, d).getTime(); };
  const inDays = (m) => { const d = Math.ceil((relAt(m) - Date.now()) / 86400000); return d <= 0 ? 'OUT NOW' : d === 1 ? 'TOMORROW' : 'IN ' + d + ' DAYS'; };
  const dateLine = () => 'NOW ON VEXO';
  const daysLeft = () => {
    const up = window.VexoMovies ? window.VexoMovies.upcoming() : []; const m = up[0];
    if (!m) return '';
    const d = Math.ceil((relAt(m) - Date.now()) / 86400000);
    return 'Next up: ' + m.title + (d <= 1 ? ' tomorrow' : ' in ' + d + ' days');
  };
  // how hard the beat is hitting right now (1 on the kick, fading to 0)
  const beatOn = (t) => (t >= DROP1 && t < BREAK) || (t >= DROP2 && t < STOP);
  const pulse = (t) => { if (!beatOn(t)) return 0; const s = t >= DROP2 ? DROP2 : DROP1; return beatAmt * Math.exp(-(((t - s) / BEAT) % 1) * 7); };

  /* ---------- the soundtrack ---------- */
  function soundtrack(withSongs) {
    const A = window.AudioContext || window.webkitAudioContext; if (!A) return null;
    let ac; try { ac = new A(); } catch (e) { return null; }
    const out = ac.createGain(); out.gain.value = 0.8; out.connect(ac.destination);
    const L0 = ac.currentTime + 0.05, T = L0 + LEAD;
    const noise = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate);
    const nd = noise.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
    const env = (g, at, peak, attack, decay) => { g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(peak, at + attack); g.gain.exponentialRampToValueAtTime(0.0001, at + attack + decay); };
    const noiseHit = (at, type, hz, peak, decay, q) => {
      const n = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
      n.buffer = noise; n.loop = true; f.type = type; f.frequency.value = hz; if (q) f.Q.value = q;
      env(g, at, peak, 0.002, decay); n.connect(f).connect(g).connect(out); n.start(at, Math.random()); n.stop(at + decay + 0.05);
    };
    function boom(at, big) {
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(big ? 100 : 80, at); o.frequency.exponentialRampToValueAtTime(26, at + (big ? 2 : 1.3));
      env(g, at, big ? 1 : 0.7, 0.01, big ? 2.6 : 1.6); o.connect(g).connect(out); o.start(at); o.stop(at + 3);
      noiseHit(at, 'lowpass', big ? 900 : 500, big ? 0.6 : 0.4, big ? 1.1 : 0.6);
      if (big) noiseHit(at, 'highpass', 5000, 0.12, 2.2);
    }
    function kick(at) { const o = ac.createOscillator(), g = ac.createGain(); o.frequency.setValueAtTime(160, at); o.frequency.exponentialRampToValueAtTime(42, at + 0.12); env(g, at, 0.9, 0.002, 0.28); o.connect(g).connect(out); o.start(at); o.stop(at + 0.35); }
    function snare(at) { noiseHit(at, 'bandpass', 1900, 0.38, 0.16, 0.8); const o = ac.createOscillator(), g = ac.createGain(); o.type = 'triangle'; o.frequency.value = 190; env(g, at, 0.25, 0.002, 0.08); o.connect(g).connect(out); o.start(at); o.stop(at + 0.12); }
    function hat(at, open) { noiseHit(at, 'highpass', 7500, open ? 0.1 : 0.07, open ? 0.12 : 0.035); }
    function bass(at, hz, len) {
      const o = ac.createOscillator(), f = ac.createBiquadFilter(), g = ac.createGain();
      o.type = 'sawtooth'; o.frequency.value = hz; f.type = 'lowpass'; f.frequency.setValueAtTime(900, at); f.frequency.exponentialRampToValueAtTime(180, at + len);
      env(g, at, 0.28, 0.005, len); o.connect(f).connect(g).connect(out); o.start(at); o.stop(at + len + 0.05);
    }
    function stab(at, notes) {
      const g = ac.createGain(), f = ac.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 2400;
      env(g, at, 0.07, 0.005, 0.22); f.connect(g).connect(out);
      notes.forEach((hz) => [0, 4].forEach((det) => { const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = hz; o.detune.value = det ? 9 : -9; o.connect(f); o.start(at); o.stop(at + 0.3); }));
    }
    function drone(a, b) {
      const f = ac.createBiquadFilter(), g = ac.createGain(); f.type = 'lowpass'; f.frequency.value = 240;
      g.gain.setValueAtTime(0.0001, T + a); g.gain.exponentialRampToValueAtTime(0.08, T + a + 2); g.gain.setValueAtTime(0.08, T + b - 0.4); g.gain.exponentialRampToValueAtTime(0.0001, T + b);
      [55, 55.4, 82.4].forEach((hz) => { const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = hz; o.connect(f); o.start(T + a); o.stop(T + b + 0.1); });
      f.connect(g).connect(out);
    }
    function riser(a, b) {
      const n = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
      n.buffer = noise; n.loop = true; f.type = 'bandpass'; f.Q.value = 3;
      f.frequency.setValueAtTime(250, T + a); f.frequency.exponentialRampToValueAtTime(6000, T + b);
      g.gain.setValueAtTime(0.0001, T + a); g.gain.exponentialRampToValueAtTime(0.4, T + b - 0.05); g.gain.linearRampToValueAtTime(0.0001, T + b);
      n.connect(f).connect(g).connect(out); n.start(T + a); n.stop(T + b + 0.05);
    }
    // the beat: four-on-the-floor kick, snare on 2 and 4, hats, a bass line and chord stabs
    const ROOTS = [55, 43.65, 65.41, 49]; // A, F, C, G
    const CHORDS = [[220, 261.6, 329.6], [174.6, 220, 261.6], [261.6, 329.6, 392], [196, 246.9, 293.7]];
    function groove(a, b, full) {
      for (let i = 0; T + a + i * BEAT < T + b - 0.01; i++) {
        const at = T + a + i * BEAT, bar = Math.floor(i / 4) % 4;
        kick(at);
        if (i % 4 === 1 || i % 4 === 3) snare(at);
        hat(at + BEAT / 2, i % 2 === 1);
        if (full) hat(at + BEAT / 4); if (full) hat(at + BEAT * 3 / 4);
        bass(at + BEAT / 2, ROOTS[bar], BEAT * 0.45);
        if (i % 4 === 0) stab(at, CHORDS[bar]); else if (full && i % 4 === 2) stab(at + BEAT / 2, CHORDS[bar]);
      }
    }
    // the film countdown: projector clatter, a beep on every number, and a pop
    for (let i = 0; i < LEAD * 18; i++) noiseHit(L0 + i / 18, 'highpass', 3000, 0.035, 0.012);
    [0, 0.8, 1.6].forEach((b) => { const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = 1000; env(g, L0 + b, 0.13, 0.004, 0.09); o.connect(g).connect(out); o.start(L0 + b); o.stop(L0 + b + 0.12); });
    noiseHit(L0 + 2.4, 'bandpass', 1200, 0.3, 0.05, 1);
    // a swish on every cut of the movie montage
    for (let i = 0; i < 9; i++) { const at = T + MONT_A + i * 2 * BEAT; noiseHit(at, 'bandpass', 2200, 0.16, 0.18, 1.2); }
    if (withSongs) {
      // the songs carry the music; keep the movie hits and the whoosh before the title on top
      out.gain.value = 0.6;
      boom(T + BOOMS[0], false); boom(T + BOOMS[1], false); boom(T + DROP1, true);
      riser(BREAK, DROP2); boom(T + DROP2, true);
      return { ac, out };
    }
    drone(0, DROP1);
    boom(T + BOOMS[0], false); boom(T + BOOMS[1], false);
    riser(6.4, DROP1);
    boom(T + DROP1, true); groove(DROP1, BREAK, false);
    drone(BREAK, DROP2); riser(BREAK, DROP2);
    boom(T + DROP2, true); groove(DROP2, STOP, true);
    boom(T + STOP, false);
    return { ac, out };
  }

  /* ---------- the picture ---------- */
  async function start() {
    if (cur || starting) return;
    starting = true;
    let songs = null;
    if (getMode() === 'song') {
      const ld = document.createElement('div');
      ld.className = 'tr tr-loading'; ld.innerHTML = '<p>Loading the trailer...</p>';
      document.body.appendChild(ld);
      try { songs = await Promise.race([lilBaby(), new Promise((res, rej) => setTimeout(() => rej(new Error('slow')), 6000))]); } catch (e) { songs = null; }
      ld.remove();
    }
    starting = false;
    begin(songs);
  }
  function begin(songs) {
    if (cur) return;
    beatAmt = songs ? 0.35 : 1;
    const el = document.createElement('div');
    el.className = 'tr'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Vexo Movies early release trailer');
    el.innerHTML = `<canvas aria-hidden="true"></canvas>
      <div class="tr-top"><span class="tr-tag">EARLY RELEASE TRAILER</span><span class="tr-btns"><button type="button" class="tr-btn" data-tr-music>Music: ${getMode() === 'song' ? 'Lil Baby' : 'Vexo beat'}</button><button type="button" class="tr-btn" data-tr-mute>Sound: on</button><button type="button" class="tr-btn" data-tr-skip>Skip</button><button type="button" class="tr-x" data-tr-close aria-label="Close trailer">&times;</button></span></div>
      <div class="tr-end" hidden><p class="tr-days"></p><div><button type="button" class="tr-cta" data-tr-movies>See the new movies</button><button type="button" class="tr-cta ghost" data-tr-replay>Watch again</button><button type="button" class="tr-cta ghost" data-tr-close>Close</button></div></div>
      <div class="tr-song" hidden><span class="tr-note" aria-hidden="true">&#9835;</span><span class="tr-song-t"><b></b><small></small></span><a target="_blank" rel="noopener">Apple Music</a><button type="button" class="tr-btn" data-tr-next>Next song</button></div>
      ${getMode() === 'song' && !songs ? '<div class="tr-warn">Couldn\'t load the Lil Baby songs here, so this is the Vexo beat.</div>' : ''}
      <div class="tr-prog"><i></i></div>`;
    document.body.appendChild(el);
    try { if (el.requestFullscreen && !document.fullscreenElement) el.requestFullscreen().catch(() => {}); } catch (e) {}
    const cv = el.querySelector('canvas'), ctx = cv.getContext('2d');
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    let W = 0, H = 0, dpr = 1;
    const size = () => { dpr = Math.min(2, window.devicePixelRatio || 1); W = el.clientWidth; H = el.clientHeight; cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px'; };
    size(); addEventListener('resize', size);
    const grain = document.createElement('canvas'); grain.width = grain.height = 160;
    const gx = grain.getContext('2d'), gd = gx.createImageData(160, 160);
    for (let i = 0; i < gd.data.length; i += 4) { const v = Math.random() * 255; gd.data[i] = gd.data[i + 1] = gd.data[i + 2] = v; gd.data[i + 3] = 255; }
    gx.putImageData(gd, 0, 0);
    const stars = Array.from({ length: 480 }, () => ({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() }));
    // real game pictures for the game montage
    const V = window.Vexo || {};
    const games = (V.Store ? V.Store.games() : []).slice().sort(() => Math.random() - 0.5).slice(0, 24).map((g) => {
      const img = new Image(); img.decoding = 'async'; img.referrerPolicy = 'no-referrer';
      try { img.src = g.thumb || (V.thumbOf ? V.thumbOf(g) : ''); } catch (e) {}
      return { title: g.title, img };
    });
    const gameCount = V.Store ? V.Store.games().length : 0;
    // the next big movies coming out, for the movie montage
    const movies = (window.VexoMovies ? window.VexoMovies.upcoming() : []).slice(0, 9);
    const movieCount = window.VexoMovies ? window.VexoMovies.list().length : 0;
    const sparks = Array.from({ length: 90 }, () => { const a = Math.random() * Math.PI * 2, v = 0.35 + Math.random() * 0.9; return { dx: Math.cos(a) * v, dy: Math.sin(a) * v, r: 0.8 + Math.random() * 2 }; });

    const state = { el, t0: performance.now(), last: performance.now(), raf: 0, audio: soundtrack(!!songs), muted: false, ended: false, onResize: size, songs, idx: 0, a1: null, a2: null };
    cur = state;
    if (state.audio && state.audio.ac.state === 'suspended') state.audio.ac.resume().catch(() => {});
    // songs: the first one plays until the music cuts out, the second one hits with the big title
    function playSong() {
      const S = state.songs, s = S[state.idx++ % S.length];
      const a = new Audio(s.preview); a.muted = state.muted; a.play().catch(() => {});
      const box = el.querySelector('.tr-song'); box.hidden = false;
      box.querySelector('b').textContent = s.title; box.querySelector('small').textContent = s.artist;
      const link = box.querySelector('a'); if (s.link) { link.href = s.link; link.hidden = false; } else link.hidden = true;
      return a;
    }
    state.nextSong = () => {
      if (!state.songs) return;
      const t = (performance.now() - state.t0) / 1000 - LEAD;
      if (state.a2) { state.a2.pause(); state.a2 = playSong(); }
      else if (state.a1 && t < BREAK) { state.a1.pause(); state.a1 = playSong(); }
    };
    function songTick(t) {
      if (!state.songs) return;
      if (!state.a1 && t >= 0 && t < BREAK) state.a1 = playSong();
      if (state.a1 && !state.a1.paused) { state.a1.volume = Math.max(0, Math.min(1, (BREAK - t) / 1.5)); if (t >= BREAK) state.a1.pause(); }
      if (!state.a2 && t >= DROP2) { if (state.a1) state.a1.pause(); state.a2 = playSong(); }
    }
    const speed = (t) => {
      if (t >= BREAK && t < DROP2) return 0.04 + Math.pow((t - BREAK) / (DROP2 - BREAK), 3) * 2.8;
      if (t >= DROP2 && t < DROP2 + 2) return 2.8 * Math.exp(-(t - DROP2) * 2.2) + 0.06;
      return beatOn(t) ? 0.1 + pulse(t) * 0.25 : 0.03;
    };

    /* drawing helpers */
    const SANS = 'Manrope, "Segoe UI", Arial, sans-serif', SCRIPT = '"Kaushan Script", "Brush Script MT", cursive';
    const ls = (px) => { try { ctx.letterSpacing = px; } catch (e) {} };
    const fade = (t, a, b, f = 0.35) => Math.max(0, Math.min(1, (t - a) / f, (b - t) / f));
    function text(s, t, a, b, o) {
      if (t < a || t > b) return;
      const p = (t - a) / (b - a), base = Math.min(W, H * 1.6);
      const px = Math.round(base * o.size);
      ctx.save();
      ctx.globalAlpha = fade(t, a, b, o.f || 0.35) * (o.dim ? 0.65 : 1);
      ctx.font = `${o.weight || 800} ${px}px ${o.font || SANS}`;
      ls((px * ((o.ls || 0.1) + (o.grow ? p * 0.08 : 0))).toFixed(1) + 'px');
      const w = ctx.measureText(s).width, fit = Math.min(1, (W * 0.88) / Math.max(1, w));
      ctx.translate(W / 2 + (o.dx || 0) * W, H / 2 + (o.dy || 0) * H);
      let sc = fit;
      if (!reduce) { sc *= o.pop ? 1 + 0.6 * Math.exp(-(t - a) * 10) : 1.06 - 0.06 * Math.min(1, p * 1.4); sc *= 1 + (o.beat ? pulse(t) * 0.05 : 0); }
      sc = Math.min(sc, (W * 0.95) / Math.max(1, w)); // never spill off the screen
      ctx.scale(sc, sc); if (o.rot) ctx.rotate(o.rot);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (o.glitch && !reduce && t - a < 0.35) glitch(s, px * 0.09 * (1 - (t - a) / 0.35));
      ctx.fillStyle = o.color || '#fff';
      ctx.fillText(s, 0, 0);
      ctx.restore();
    }
    // a quick red/blue split on the big hits
    function glitch(s, g) {
      const op = ctx.globalCompositeOperation; ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = 'rgba(255,40,80,0.75)'; ctx.fillText(s, -g, g * 0.3);
      ctx.fillStyle = 'rgba(40,210,255,0.75)'; ctx.fillText(s, g, -g * 0.3);
      ctx.globalCompositeOperation = op;
    }
    // a ring of light and sparks blasting out from the middle
    function shock(t, at, big) {
      const p = t - at; if (p < 0 || p > 1.6 || reduce) return;
      const cx = W / 2, cy = H / 2, m = Math.max(W, H);
      ctx.save();
      ctx.strokeStyle = `rgba(255,255,255,${0.7 * Math.exp(-p * 3)})`; ctx.lineWidth = big ? 4 : 2.5;
      ctx.beginPath(); ctx.arc(cx, cy, p * m * 0.9, 0, Math.PI * 2); ctx.stroke();
      if (big) { ctx.strokeStyle = `rgba(255,255,255,${0.35 * Math.exp(-p * 3)})`; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(cx, cy, p * m * 0.6, 0, Math.PI * 2); ctx.stroke(); }
      ctx.fillStyle = '#fff';
      for (const sp of sparks) {
        const d = (1 - Math.exp(-p * 2.5)) * m * 0.55;
        ctx.globalAlpha = Math.max(0, 1 - p / 1.4);
        ctx.beginPath(); ctx.arc(cx + sp.dx * d, cy + sp.dy * d, sp.r, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
    }
    // the 3, 2, 1 film countdown
    function leader(raw) {
      const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.3, fl = 0.85 + Math.random() * 0.15;
      if (raw >= 2.4) { ctx.fillStyle = raw < 2.46 ? '#fff' : '#000'; ctx.fillRect(0, 0, W, H); return; }
      const n = 3 - Math.floor(raw / 0.8), p = (raw % 0.8) / 0.8, c = Math.round(28 * fl);
      ctx.fillStyle = `rgb(${c},${c},${c})`; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(255,255,255,0.13)'; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, Math.max(W, H), -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(W, cy); ctx.moveTo(cx, 0); ctx.lineTo(cx, H); ctx.stroke();
      ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.stroke();
      ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, R * 0.84, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.font = `800 ${Math.round(R * 1.15)}px ${SANS}`; ls('0px'); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(n), cx, cy + R * 0.05);
      // scratches and dust
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      for (let i = 0; i < 3; i++) if (Math.random() < 0.5) ctx.fillRect(Math.random() * W, 0, 1, H);
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      for (let i = 0; i < 6; i++) { ctx.beginPath(); ctx.arc(Math.random() * W, Math.random() * H, 1 + Math.random() * 3, 0, Math.PI * 2); ctx.fill(); }
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function wrap(s, maxW) { const words = s.split(' '), lines = []; let line = ''; for (const w of words) { const tst = line ? line + ' ' + w : w; if (ctx.measureText(tst).width > maxW && line) { lines.push(line); line = w; } else line = tst; } if (line) lines.push(line); return lines; }
    function bubble(s, t, at, right, y, typing) {
      if (t < at) return;
      const k = reduce ? 1 : Math.min(1, (t - at) / 0.25), sc = 0.6 + 0.4 * (1 - Math.pow(1 - k, 3));
      const px = Math.round(Math.min(W * 0.035, 24) + 4);
      ctx.save(); ctx.font = `600 ${px}px ${SANS}`; ls('0px');
      const maxW = Math.min(W * 0.62, 520), lines = typing ? [''] : wrap(s, maxW - px * 1.6);
      const w = typing ? px * 3.6 : Math.max(...lines.map((l) => ctx.measureText(l).width)) + px * 1.6, h = lines.length * px * 1.35 + px * 1.1;
      const x = right ? W / 2 + Math.min(W * 0.3, 300) - w : W / 2 - Math.min(W * 0.3, 300);
      ctx.globalAlpha = k; ctx.translate(x + (right ? w : 0), y); ctx.scale(sc, sc); ctx.translate(-(right ? w : 0), 0);
      rr(0, 0, w, h, px * 0.9); ctx.fillStyle = right ? '#fff' : '#1b1b1b'; ctx.fill();
      if (!right) { ctx.strokeStyle = '#333'; ctx.lineWidth = 1; ctx.stroke(); }
      ctx.fillStyle = right ? '#000' : '#fff'; ctx.textBaseline = 'top';
      if (typing) { for (let i = 0; i < 3; i++) { ctx.globalAlpha = k * (0.35 + 0.65 * Math.max(0, Math.sin(t * 9 - i * 0.9))); ctx.beginPath(); ctx.arc(px * 1.0 + i * px * 0.8, h / 2, px * 0.2, 0, 7); ctx.fill(); } }
      else lines.forEach((l, i) => ctx.fillText(l, px * 0.8, px * 0.55 + i * px * 1.35));
      ctx.restore();
      return h;
    }
    function drawStars(t, dt) {
      const v = reduce ? Math.min(speed(t), 0.3) : speed(t), f = Math.min(W, H) * 0.6, cx = W / 2, cy = H / 2, intro = Math.min(1, t / 2.5);
      ctx.lineCap = 'round';
      for (const s of stars) {
        const z0 = s.z; s.z -= v * dt;
        if (s.z <= 0.02) { s.x = Math.random() * 2 - 1; s.y = Math.random() * 2 - 1; s.z = 1; continue; }
        const x1 = cx + (s.x / s.z) * f, y1 = cy + (s.y / s.z) * f;
        if (x1 < -50 || x1 > W + 50 || y1 < -50 || y1 > H + 50) { s.z = 1; s.x = Math.random() * 2 - 1; s.y = Math.random() * 2 - 1; continue; }
        const zb = Math.min(1, z0 + v * 0.02), x0 = cx + (s.x / zb) * f, y0 = cy + (s.y / zb) * f;
        ctx.strokeStyle = `rgba(255,255,255,${Math.min(1, (1 - s.z) * 1.3) * intro})`; ctx.lineWidth = Math.max(0.6, (1 - s.z) * 2.6);
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1 + 0.1, y1 + 0.1); ctx.stroke();
      }
    }

    /* the scenes */
    function sceneGames(t) { // 9 - 14: three rows of real game cards sliding past, and a game counter
      const a = 9, b = 14; if (t < a - 0.2 || t > b) return;
      const al = fade(t, a - 0.2, b, 0.3), cw = Math.max(150, Math.min(W * 0.2, 260)), ch = cw * 0.62, gap = cw * 0.12;
      ctx.save(); ctx.globalAlpha = al * 0.9; ctx.translate(W / 2, H / 2); ctx.rotate(reduce ? 0 : -0.12); ctx.translate(-W / 2, -H / 2);
      for (let row = 0; row < 3; row++) {
        const y = H / 2 + (row - 1) * (ch + gap) - ch / 2, dir = row % 2 ? 1 : -1, sp = (reduce ? 40 : 160 + row * 40) * (1 + pulse(t) * 0.4);
        const off = ((t - a) * sp * dir) % ((cw + gap) * 8);
        for (let i = -2; i < 12; i++) {
          const g = games[(row * 8 + ((i % 8) + 8) % 8) % Math.max(1, games.length)]; if (!g) continue;
          const x = i * (cw + gap) + off - (cw + gap) * 2 + (row === 1 ? cw / 2 : 0);
          ctx.save(); rr(x, y, cw, ch, 14); ctx.fillStyle = '#151515'; ctx.fill(); ctx.clip();
          if (g.img.complete && g.img.naturalWidth) ctx.drawImage(g.img, x, y, cw, ch);
          else { ctx.fillStyle = '#fff'; ctx.font = `800 ${Math.round(cw * 0.09)}px ${SANS}`; ls('0px'); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(g.title.slice(0, 18), x + cw / 2, y + ch / 2); }
          ctx.restore();
        }
      }
      ctx.restore();
      // dark band so the words read over the cards
      ctx.save(); ctx.globalAlpha = al * 0.78; ctx.fillStyle = '#000'; ctx.fillRect(0, H / 2 - H * 0.13, W, H * 0.26); ctx.restore();
      const n = Math.round(gameCount * Math.min(1, Math.max(0, (t - a) / 1.4)));
      text(n + ' GAMES', t, a, b, { size: 0.09, ls: 0.06, beat: true });
      text('NO DOWNLOADS. NO ACCOUNT. NO WAITING.', t, a + 1.6, b, { size: 0.022, ls: 0.4, dy: 0.085, dim: true });
    }
    function sceneMusic(t) { // 14 - 18: equalizer bars bouncing to the beat
      const a = 14, b = 18; if (t < a || t > b) return;
      const al = fade(t, a, b, 0.3), n = Math.max(16, Math.min(40, Math.floor(W / 30))), bw = W / n;
      ctx.save(); ctx.globalAlpha = al;
      for (let i = 0; i < n; i++) {
        const wob = 0.5 + 0.5 * Math.sin(t * 7 + i * 0.7) * Math.sin(t * 3.3 + i * 1.9);
        const h = H * (0.08 + 0.42 * wob * (0.45 + pulse(t) * 0.75) * (1 - Math.abs(i - n / 2) / n));
        ctx.fillStyle = `rgba(255,255,255,${0.25 + 0.55 * wob})`; rr(i * bw + bw * 0.18, H - h - H * 0.1, bw * 0.64, h, Math.min(6, bw * 0.3)); ctx.fill();
      }
      ctx.restore();
      text('MUSIC THAT ACTUALLY SLAPS', t, a, b, { size: 0.065, ls: 0.06, dy: -0.12, beat: true, pop: true });
      text('SPOTIFY  ·  YOUTUBE  ·  YOUR OWN PLAYLISTS', t, a + 0.8, b, { size: 0.02, ls: 0.4, dy: -0.04, dim: true });
    }
    function sceneAI(t) { // 18 - 23: a funny Vexo AI chat
      const a = 18, b = 23; if (t < a || t > b) return;
      ctx.save(); ctx.globalAlpha = fade(t, a, b, 0.3);
      const y0 = H * 0.3;
      bubble('can u just do my homework', t, a + 0.3, true, y0);
      if (t > a + 1.3 && t < a + 2.4) bubble('', t, a + 1.3, false, y0 + H * 0.13, true);
      if (t >= a + 2.4) bubble("Nice try. I'll help you actually get it though.", t, a + 2.4, false, y0 + H * 0.13);
      ctx.restore();
      text('VEXO AI', t, a + 3.4, b, { size: 0.06, ls: 0.3, dy: 0.25, pop: true, beat: true });
      text('SMARTER THAN YOUR GROUP CHAT', t, a + 3.7, b, { size: 0.02, ls: 0.4, dy: 0.32, dim: true });
    }
    function sceneReviews(t) { // 23 - 27: joke reviews pop in on the beat
      const a = 23, b = 27; if (t < a || t > b) return;
      const R = [
        ['"Better than recess."', '- a kid in 3rd period'],
        ['"I told my dog about it."', '- some guy named Kevin'],
        ['"Needs more snacks."', '- the cafeteria']
      ];
      R.forEach((r, i) => {
        const at = a + i * BEAT * 2.5, y = -0.22 + i * 0.22;
        text('★★★★★', t, at, b, { size: 0.03, ls: 0.3, dy: y - 0.065, pop: true, color: '#fff' });
        text(r[0], t, at, b, { size: 0.05, ls: 0.01, dy: y, pop: true, weight: 800 });
        text(r[1], t, at + 0.2, b, { size: 0.022, ls: 0.15, dy: y + 0.055, dim: true, weight: 600 });
      });
    }
    function sceneTitle(t, cx, cy) { // the big title, right after the drop
      if (t < DROP2 || t >= MONT_A) return;
      const p = t - DROP2, al = Math.min(1, (MONT_A - t) / 0.25);
      const slam = reduce ? 1 : (1 + 0.9 * Math.exp(-p * 9)) * (1 + pulse(t) * 0.035);
      const big = Math.round(Math.min(W * 0.26, H * 0.32));
      ctx.save(); ctx.globalAlpha = al; ctx.translate(cx, cy - big * 0.12); ctx.scale(slam, slam);
      ctx.font = `400 ${big}px ${SCRIPT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ls('0px');
      if (!reduce && p < 0.4) glitch('vexo', big * 0.05 * (1 - p / 0.4));
      ctx.fillStyle = '#fff'; ctx.fillText('vexo', 0, 0); ctx.restore();
      const st = Math.exp(-p * 1.6) * al;
      if (st > 0.02) { const g = ctx.createLinearGradient(0, 0, W, 0); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, `rgba(255,255,255,${0.75 * st})`); g.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = g; ctx.fillRect(0, cy - big * 0.12 - 1, W, 2); }
      if (t > DROP2 + 0.9) {
        const q = Math.min(1, (t - DROP2 - 0.9) / 1.2), e = 1 - Math.pow(1 - q, 3), px = Math.round(Math.min(W * 0.05, H * 0.06));
        ctx.save(); ctx.globalAlpha = al * e; ctx.font = `800 ${px}px ${SANS}`; ls((px * (0.2 + 0.6 * e)).toFixed(1) + 'px');
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff';
        ctx.fillText('MOVIES', cx + px * 0.3 * e, cy + big * 0.42); ctx.restore();
      }
    }
    function sceneMontage(t) { // the next movies coming out, one slam every 2 beats
      if (t < MONT_A || t >= MONT_B) return;
      if (!movies.length) { text('NEW MOVIES', t, MONT_A, MONT_B, { size: 0.1, ls: 0.1, pop: true, beat: true }); return; }
      const k = Math.floor((t - MONT_A) / (2 * BEAT)), m = movies[k % movies.length];
      const a = MONT_A + k * 2 * BEAT, b = a + 2 * BEAT, p = (t - a) / (b - a);
      const d = new Date(relAt(m));
      // a giant outlined day number behind, drifting toward you
      const big = Math.round(Math.min(W, H) * 0.62);
      ctx.save(); ctx.globalAlpha = 0.16 * Math.min(1, (t - a) / 0.08); ctx.translate(W / 2 + (k % 2 ? 1 : -1) * W * 0.18, H / 2);
      ctx.scale(1 + p * 0.12, 1 + p * 0.12); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
      ctx.font = `800 ${big}px ${SANS}`; ls('0px'); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.strokeText(String(d.getDate()), 0, 0); ctx.restore();
      // a light bar sliding under the title
      ctx.save(); const bw = W * 0.5 * Math.min(1, (t - a) / 0.25); ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.fillRect(W / 2 - bw / 2, H / 2 + H * 0.075, bw, 2); ctx.restore();
      const when = d.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase();
      text(when, t, a, b, { size: 0.022, ls: 0.45, dy: -0.09, f: 0.06, dim: true });
      text(m.title.toUpperCase(), t, a, b, { size: 0.062, ls: 0.04, f: 0.06, pop: true, glitch: true });
      text(inDays(m), t, a + 0.12, b, { size: 0.026, ls: 0.4, dy: 0.12, f: 0.06 });
    }
    function sceneEnd(t, cx, cy) {
      if (t < END - 0.4) return;
      const al = Math.min(1, (t - END + 0.4) / 0.8), big = Math.round(Math.min(W * 0.14, H * 0.18));
      ctx.save(); ctx.globalAlpha = al; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff';
      ctx.font = `400 ${big}px ${SCRIPT}`; ls('0px'); ctx.fillText('vexo', cx, cy - big * 0.75);
      const px = Math.round(big * 0.2); ctx.font = `800 ${px}px ${SANS}`; ls((px * 0.7).toFixed(1) + 'px');
      ctx.fillText('MOVIES', cx + px * 0.35, cy - big * 0.15); ctx.restore();
      // post-credits joke
      if (t > END + 4) {
        const k = Math.min(1, (t - END - 4) / 0.6), px2 = Math.round(Math.min(W * 0.032, 18));
        ctx.save(); ctx.globalAlpha = k * 0.7; ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.font = `600 ${px2}px ${SANS}`; ls('0px');
        ctx.fillText("...you're still here? Go play a game.", cx, H - H * 0.06 - px2); ctx.restore();
      }
    }

    function draw(now) {
      const raw = (now - state.t0) / 1000, t = raw - LEAD;
      songTick(t);
      const dt = Math.min(0.05, (now - state.last) / 1000); state.last = now;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (raw < LEAD) { leader(raw); el.querySelector('.tr-prog i').style.width = Math.min(100, (raw / (END + LEAD)) * 100) + '%'; state.raf = requestAnimationFrame(draw); return; }
      let sx = 0, sy = 0;
      if (!reduce) {
        for (const b of BOOMS) if (t > b && t < b + 1) { const k = Math.exp(-(t - b) * 7) * (b >= DROP1 ? 14 : 6); sx += (Math.random() - 0.5) * k; sy += (Math.random() - 0.5) * k; }
        const pk = pulse(t) * 3; sx += (Math.random() - 0.5) * pk; sy += (Math.random() - 0.5) * pk;
      }
      const cx = W / 2, cy = H / 2;
      ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.translate(sx, sy);
      drawStars(t, dt);
      text('IN A WORLD...', t, 0.6, 3.6, { size: 0.055, ls: 0.4, grow: true });
      text('WHERE 3RD PERIOD NEVER ENDS...', t, 3.9, 6.4, { size: 0.055, ls: 0.12, grow: true });
      text('ONE WEBSITE SAID:', t, 6.6, 7.95, { size: 0.045, ls: 0.3, grow: true, dim: true });
      shock(t, DROP1, false);
      text("LET'S GO.", t, DROP1, 9, { size: 0.13, ls: 0.04, pop: true, glitch: true });
      sceneGames(t); sceneMusic(t); sceneAI(t); sceneReviews(t);
      text('BUT THIS NOVEMBER...', t, BREAK + 0.2, DROP2 - 0.1, { size: 0.05, ls: 0.4, grow: true });
      shock(t, DROP2, true);
      sceneTitle(t, cx, cy);
      sceneMontage(t);
      text((movieCount ? movieCount + ' NEW MOVIES.' : 'NEW MOVIES.') + ' ONE PLACE.', t, MONT_B, DATE_A, { size: 0.07, ls: 0.08, pop: true, beat: true, f: 0.1 });
      text(dateLine(), t, DATE_A, END - 0.4, { size: 0.05, ls: 0.3, pop: true, beat: true, glitch: true });
      text('COUNTDOWNS  ·  TRAILERS  ·  RELEASE DATES', t, DATE_A + 0.4, END - 0.4, { size: 0.022, ls: 0.45, dy: 0.08, dim: true });
      sceneEnd(t, cx, cy);
      ctx.restore();
      // flashes on the big hits and a little one on every kick
      let fl = 0;
      for (const b of [DROP1, DROP2]) if (t > b && t < b + 1.2) fl = Math.max(fl, Math.exp(-(t - b) * 6) * 0.9);
      fl = Math.max(fl, pulse(t) * 0.06);
      if (t >= MONT_A && t < MONT_B) fl = Math.max(fl, Math.exp(-(((t - MONT_A) % (2 * BEAT))) * 22) * 0.35); // flash on each cut
      if (reduce) fl *= 0.3;
      if (fl > 0.005) { ctx.fillStyle = `rgba(255,255,255,${fl})`; ctx.fillRect(0, 0, W, H); }
      // film grain, vignette and movie bars
      ctx.save(); ctx.globalAlpha = 0.07; ctx.globalCompositeOperation = 'overlay';
      const ox = Math.random() * 160, oy = Math.random() * 160;
      ctx.translate(-ox, -oy); ctx.fillStyle = ctx.createPattern(grain, 'repeat'); ctx.fillRect(0, 0, W + 160, H + 160); ctx.restore();
      const vg = ctx.createRadialGradient(cx, cy, Math.min(W, H) * 0.3, cx, cy, Math.max(W, H) * 0.75);
      vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.65)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
      const bar = H * 0.08 * Math.min(1, t / 1.2); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, bar); ctx.fillRect(0, H - bar, W, bar);
      el.querySelector('.tr-prog i').style.width = Math.min(100, (raw / (END + LEAD)) * 100) + '%';
      if (t >= END && !state.ended) finish();
      state.raf = requestAnimationFrame(draw);
    }
    function finish() {
      state.ended = true;
      el.querySelector('.tr-end').hidden = false;
      el.querySelector('.tr-days').textContent = daysLeft();
      el.querySelector('[data-tr-skip]').hidden = true;
      const b = el.querySelector('[data-tr-movies]'); if (b) b.focus();
    }
    state.skip = () => { if (state.ended) return; if (state.audio) try { state.audio.out.gain.value = 0; } catch (e) {} if (state.a1) state.a1.pause(); state.t0 = performance.now() - (END + LEAD) * 1000; };
    state.raf = requestAnimationFrame(draw);
    el.querySelector('[data-tr-close]').focus();
  }
  function stop() {
    if (!cur) return;
    cancelAnimationFrame(cur.raf); removeEventListener('resize', cur.onResize);
    if (cur.audio) try { cur.audio.ac.close(); } catch (e) {}
    [cur.a1, cur.a2].forEach((a) => { if (a) try { a.pause(); a.src = ''; } catch (e) {} });
    try { if (document.fullscreenElement === cur.el) document.exitFullscreen().catch(() => {}); } catch (e) {}
    cur.el.remove(); cur = null;
  }
  async function replay() { const m = cur && cur.muted; stop(); await start(); if (m) mute(); }
  function mute() {
    if (!cur) return;
    cur.muted = !cur.muted;
    if (cur.audio) cur.audio.out.gain.value = cur.muted ? 0 : (cur.songs ? 0.6 : 0.8);
    [cur.a1, cur.a2].forEach((a) => { if (a) a.muted = cur.muted; });
    const b = cur.el.querySelector('[data-tr-mute]'); if (b) b.textContent = cur.muted ? 'Sound: off' : 'Sound: on';
  }
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-trailer]')) { e.preventDefault(); const d = e.target.closest('.vx-dialog'); const x = d && d.querySelector('[data-x-close]'); if (x) x.click(); start(); return; }
    if (!cur) return;
    if (e.target.closest('[data-tr-close]')) stop();
    else if (e.target.closest('[data-tr-replay]')) replay();
    else if (e.target.closest('[data-tr-mute]')) mute();
    else if (e.target.closest('[data-tr-skip]')) cur.skip();
    else if (e.target.closest('[data-tr-next]')) cur.nextSong();
    else if (e.target.closest('[data-tr-movies]')) { stop(); if (window.VexoHub) location.hash = '#/movies'; else location.href = 'index.html#/movies'; }
    else if (e.target.closest('[data-tr-music]')) { setMode(getMode() === 'song' ? 'beat' : 'song'); replay(); }
  });
  document.addEventListener('keydown', (e) => {
    if (!cur) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); stop(); }
    else if (e.key === 'm' || e.key === 'M') mute();
  }, true);

  window.VexoTrailer = { play: start, stop, playing: () => !!cur };
})();
