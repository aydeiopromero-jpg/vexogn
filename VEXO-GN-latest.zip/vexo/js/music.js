/* VEXO-GN - Music page (#/music).
   - Browse: Spotify's official playlists, your picks and your playlists, shown as cover tiles
   - Search: search Spotify, then "Paste & play" the link you copy
   - Your Library: everything you saved, plus songs from your own device
   - Playlists: make your own collections of Spotify links
   Music plays in a bar at the bottom of the screen and keeps going while you browse and play games.
   Songs play through Spotify's official player (full songs when logged in to Spotify, otherwise 30-second previews). */
(function () {
  'use strict';
  const { toast, esc } = window.Vexo;
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} } };

  const FEATURED = [
    { name: 'Top 50 Global', type: 'playlist', id: '37i9dQZEVXbMDoHDwVN2tF' },
    { name: 'Best Hits of 2025', type: 'playlist', id: '37i9dQZF1DWVmX5LMTOKPw' },
    { name: 'RapCaviar', type: 'playlist', id: '37i9dQZF1DX0XUsuxWHRQd' },
    { name: 'Best Hip-Hop of 2025', type: 'playlist', id: '37i9dQZF1DWZFV9Asvj1J9' },
    { name: 'Gaming Music', type: 'playlist', id: '4KJGeJqskaIHlCyrbF0aC5' },
    { name: 'Gaming Phonk', type: 'playlist', id: '0I3oQjjRFzEoO0llQRlCVg' },
    { name: 'Lofi Driving', type: 'playlist', id: '1Wh4WBSFFYFIpwkHjGU7NK' },
    { name: 'Songs to Sing in the Car', type: 'playlist', id: '6xpEjLdywtCpq0VOBx6KDs' }
  ];
  // real music from YouTube's official player: full songs, no login needed
  const YOUTUBE = [
    { name: 'Top 100 Songs Global', type: 'ytlist', id: 'PL4fGSI1pDJn6puJdseH2Rt9sMvt9E2M4i' },
    { name: 'Top 50 This Week', type: 'ytlist', id: 'PLx0sYbCqOb8TBPRdmBHs5Iftvv9TPboYG' },
    { name: 'Hip Hop Hits 2025', type: 'ytlist', id: 'RDCLAK5uy_nAqgfuOLNPvq_GGTGCe2b9PbpH7VxysI8' },
    { name: 'Rap Music 2025', type: 'ytlist', id: 'PLxA687tYuMWjuNRTGvDuLQZjHaLQv3wYL' },
    { name: 'Top Rap Hits', type: 'ytlist', id: 'PL9tY0BWXOZFv-V7FvZP-PWuE-1x2Deqqe' },
    { name: 'Phonk Music', type: 'ytlist', id: 'PLeZo-g7MgUlFrrsJ5rZvz5cgwXka6y1kV' },
    { name: 'Aggressive Gaming Phonk', type: 'ytlist', id: 'PLrTbvtYj2rVtMjBEIS3P8my60lm9XyUv1' },
    { name: 'Lofi Hip Hop Radio (24/7)', type: 'ytvideo', id: 'uWzSqdcfPZw' }
  ];
  const KIND = { playlist: 'Playlist', album: 'Album', track: 'Song', artist: 'Artist', show: 'Podcast', episode: 'Episode', ytlist: 'YouTube playlist', ytvideo: 'YouTube' };
  const isYT = (it) => it.type === 'ytlist' || it.type === 'ytvideo';
  const YT_LINK = /(?:youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/)|youtu\.be\/)([A-Za-z0-9_-]{11})|youtube\.com\/(?:playlist|watch)\?(?:.*&)?list=([A-Za-z0-9_-]{12,64})/;
  const SP_LINK = /open\.spotify\.com\/(?:intl-[a-z]{2}\/)?(?:embed\/)?(playlist|album|track|artist|show|episode)\/([A-Za-z0-9]{10,40})/;
  const valid = (x) => x && KIND[x.type] && (isYT(x) ? /^[A-Za-z0-9_-]{11,64}$/ : /^[A-Za-z0-9]{10,40}$/).test(x.id);
  const library = () => { const v = LS.get('vexo_spotify', []); return Array.isArray(v) ? v.filter(valid) : []; };
  const saveLibrary = (l) => LS.set('vexo_spotify', l.slice(0, 60));
  const playlists = () => { const v = LS.get('vexo_playlists', []); return Array.isArray(v) ? v.filter((p) => p && p.id && Array.isArray(p.items)) : []; };
  const savePlaylists = (l) => LS.set('vexo_playlists', l.slice(0, 30));
  const spPage = (it) => it.type === 'ytlist' ? `https://www.youtube.com/playlist?list=${encodeURIComponent(it.id)}` : it.type === 'ytvideo' ? `https://www.youtube.com/watch?v=${encodeURIComponent(it.id)}` : `https://open.spotify.com/${it.type}/${encodeURIComponent(it.id)}`;
  const spEmbed = (it) => it.type === 'ytlist' ? `https://www.youtube.com/embed/videoseries?list=${encodeURIComponent(it.id)}&autoplay=1` : it.type === 'ytvideo' ? `https://www.youtube.com/embed/${encodeURIComponent(it.id)}?autoplay=1` : `https://open.spotify.com/embed/${it.type}/${encodeURIComponent(it.id)}?utm_source=generator&theme=0`;

  /* ---------- cover pictures and names, from Spotify's official oEmbed (saved so they load fast next time) ---------- */
  const META = LS.get('vexo_sp_meta', {}) || {};
  const asking = new Set();
  const title = (it) => (META[it.id] && META[it.id].title) || it.name || KIND[it.type];
  // cover pictures come from YouTube's and Spotify's official oEmbed; noembed.com is a backup that serves the same official info
  function fetchMeta(it) {
    if ((META[it.id] && META[it.id].thumb) || asking.has(it.id) || !/^(https?|file):$/.test(location.protocol)) return;
    asking.add(it.id);
    const page = spPage(it);
    const sources = [(isYT(it) ? 'https://www.youtube.com/oembed?format=json&url=' : 'https://open.spotify.com/oembed?url=') + encodeURIComponent(page), 'https://noembed.com/embed?url=' + encodeURIComponent(page)];
    const tryNext = (i) => {
      if (i >= sources.length) { asking.delete(it.id); return; }
      fetch(sources[i]).then((r) => (r.ok ? r.json() : null)).then((j) => {
        if (!j || j.error || !/^https:\/\//.test(j.thumbnail_url || '')) return tryNext(i + 1);
        META[it.id] = { title: String(j.title || '').slice(0, 80), thumb: j.thumbnail_url };
        LS.set('vexo_sp_meta', META); asking.delete(it.id);
        document.querySelectorAll(`[data-meta="${it.id}"]`).forEach((el) => {
          const img = el.querySelector('img.mp-cover'); if (img) { img.src = META[it.id].thumb; img.hidden = false; }
          const t = el.querySelector('.mp-t'); if (t && !el.dataset.keepName) t.textContent = title(it);
        });
        document.querySelectorAll(`[data-cover-of="${it.id}"]`).forEach((img) => { img.src = META[it.id].thumb; img.hidden = false; });
      }).catch(() => tryNext(i + 1));
    };
    tryNext(0);
  }

  /* ---------- the music bar at the bottom of the screen ---------- */
  const NOTE = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg>';
  const X = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  const bar = document.createElement('div');
  bar.className = 'mp-bar'; bar.hidden = true; bar.setAttribute('role', 'region'); bar.setAttribute('aria-label', 'Now playing');
  let nowPlaying = null;
  function markMusic() { const on = !!nowPlaying || !audio.paused || (typeof preview !== 'undefined' && !preview.paused); document.querySelectorAll('[data-music]').forEach((a) => a.classList.toggle('mu-on', on)); }
  function play(it) {
    if (!valid(it)) return;
    audio.pause(); if (typeof preview !== 'undefined') { preview.pause(); pvIdx = -1; }
    nowPlaying = it; bar.hidden = false; document.body.classList.add('mp-playing');
    document.dispatchEvent(new CustomEvent('vexo:music'));
    const yt = isYT(it);
    bar.classList.toggle('yt', yt);
    bar.innerHTML = `<iframe class="mp-frame${yt ? ' mp-yt' : ''}" title="${yt ? 'YouTube' : 'Spotify'}: ${esc(title(it))}" src="${spEmbed(it)}" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" allowfullscreen></iframe>
      ${yt ? `<div class="mp-bar-t"><b>${esc(title(it))}</b><small>Full songs from YouTube</small></div>` : ''}
      <div class="mp-bar-side"><a class="mp-open" href="${spPage(it)}" target="_blank" rel="noopener">Open in ${yt ? 'YouTube' : 'Spotify'} ↗</a><button type="button" class="mp-x" data-mp-stop aria-label="Stop the music" title="Stop">${X}</button></div>`;
    document.querySelectorAll('.mp-tile').forEach((t) => t.classList.toggle('on', t.dataset.id === it.id));
    markMusic();
  }
  function stop() { nowPlaying = null; bar.hidden = true; bar.innerHTML = ''; document.body.classList.remove('mp-playing'); document.querySelectorAll('.mp-tile.on').forEach((t) => t.classList.remove('on')); markMusic(); }
  const mount = () => document.body.appendChild(bar);
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);

  /* ---------- song search inside the site (Apple's free public song search; 30-second previews) ---------- */
  let sq = '', sres = [], sstate = 'idle';
  const preview = new Audio(); preview.preload = 'none';
  let pvIdx = -1;
  function itunes(q, extra) {
    const url = 'https://itunes.apple.com/search?media=music&entity=song&limit=30' + (extra || '') + '&term=' + encodeURIComponent(q);
    const jsonp = () => new Promise((res, rej) => {
      const cb = '__vxIt' + Date.now().toString(36), sc = document.createElement('script');
      const done = (v, err) => { try { delete window[cb]; } catch (x) { window[cb] = undefined; } sc.remove(); err ? rej(err) : res(v); };
      window[cb] = (j) => done(j); sc.onerror = () => done(null, new Error('blocked'));
      sc.src = url + '&callback=' + cb; document.head.appendChild(sc); setTimeout(() => window[cb] && done(null, new Error('timeout')), 9000);
    });
    return fetch(url).then((r) => { if (!r.ok) throw new Error('http'); return r.json(); }).catch(jsonp);
  }
  function runSearch(q) {
    sq = q; sstate = 'loading'; sres = []; paintMain();
    itunes(q).then((j) => {
      if (sq !== q) return;
      sres = ((j && j.results) || []).filter((r) => r.trackName && r.artistName).map((r) => ({
        title: String(r.trackName).slice(0, 90), artist: String(r.artistName).slice(0, 70), album: String(r.collectionName || '').slice(0, 70),
        cover: String(r.artworkUrl100 || '').replace('100x100bb', '300x300bb'), preview: /^https:\/\//.test(r.previewUrl || '') ? r.previewUrl : '',
        link: /^https:\/\//.test(r.trackViewUrl || '') ? r.trackViewUrl : '', ms: r.trackTimeMillis || 0
      }));
      sstate = 'done'; paintMain();
    }).catch(() => { if (sq === q) { sstate = 'error'; paintMain(); } });
  }
  const mmss = (ms) => { const t = Math.round(ms / 1000); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
  const ytFind = (r) => 'https://www.youtube.com/results?search_query=' + encodeURIComponent(r.title + ' ' + r.artist + ' official audio');
  function playPreview(i) {
    const r = sres[i]; if (!r) return;
    if (!r.preview) { toast('No preview for this one. Tap Full song.'); return; }
    if (nowPlaying) stop(); audio.pause();
    pvIdx = i; preview.src = r.preview; preview.play().catch(() => toast("That preview couldn't play."));
    document.dispatchEvent(new CustomEvent('vexo:music'));
    bar.hidden = false; document.body.classList.add('mp-playing'); bar.classList.remove('yt');
    bar.innerHTML = `<img class="mp-pv-cover" src="${esc(r.cover)}" alt="" data-hide-err><div class="mp-bar-t"><b>${esc(r.title)}</b><small>${esc(r.artist)} · 30-second preview</small></div>
      <button type="button" class="mp-c mp-c-main" data-pv-toggle aria-label="Pause">❚❚</button>
      <div class="mp-bar-side"><a class="mp-open" href="${esc(ytFind(r))}" target="_blank" rel="noopener">Full song on YouTube ↗</a><button type="button" class="mp-x" data-pv-stop aria-label="Stop" title="Stop">${X}</button></div>`;
    paintResults(); markMusic();
  }
  function stopPreview() { preview.pause(); pvIdx = -1; if (!nowPlaying) { bar.hidden = true; bar.innerHTML = ''; document.body.classList.remove('mp-playing'); } paintResults(); markMusic(); }
  preview.addEventListener('ended', () => { if (sres[pvIdx + 1]) playPreview(pvIdx + 1); else stopPreview(); });
  ['play', 'pause'].forEach((ev) => preview.addEventListener(ev, () => { const t = bar.querySelector('[data-pv-toggle]'); if (t) { t.textContent = preview.paused ? '▶' : '❚❚'; t.setAttribute('aria-label', preview.paused ? 'Play' : 'Pause'); } markMusic(); }));
  function results() {
    if (sstate === 'idle') return '';
    if (sstate === 'loading') return '<div class="mp-loading"><span class="ld-spin"></span>Searching…</div>';
    if (sstate === 'error') return '<p class="mp-note">Search isn\'t working right now. This network might be blocking it. You can still use Paste &amp; play below.</p>';
    if (!sres.length) return `<p class="mp-note">No songs found for "${esc(sq)}". Try another spelling.</p>`;
    return `<p class="mp-res-count">${sres.length} songs for "${esc(sq)}"</p><ol class="mp-res">${sres.map((r, i) => `<li class="${i === pvIdx ? 'on' : ''}">
      <button type="button" class="mp-res-play" data-pv="${i}" aria-label="Play a preview of ${esc(r.title)}"><img src="${esc(r.cover)}" alt="" loading="lazy" data-hide-err><span>${i === pvIdx && !preview.paused ? '❚❚' : '▶'}</span></button>
      <span class="mp-res-t"><b>${esc(r.title)}</b><small>${esc(r.artist)}${r.album ? ' · ' + esc(r.album) : ''}</small></span>
      <span class="mp-res-len">${r.ms ? mmss(r.ms) : ''}</span>
      <a class="mp-btn mp-res-full" href="${esc(ytFind(r))}" target="_blank" rel="noopener" title="Find the full song on YouTube">Full song</a></li>`).join('')}</ol>
      <p class="mp-attrib">Song search by Apple Music${sres[0] && sres[0].link ? ` · <a href="${esc(sres[0].link)}" target="_blank" rel="noopener">Listen on Apple Music ↗</a>` : ''}</p>`;
  }
  function paintResults() { const r = document.getElementById('mpResults'); if (r) r.innerHTML = results(); }

  /* ---------- songs from your own device ---------- */
  const songs = []; let songIdx = -1;
  const audio = new Audio(); audio.preload = 'auto';
  audio.addEventListener('ended', () => { if (songs.length) playSong((songIdx + 1) % songs.length); });
  ['play', 'pause'].forEach((ev) => audio.addEventListener(ev, () => { markMusic(); if (sub === 'library') paintMain(); }));
  function playSong(i) {
    if (!songs[i]) return;
    if (nowPlaying) stop(); preview.pause(); pvIdx = -1;
    songIdx = i; audio.src = songs[i].url;
    const p = audio.play(); if (p && p.catch) p.catch(() => toast("That song couldn't play. Try a different file."));
  }

  /* ---------- the page ---------- */
  let sub = 'browse';
  const I = {
    browse: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/></svg>',
    search: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    library: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4v16M9 4v16M14 5l5 15"/></svg>',
    list: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h12M4 12h12M4 18h8M18 15v6M15 18h6"/></svg>',
    plus: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>'
  };
  function tile(it, opts = {}) {
    fetchMeta(it);
    const m = META[it.id] || (it.type === 'ytvideo' ? { thumb: `https://i.ytimg.com/vi/${it.id}/hqdefault.jpg` } : null), on = nowPlaying && nowPlaying.id === it.id;
    return `<div class="mp-tile${on ? ' on' : ''}" data-id="${esc(it.id)}" data-meta="${esc(it.id)}"${opts.keepName ? ' data-keep-name="1"' : ''}>
      <button type="button" class="mp-tile-btn" data-mp-play data-type="${esc(it.type)}" data-pid="${esc(it.id)}" data-name="${esc(it.name || '')}" aria-label="Play ${esc(title(it))}">
        <span class="mp-art">${NOTE}<img class="mp-cover" src="${m && m.thumb ? esc(m.thumb) : ''}" alt="" ${m && m.thumb ? '' : 'hidden'} data-hide-err><span class="mp-playbtn" aria-hidden="true"><svg class="ic" viewBox="0 0 24 24"><path d="M7 4.5v15l13-7.5z" fill="currentColor"/></svg></span></span>
        <span class="mp-t">${esc(opts.keepName ? it.name : title(it))}</span><small>${esc(KIND[it.type])}</small>
      </button>${opts.remove ? `<button type="button" class="mp-del" ${opts.remove} aria-label="Remove ${esc(title(it))}" title="Remove">${X}</button>` : ''}</div>`;
  }
  const row = (head, items, opts) => items.length ? `<section class="mp-row"><h2>${head}</h2><div class="mp-tiles">${items.map((it) => tile(it, opts)).join('')}</div></section>` : '';
  function sidebar() {
    const pls = playlists();
    const item = (key, icon, name) => `<button type="button" class="mp-nav${sub === key ? ' on' : ''}" data-mp-tab="${key}">${icon}<span>${esc(name)}</span></button>`;
    return `<h1 class="mp-h">Music</h1>
      <nav class="mp-navs">${item('browse', I.browse, 'Browse')}${item('search', I.search, 'Search')}${item('library', I.library, 'Your Library')}</nav>
      <p class="mp-lbl">Playlists</p>
      <div class="mp-pls">${pls.length ? pls.map((p) => item('pl:' + p.id, I.list, p.name)).join('') : '<p class="mp-empty">Create your first playlist</p>'}</div>
      <button type="button" class="mp-new" data-mp-new>${I.plus}New playlist</button>`;
  }
  function content() {
    if (sub === 'search') return `<header class="mp-top"><h2>Search</h2></header>
      <form class="mp-find" data-mp-find novalidate>${I.search}<input type="search" id="mpFind" placeholder="Search any song or artist" aria-label="Search for songs" autocomplete="off" value="${esc(sq)}"><button type="submit" class="mp-btn mp-main">Search</button></form>
      <div id="mpResults">${results()}</div>
      <section class="mp-row mp-full"><h2>Play the full song on your site</h2>
        <div class="mp-steps"><div><b>1</b><span>Tap <b>Full song</b> on a result (or find it on YouTube or Spotify).</span></div><div><b>2</b><span>Tap <b>Share</b>, then <b>Copy link</b>.</span></div><div><b>3</b><span>Come back and tap <b>Paste &amp; play</b>.</span></div></div>
        <div class="mp-paste"><button type="button" class="mp-btn mp-main" data-mp-paste>Paste &amp; play</button>
          <form class="mp-add" data-mp-add novalidate><input type="url" id="mpLink" placeholder="Or paste a YouTube or Spotify link here" aria-label="YouTube or Spotify link" autocomplete="off"><button type="submit" class="mp-btn">Play</button></form></div></section>`;
    if (sub === 'library') {
      const lib = library(), now = songs[songIdx];
      return `<header class="mp-top"><h2>Your Library</h2></header>
        ${lib.length ? row('Saved from Spotify', lib, { remove: 'data-mp-unsave' }) : '<p class="mp-note">Songs and playlists you play from a Spotify link get saved here.</p>'}
        <section class="mp-row"><h2>Songs from your device</h2>
          <div class="mp-local">
            <label class="mp-btn mp-main mp-choose">${I.plus}Choose songs<input type="file" id="mpFiles" accept="audio/*,.mp3,.m4a,.wav,.ogg,.flac,.aac,.opus" multiple hidden></label>
            ${songs.length ? `<div class="mp-now"><b>${now ? esc(now.title) : 'Pick a song'}</b><small>${now ? (audio.paused ? 'Paused' : 'Playing') : songs.length + ' ready'}</small>
              <div class="mp-ctrls"><button type="button" class="mp-c" data-my="prev" aria-label="Previous">⏮</button><button type="button" class="mp-c mp-c-main" data-my="play" aria-label="${now && !audio.paused ? 'Pause' : 'Play'}">${now && !audio.paused ? '❚❚' : '▶'}</button><button type="button" class="mp-c" data-my="next" aria-label="Next">⏭</button></div></div>
              <ol class="mp-songs">${songs.map((s, i) => `<li><button type="button" class="${i === songIdx ? 'on' : ''}" data-song="${i}"><span>${i + 1}</span>${esc(s.title)}</button></li>`).join('')}</ol>` : '<p class="mp-note">Pick music files like MP3s from your phone or computer. They play only for you and need picking again after a reload.</p>'}
          </div></section>`;
    }
    if (sub.startsWith('pl:')) {
      const p = playlists().find((x) => 'pl:' + x.id === sub);
      if (!p) { sub = 'browse'; return content(); }
      return `<header class="mp-top"><h2>${esc(p.name)}</h2><span class="mp-count">${p.items.length} item${p.items.length === 1 ? '' : 's'}</span>
          <button type="button" class="mp-btn" data-mp-rename="${esc(p.id)}">Rename</button><button type="button" class="mp-btn mp-danger" data-mp-delpl="${esc(p.id)}">Delete</button></header>
        <form class="mp-add" data-mp-addto="${esc(p.id)}" novalidate><input type="url" id="mpAddTo" placeholder="Paste a YouTube or Spotify link to add it" aria-label="Spotify link" autocomplete="off"><button type="submit" class="mp-btn mp-main">Add</button></form>
        ${p.items.length ? `<div class="mp-tiles mp-grid">${p.items.map((it) => tile(it, { remove: `data-mp-rmfrom="${esc(p.id)}"` })).join('')}</div>` : '<p class="mp-note">This playlist is empty. In Spotify, tap <b>Share</b>, then <b>Copy link</b>, and paste it above.</p>'}`;
    }
    const lib = library(), pls = playlists();
    return `<header class="mp-top"><h2>Browse</h2></header>
      ${row('Full songs <span class="mp-tag">YouTube · no login</span>', YOUTUBE)}
      ${row('Spotify playlists <span class="mp-tag">full songs when logged in</span>', FEATURED)}
      ${row('Your picks', lib)}
      ${pls.length ? `<section class="mp-row"><h2>Your playlists</h2><div class="mp-tiles">${pls.map((p) => { const f = p.items[0]; if (f) fetchMeta(f); const th = f && META[f.id] && META[f.id].thumb; return `<div class="mp-tile"><button type="button" class="mp-tile-btn" data-mp-tab="pl:${esc(p.id)}"><span class="mp-art">${I.list}${f ? `<img class="mp-cover" data-cover-of="${esc(f.id)}" src="${th ? esc(th) : ''}" alt="" ${th ? '' : 'hidden'} data-hide-err>` : ''}</span><span class="mp-t">${esc(p.name)}</span><small>${p.items.length} item${p.items.length === 1 ? '' : 's'}</small></button></div>`; }).join('')}</div></section>` : ''}
      <p class="mp-note">YouTube playlists play full songs with no login. Spotify plays full songs when you're logged in to Spotify in this browser, otherwise 30-second previews. Music keeps playing while you browse and play games.</p>`;
  }
  function page() { return `<div class="mp"><aside class="mp-side">${sidebar()}</aside><section class="mp-main" id="mpMain">${content()}</section></div>`; }
  function paintSide() { const s = document.querySelector('.mp-side'); if (s) s.innerHTML = sidebar(); }
  function paintMain() { const m = document.getElementById('mpMain'); if (m) m.innerHTML = content(); }
  function go(s) { sub = s; paintSide(); paintMain(); const m = document.getElementById('mpMain'); if (m && m.scrollIntoView && innerWidth < 760) m.scrollIntoView({ block: 'start' }); }

  /* ---------- adding links ---------- */
  function parse(text) {
    text = String(text || '');
    const y = text.match(YT_LINK); if (y) return y[2] ? { type: 'ytlist', id: y[2] } : { type: 'ytvideo', id: y[1] };
    const m = text.match(SP_LINK); return m ? { type: m[1], id: m[2] } : null;
  }
  function saveToLibrary(it) {
    const l = library().filter((x) => x.id !== it.id);
    l.unshift({ type: it.type, id: it.id, name: it.name || KIND[it.type], mine: true }); saveLibrary(l);
  }
  function playLink(text) {
    const it = parse(text);
    if (!it) { toast("That isn't a YouTube or Spotify link. Tap Share, then Copy link."); return false; }
    it.name = KIND[it.type]; saveToLibrary(it); play(it); toast('Playing. Saved to Your Library.'); if (sub === 'library' || sub === 'browse') paintMain();
    return true;
  }

  /* ---------- clicks ---------- */
  document.addEventListener('click', async (e) => {
    if (e.target.closest('[data-mp-stop]')) { stop(); return; }
    if (e.target.closest('[data-pv-stop]')) { stopPreview(); return; }
    if (e.target.closest('[data-pv-toggle]')) { if (preview.paused) preview.play().catch(() => {}); else preview.pause(); return; }
    const pv = e.target.closest('[data-pv]'); if (pv) { const i = Number(pv.dataset.pv); if (i === pvIdx) { if (preview.paused) preview.play().catch(() => {}); else preview.pause(); paintResults(); } else playPreview(i); return; }
    const t = e.target.closest('[data-mp-tab]'); if (t) { go(t.dataset.mpTab); return; }
    const pl = e.target.closest('[data-mp-play]'); if (pl) { play({ type: pl.dataset.type, id: pl.dataset.pid, name: pl.dataset.name }); return; }
    const un = e.target.closest('[data-mp-unsave]'); if (un) { const id = un.closest('.mp-tile').dataset.id; saveLibrary(library().filter((x) => x.id !== id)); paintMain(); toast('Removed from Your Library'); return; }
    const rf = e.target.closest('[data-mp-rmfrom]'); if (rf) { const id = rf.closest('.mp-tile').dataset.id, l = playlists(), p = l.find((x) => x.id === rf.dataset.mpRmfrom); if (p) { p.items = p.items.filter((x) => x.id !== id); savePlaylists(l); paintMain(); } return; }
    if (e.target.closest('[data-mp-new]')) {
      const v = await window.Vexo.dialog({ title: 'New playlist', ok: 'Create', fields: [{ label: 'Name', attrs: 'maxlength="40" placeholder="My playlist"', check: (x) => (x.trim() ? '' : 'Give your playlist a name.') }] });
      if (!v) return;
      const l = playlists(), id = 'p' + Date.now().toString(36); l.push({ id, name: v[0].trim().slice(0, 40), items: [] }); savePlaylists(l); go('pl:' + id); toast('Playlist created'); return;
    }
    const rn = e.target.closest('[data-mp-rename]');
    if (rn) {
      const l = playlists(), p = l.find((x) => x.id === rn.dataset.mpRename); if (!p) return;
      const v = await window.Vexo.dialog({ title: 'Rename playlist', ok: 'Save', fields: [{ label: 'Name', attrs: `maxlength="40" value="${esc(p.name)}"`, check: (x) => (x.trim() ? '' : 'Give your playlist a name.') }] });
      if (!v) return; p.name = v[0].trim().slice(0, 40); savePlaylists(l); paintSide(); paintMain(); return;
    }
    const dp = e.target.closest('[data-mp-delpl]');
    if (dp) {
      const ok = await window.Vexo.ask('Delete this playlist?', 'The songs stay on Spotify. This only removes the playlist from VEXO-GN.', 'Delete');
      if (!ok) return; savePlaylists(playlists().filter((x) => x.id !== dp.dataset.mpDelpl)); go('browse'); toast('Playlist deleted'); return;
    }
    if (e.target.closest('[data-mp-paste]')) {
      let text = ''; try { text = await navigator.clipboard.readText(); } catch (x) { text = ''; }
      if (text && parse(text)) { playLink(text); return; }
      const inp = document.getElementById('mpLink'); if (inp) inp.focus();
      toast(text ? "What you copied isn't a YouTube or Spotify link." : 'Paste the link in the box below.');
      return;
    }
    const my = e.target.closest('[data-my]');
    if (my) { const a = my.dataset.my; if (a === 'play') { if (songIdx < 0) playSong(0); else if (audio.paused) { if (nowPlaying) stop(); audio.play().catch(() => {}); } else audio.pause(); } if (a === 'next') playSong((songIdx + 1) % songs.length); if (a === 'prev') playSong((songIdx - 1 + songs.length) % songs.length); return; }
    const sg = e.target.closest('[data-song]'); if (sg) playSong(Number(sg.dataset.song));
  });
  document.addEventListener('submit', (e) => {
    const f = e.target;
    if (f.matches('[data-mp-find]')) {
      e.preventDefault(); const q = f.querySelector('#mpFind').value.trim(); if (!q) { f.querySelector('#mpFind').focus(); return; }
      runSearch(q);
    }
    if (f.matches('[data-mp-add]')) { e.preventDefault(); if (playLink(f.querySelector('#mpLink').value.trim())) f.querySelector('#mpLink').value = ''; }
    if (f.matches('[data-mp-addto]')) {
      e.preventDefault();
      const it = parse(f.querySelector('#mpAddTo').value.trim());
      if (!it) { toast("That isn't a YouTube or Spotify link. Tap Share, then Copy link."); return; }
      const l = playlists(), p = l.find((x) => x.id === f.dataset.mpAddto); if (!p) return;
      if (!p.items.some((x) => x.id === it.id)) p.items.push({ type: it.type, id: it.id, name: KIND[it.type] });
      savePlaylists(l); paintMain(); paintSide(); toast('Added to ' + p.name);
    }
  });
  document.addEventListener('paste', (e) => {
    if (e.target.id !== 'mpLink' && e.target.id !== 'mpFind') return;
    const text = (e.clipboardData || window.clipboardData).getData('text');
    if (parse(text)) { e.preventDefault(); playLink(text); }
  });
  document.addEventListener('change', (e) => {
    if (e.target.id !== 'mpFiles') return;
    const files = [...e.target.files].filter((f) => /^audio\//.test(f.type) || /\.(mp3|m4a|aac|wav|ogg|oga|flac|opus|webm)$/i.test(f.name));
    e.target.value = '';
    if (!files.length) { toast('Pick a music file, like an MP3.'); return; }
    const first = songs.length;
    files.forEach((f) => songs.push({ title: f.name.replace(/\.[^.]+$/, '').slice(0, 80), url: URL.createObjectURL(f) }));
    toast(`Added ${files.length} song${files.length > 1 ? 's' : ''}`); playSong(first); paintMain();
  });

  document.addEventListener('vexo:ad', () => { try { audio.pause(); preview.pause(); } catch (e) {} }); // quiet while a full-screen ad plays
  window.VexoMusic = { page, itunes, show: () => { location.hash = '#/music'; }, play, stop, playing: () => !!nowPlaying || !audio.paused || !preview.paused, previewing: () => !preview.paused, nowPlaying: () => nowPlaying, songs: () => songs.length, featured: FEATURED.map((p) => p.name), youtube: YOUTUBE.map((p) => p.name) };
})();
