/* VEXO-GN - Levels, XP, badges and the Game of the Day.
   Everything is saved in this browser (no account).
   XP comes from: visiting each day (bigger bonus for streaks), playing games (more for new ones and the
   Game of the Day), playing music, asking Vexo AI, searching, setting movie reminders and customizing the look.
   Other parts of the site tell this file what happened with events like "vexo:play" and "vexo:music". */
(function () {
  'use strict';
  const { esc, Store, toast, thumbOf } = window.Vexo;
  const KEY = 'vexo_progress';

  /* ---------- dates ---------- */
  const ymd = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const today = () => ymd(new Date());
  const dateOf = (x) => { const [y, m, d] = String(x).split('-').map(Number); return new Date(y, m - 1, d); };
  const dayNum = (s) => { const [y, m, d] = String(s).split('-').map(Number); return Math.round(new Date(y, m - 1, d).getTime() / 86400000); };

  /* ---------- saved progress ---------- */
  const blank = () => ({ xp: 0, lastDay: '', streak: 0, best: 0, visits: 0, plays: 0, games: [], songs: 0, ai: 0, searches: 0, reminders: 0, gotd: 0, custom: 0, badges: {}, daily: {} });
  function load() {
    try { const v = JSON.parse(localStorage.getItem(KEY) || 'null'); if (v && typeof v === 'object') return Object.assign(blank(), v); } catch (e) {}
    return blank();
  }
  let s = load();
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {} };
  function daily() { if (s.daily.day !== today()) s.daily = { day: today(), play: 0, music: 0, ai: 0, search: 0, gotd: false }; return s.daily; }

  /* ---------- levels ---------- */
  const need = (lv) => 50 * (lv - 1) * lv; // XP needed to reach a level: 2 → 100, 3 → 300, 5 → 1000, 10 → 4500
  const levelOf = (xp) => { let lv = 1; while (xp >= need(lv + 1)) lv++; return lv; };
  const RANKS = [[1, 'Rookie'], [3, 'Player'], [5, 'Pro'], [8, 'Elite'], [12, 'Legend'], [20, 'Mythic']];
  const rank = (lv) => RANKS.filter(([n]) => lv >= n).pop()[1];

  /* ---------- badges ---------- */
  const I = {
    pad: '<path d="M7 7h10a5 5 0 015 5v1a4 4 0 01-7 2.6L14 15h-4l-1 .6A4 4 0 012 13v-1a5 5 0 015-5z"/><path d="M7.5 10v4M5.5 12h4"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
    stack: '<rect x="4" y="4" width="16" height="5" rx="1.5"/><rect x="4" y="10" width="16" height="5" rx="1.5"/><rect x="4" y="16" width="16" height="4" rx="1.5"/>',
    bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
    flame: '<path d="M12 22c4 0 7-2.8 7-6.8 0-3.4-2.4-5.6-3.8-7.6-.4 1.8-1.4 3-2.6 3.6.4-3.4-1.2-6.6-4.1-8.2.2 3.4-1.7 5.6-3.2 7.6C4.2 12.6 5 14 5 15.2 5 19.2 8 22 12 22z"/>',
    note: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
    phones: '<path d="M4 15v-3a8 8 0 0116 0v3"/><rect x="3" y="14" width="5" height="7" rx="2"/><rect x="16" y="14" width="5" height="7" rx="2"/>',
    spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    bell: '<path d="M6 16V11a6 6 0 0112 0v5l2 2H4z"/><path d="M10 20a2 2 0 004 0"/>',
    brush: '<path d="M14 4l6 6-8.5 8.5a3 3 0 01-4.2 0l-1.8-1.8a3 3 0 010-4.2z"/><path d="M4 20c1.5 0 3-.5 3-2"/>',
    trophy: '<path d="M8 4h8v5a4 4 0 01-8 0z"/><path d="M8 6H5a3 3 0 003 4M16 6h3a3 3 0 01-3 4M12 13v4M8 21h8M9 17h6"/>',
    crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/>',
    gem: '<path d="M6 3h12l3 6-9 12L3 9z"/><path d="M3 9h18M9 3l3 6 3-6M12 9v12"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'
  };
  const svg = (k) => `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[k]}</svg>`;
  const BADGES = [
    { id: 'first-game', icon: 'pad', name: 'First Game', how: 'Play your first game', n: () => s.plays, goal: 1 },
    { id: 'explorer', icon: 'compass', name: 'Explorer', how: 'Play 10 different games', n: () => s.games.length, goal: 10 },
    { id: 'collector', icon: 'stack', name: 'Collector', how: 'Play 25 different games', n: () => s.games.length, goal: 25 },
    { id: 'marathon', icon: 'bolt', name: 'Marathon', how: 'Start 100 games', n: () => s.plays, goal: 100 },
    { id: 'daily-pick', icon: 'star', name: 'Daily Pick', how: 'Play the Game of the Day', n: () => s.gotd, goal: 1 },
    { id: 'daily-pick-7', icon: 'sun', name: 'Pick Pro', how: 'Play the Game of the Day 7 times', n: () => s.gotd, goal: 7 },
    { id: 'streak-3', icon: 'flame', name: '3-Day Streak', how: 'Visit Vexo 3 days in a row', n: () => s.best, goal: 3 },
    { id: 'streak-7', icon: 'flame', name: '7-Day Streak', how: 'Visit Vexo 7 days in a row', n: () => s.best, goal: 7 },
    { id: 'streak-30', icon: 'flame', name: '30-Day Streak', how: 'Visit Vexo 30 days in a row', n: () => s.best, goal: 30 },
    { id: 'dj', icon: 'note', name: 'DJ', how: 'Play 10 songs', n: () => s.songs, goal: 10 },
    { id: 'music-lover', icon: 'phones', name: 'Music Lover', how: 'Play 50 songs', n: () => s.songs, goal: 50 },
    { id: 'curious', icon: 'spark', name: 'Curious Mind', how: 'Ask Vexo AI 10 questions', n: () => s.ai, goal: 10 },
    { id: 'searcher', icon: 'search', name: 'Searcher', how: 'Do 10 searches in Vexo Search', n: () => s.searches, goal: 10 },
    { id: 'movie-buff', icon: 'bell', name: 'Movie Buff', how: 'Set 3 movie reminders', n: () => s.reminders, goal: 3 },
    { id: 'stylist', icon: 'brush', name: 'Stylist', how: 'Change your background or cursor', n: () => s.custom, goal: 1 },
    { id: 'level-5', icon: 'trophy', name: 'Level 5', how: 'Reach level 5', n: () => levelOf(s.xp), goal: 5 },
    { id: 'level-10', icon: 'crown', name: 'Level 10', how: 'Reach level 10', n: () => levelOf(s.xp), goal: 10 },
    { id: 'level-20', icon: 'gem', name: 'Level 20', how: 'Reach level 20', n: () => levelOf(s.xp), goal: 20 }
  ];

  /* ---------- popups ---------- */
  const queue = []; let showing = false;
  function pop(html) {
    queue.push(html); if (showing) return;
    const next = () => {
      const h = queue.shift(); if (!h) { showing = false; return; }
      showing = true;
      const el = document.createElement('div'); el.className = 'xp-pop'; el.setAttribute('role', 'status'); el.innerHTML = h;
      document.body.appendChild(el);
      requestAnimationFrame(() => el.classList.add('in'));
      setTimeout(() => { el.classList.remove('in'); setTimeout(() => { el.remove(); next(); }, 350); }, 3200);
    };
    next();
  }
  let floatT = 0;
  function float(n) { // small "+10 XP" chip in the corner
    let el = document.querySelector('.xp-float');
    if (!el) { el = document.createElement('div'); el.className = 'xp-float'; el.setAttribute('aria-hidden', 'true'); document.body.appendChild(el); }
    el.textContent = '+' + n + ' XP'; el.classList.remove('go'); void el.offsetWidth; el.classList.add('go');
    clearTimeout(floatT); floatT = setTimeout(() => el.classList.remove('go'), 1600);
  }
  function checkBadges(quiet) {
    BADGES.forEach((b) => {
      if (s.badges[b.id] || b.n() < b.goal) return;
      s.badges[b.id] = today();
      if (!quiet) pop(`<span class="xp-pop-ic">${svg(b.icon)}</span><span><small>Badge unlocked</small><b>${esc(b.name)}</b></span>`);
    });
  }
  function gain(n) {
    const before = levelOf(s.xp);
    s.xp += n;
    const after = levelOf(s.xp);
    float(n);
    if (after > before) pop(`<span class="xp-pop-ic is-lv">${after}</span><span><small>Level up!</small><b>Level ${after} · ${esc(rank(after))}</b></span>`);
    checkBadges(false); save(); paintChips();
  }

  /* ---------- Game of the Day: the same pick for everyone, new every day ---------- */
  function gotd(dateStr) {
    const list = Store.games().filter((g) => !g.external).sort((a, b) => (a.id < b.id ? -1 : 1));
    const pool = list.length ? list : Store.games(); if (!pool.length) return null;
    let h = 2166136261; for (const ch of String(dateStr || today())) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
    return pool[(h >>> 0) % pool.length];
  }
  function nextPickIn() {
    const n = new Date(); const t = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1) - n;
    const h = Math.floor(t / 3600000), m = Math.floor((t % 3600000) / 60000);
    return h ? `${h}h ${m}m` : `${m}m`;
  }
  function gotdCard() {
    const g = gotd(); if (!g) return '';
    const done = daily().gotd;
    return `<a class="gotd" href="#/play/${encodeURIComponent(g.id)}" data-open="${esc(g.id)}" aria-label="Game of the Day: ${esc(g.title)}">
      <span class="gotd-pic"><img src="${esc(thumbOf(g))}" alt="" loading="lazy" data-hide-err></span>
      <span class="gotd-t"><small>${svg('star')}Game of the Day${done ? ' · played' : ' · +50 XP'}</small><b>${esc(g.title)}</b><em>${esc((g.categories || []).join(' · '))}</em></span>
      <span class="gotd-go">Play</span>
      <span class="gotd-next">New pick in ${nextPickIn()}</span>
    </a>`;
  }

  /* ---------- what counts ---------- */
  function visit() {
    const t = today(); if (s.lastDay === t) return;
    const gap = s.lastDay ? dayNum(t) - dayNum(s.lastDay) : 0;
    s.streak = gap === 1 ? s.streak + 1 : 1;
    s.best = Math.max(s.best, s.streak); s.visits++; s.lastDay = t;
    const bonus = 25 + Math.min(50, 5 * (s.streak - 1));
    save();
    setTimeout(() => {
      gain(bonus);
      if (s.streak > 1) pop(`<span class="xp-pop-ic">${svg('flame')}</span><span><small>Welcome back</small><b>${s.streak}-day streak · +${bonus} XP</b></span>`);
    }, 1200);
  }
  document.addEventListener('vexo:play', (e) => {
    const id = e.detail && e.detail.id; if (!id) return;
    const d = daily(); let n = 0;
    s.plays++;
    if (!s.games.includes(id)) { s.games.push(id); n += 20; }
    if (d.play < 20) { d.play++; n += 10; }
    const g = gotd();
    if (g && g.id === id && !d.gotd) { d.gotd = true; s.gotd++; n += 50; pop(`<span class="xp-pop-ic">${svg('star')}</span><span><small>Game of the Day</small><b>Bonus +50 XP</b></span>`); }
    if (n) gain(n); else { checkBadges(false); save(); }
  });
  document.addEventListener('vexo:music', () => { const d = daily(); s.songs++; if (d.music < 30) { d.music++; gain(5); } else { checkBadges(false); save(); } });
  document.addEventListener('vexo:ai', () => { const d = daily(); s.ai++; if (d.ai < 20) { d.ai++; gain(2); } else { checkBadges(false); save(); } });
  document.addEventListener('vexo:search', () => { const d = daily(); s.searches++; if ((d.search || 0) < 20) { d.search = (d.search || 0) + 1; gain(2); } else { checkBadges(false); save(); } });
  document.addEventListener('vexo:remind', () => { s.reminders++; gain(10); });
  document.addEventListener('vexo:custom', () => { s.custom++; if (s.custom === 1) gain(15); else { checkBadges(false); save(); } });

  /* ---------- level chip (sidebar + home) ---------- */
  function chip() {
    const lv = levelOf(s.xp);
    return `<a class="xp-chip" href="#/me" aria-label="Level ${lv}, ${s.streak}-day streak. See your badges"><span class="xp-chip-lv">${lv}</span><span>Level ${lv}</span>${s.streak > 1 ? `<span class="xp-chip-st">${svg('flame')}${s.streak}</span>` : ''}</a>`;
  }
  function paintChips() {
    const lv = levelOf(s.xp);
    document.querySelectorAll('[data-xp-lv]').forEach((el) => { el.textContent = lv; });
    document.querySelectorAll('.xp-chip').forEach((el) => { el.outerHTML = chip(); });
  }

  /* ---------- the progress page (#/me) ---------- */
  function page() {
    checkBadges(true); save();
    const lv = levelOf(s.xp), lo = need(lv), hi = need(lv + 1), pct = Math.max(0, Math.min(100, ((s.xp - lo) / (hi - lo)) * 100));
    const R = 54, C = 2 * Math.PI * R;
    const got = BADGES.filter((b) => s.badges[b.id]).length;
    const stat = (n, l) => `<div class="me-stat"><b>${n}</b><small>${l}</small></div>`;
    return `<div class="me">
      <header class="me-head">
        <div class="me-ring"><svg viewBox="0 0 128 128" aria-hidden="true"><circle cx="64" cy="64" r="${R}" class="me-ring-bg"/><circle cx="64" cy="64" r="${R}" class="me-ring-fg" style="stroke-dasharray:${C.toFixed(1)};stroke-dashoffset:${(C * (1 - pct / 100)).toFixed(1)}"/></svg><span><b>${lv}</b><small>LEVEL</small></span></div>
        <div class="me-info">
          <p class="me-rank">${esc(rank(lv))}</p>
          <h1>Level ${lv}</h1>
          <div class="me-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(pct)}"><i style="width:${pct.toFixed(1)}%"></i></div>
          <p class="me-sub">${s.xp - lo} / ${hi - lo} XP to level ${lv + 1} · ${s.xp} XP total</p>
          <p class="me-streak">${svg('flame')}<b>${s.streak}-day streak</b><span>Best: ${s.best} days</span></p>
        </div>
      </header>
      <div class="me-stats">${stat(s.plays, 'Games started')}${stat(s.games.length, 'Different games')}${stat(s.songs, 'Songs played')}${stat(s.ai, 'AI questions')}${stat(s.visits, 'Days on Vexo')}</div>
      <h2 class="me-h">Badges <small>${got} of ${BADGES.length}</small></h2>
      <div class="me-badges">${BADGES.map((b) => {
        const on = !!s.badges[b.id], n = Math.min(b.n(), b.goal);
        return `<div class="me-badge${on ? ' on' : ''}"><span class="me-medal">${svg(b.icon)}</span><b>${esc(b.name)}</b><small>${esc(b.how)}</small>${on ? `<em>Unlocked ${esc(dateOf(s.badges[b.id]).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }))}</em>` : `<span class="me-prog"><i style="width:${(n / b.goal * 100).toFixed(0)}%"></i></span><em>${n} / ${b.goal}</em>`}</div>`;
      }).join('')}</div>
      <h2 class="me-h">How to earn XP</h2>
      <ul class="me-how">
        <li><b>+25</b> for visiting each day, plus up to <b>+50</b> more for your streak</li>
        <li><b>+10</b> for each game you start, <b>+20</b> more the first time you play a game</li>
        <li><b>+50</b> for playing the Game of the Day</li>
        <li><b>+5</b> for each song, <b>+2</b> for each AI question or search, <b>+10</b> for each movie reminder</li>
      </ul>
      <p class="mvp-note">Your level and badges are saved in this browser. Clearing your browser data resets them.</p>
    </div>`;
  }

  visit(); checkBadges(true); save();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', paintChips); else setTimeout(paintChips, 0);
  window.VexoXP = { page, chip, gotd, gotdCard, level: () => levelOf(s.xp), state: () => JSON.parse(JSON.stringify(s)), badges: BADGES.map((b) => b.id), nextPickIn };
})();
