/* VEXO-GN - game player page */
(function () {
  'use strict';
  const { autoFs, credit, Store, ICONS, CAT_COLORS, catIcon, esc, slug, card, shell, thumbOf, autoThumb, toast, popScore } = window.Vexo;
  const view = document.getElementById('view');
  const id = new URLSearchParams(location.search).get('id');
  const g = id ? Store.get(id) : null;
  shell(g && g.categories && g.categories[0] ? 'cat:' + g.categories[0] : '');

  if (!g) {
    document.title = 'Game not found - VEXO-GN';
    const pop = Store.games().slice().sort((a, b) => (b.popularity || 0) - (a.popularity || 0)).slice(0, 6);
    view.innerHTML = `<div class="empty">${ICONS.search}<h3>Game not found</h3><p>This game may have been removed or the link is wrong.</p><a class="btn primary" href="index.html">${ICONS.home}Back to home</a></div>
      <section class="section" style="margin-top:30px"><div class="sec-head"><h2>${ICONS.fire}Try these instead</h2></div><div class="grid">${pop.map((x) => card(x)).join('')}</div></section>`;
    return;
  }

  const safeUrl = (u) => (/^\s*(javascript|data|vbscript):/i.test(u || '') ? 'about:blank' : u);
  const isExternal = (u) => { try { const x = new URL(u, location.href); return /^https?:$/.test(x.protocol) && x.origin !== location.origin; } catch (e) { return false; } };
  const aspect = String(g.aspect || '16:9').replace(':', ' / ');
  const cats = g.categories || [];
  const plays = Store.plays();
  const all = Store.games().filter((x) => x.id !== g.id);
  const similar = all.map((x) => ({ x, s: (x.categories || []).filter((c) => cats.includes(c)).length * 100 + popScore(x, plays) }))
    .sort((a, b) => b.s - a.s).map((o) => o.x);
  const sideList = all.slice().sort((a, b) => popScore(b, plays) - popScore(a, plays)).slice(0, 7);
  const addedStr = g.added ? new Date(g.added + 'T00:00:00').toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '-';
  document.title = g.title + ' - Play Free on VEXO-GN';

  view.innerHTML = `
    <nav class="crumbs" aria-label="Breadcrumb"><a href="index.html">Home</a>${ICONS.chevR}${cats[0] ? `<a href="index.html#/category/${slug(cats[0])}">${esc(cats[0])}</a>${ICONS.chevR}` : ''}<span style="color:#fff">${esc(g.title)}</span></nav>
    <div class="play-layout">
      <div class="play-main">
        <div class="player-wrap" id="pw">
          <div class="player" id="player" style="aspect-ratio:${esc(aspect)}">
            <button class="splash" id="splash" aria-label="Play ${esc(g.title)}">
              <div class="splash-bg" style="background-image:url('${esc(thumbOf(g))}')"></div>
              <img src="${esc(thumbOf(g))}" alt="" data-fallback="${esc(autoThumb(g.title, (g.categories || [])[0], g.icon))}">
              <h2>${esc(g.title)}</h2>
              <span class="play-big">${ICONS.play}PLAY</span>
            </button>
          </div>
          <div class="player-bar">
            <h1><img src="${esc(thumbOf(g))}" alt="" data-fallback="${esc(autoThumb(g.title, (g.categories || [])[0], g.icon))}">${esc(g.title)}</h1>
            <div class="acts">
              <button class="btn${Store.isFav(g.id) ? ' on' : ''}" data-fav="${esc(g.id)}" title="Favorite">${ICONS.heart}<span class="lbl">Favorite</span></button>
              <button class="btn" id="restart" title="Restart game">${ICONS.refresh}<span class="lbl">Restart</span></button>
              <button class="btn" id="theater" title="Theater mode (wider player)">${ICONS.grid}<span class="lbl">Theater</span></button>
              ${g.embed && g.source ? `<a class="btn" href="${esc(g.source)}" target="_blank" rel="noopener" data-ext="${esc(g.id)}" title="If the game does not load here, open it in its own window">${ICONS.link}<span class="lbl">New window</span></a>` : `<button class="btn" id="share" title="Copy link">${ICONS.link}<span class="lbl">Copy link</span></button>`}
              <button class="btn primary" id="fs" title="Fullscreen (F)">${ICONS.expand}<span class="lbl">Fullscreen</span></button>
              <button class="btn danger fs-exit" id="fsx" title="Exit fullscreen">${ICONS.x}<span class="lbl">Exit</span></button>
            </div>
          </div>
        </div>
        <div class="info">
          <div class="panel">
            <h3>${ICONS.star}About ${esc(g.title)}</h3>
            <p>${esc(g.description || 'No description yet.')}</p>
            <div class="tags">${cats.map((c) => `<a class="tag" style="--c:${CAT_COLORS[c] || '#a855f7'}" href="index.html#/category/${slug(c)}">${catIcon(c)}${esc(c)}</a>`).join('')}</div>
          </div>
          <div class="panel">
            <h3>${ICONS.Arcade}How to Play</h3>
            <p>${esc(g.controls || 'Click the game to focus it, then use the on-screen instructions.')}</p>
            <dl class="meta">
              <dt>Category</dt><dd>${esc(cats.join(', ') || '-')}</dd>
              <dt>Added</dt><dd>${esc(addedStr)}</dd>
              <dt>Your plays</dt><dd id="myplays">${plays[g.id] || 0}</dd>
              ${credit(g) ? `<dt>Credits</dt><dd class="credit">${credit(g)}</dd>` : ''}
            </dl>
          </div>
        </div>
      </div>
      <aside class="play-side">
        <div class="side-list"><h3>Popular right now</h3>
          ${sideList.map((x) => `<a class="s-item" href="play.html?id=${encodeURIComponent(x.id)}"><img src="${esc(thumbOf(x))}" alt="" loading="lazy" data-fallback="${esc(autoThumb(x.title, (x.categories || [])[0], x.icon))}"><span><b>${esc(x.title)}</b><small>${esc((x.categories || []).join(' · '))}</small></span></a>`).join('')}
        </div>
      </aside>
    </div>
    ${similar.length ? `<section class="section" style="margin-top:30px"><div class="sec-head"><h2>${ICONS.spark}You may also like</h2><a class="more" href="index.html#/category/${slug(cats[0] || '')}">More ${esc(cats[0] || '')}${ICONS.chevR}</a></div><div class="grid">${similar.slice(0, 6).map((x) => card(x)).join('')}</div></section>` : ''}`;

  const pw = document.getElementById('pw'), player = document.getElementById('player');
  let frame = null;
  // GameDistribution games need to know which site they are on, so add that to their link
  const gameSrc = () => safeUrl(/gamedistribution\.com/.test(g.url) ? g.url + (g.url.includes('?') ? '&' : '?') + 'gd_sdk_referrer_url=' + encodeURIComponent(location.href) : g.url);

  function startGame() {
    if (g.external) return;
    if (frame) { frame.focus(); return; }
    frame = document.createElement('iframe');
    frame.title = g.title;
    frame.setAttribute('allow', 'fullscreen; autoplay; gamepad; pointer-lock');
    frame.setAttribute('allowfullscreen', '');
    if (isExternal(g.url) && !g.embed) frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-pointer-lock allow-forms allow-modals allow-orientation-lock allow-popups');
    frame.src = gameSrc();
    frame.addEventListener('load', () => { try { frame.focus(); frame.contentWindow.focus(); } catch (e) {} });
    document.getElementById('splash').replaceWith(frame);
    Store.pushRecent(g.id); Store.addPlay(g.id);
    document.getElementById('myplays').textContent = Store.plays()[g.id] || 1;
    setTimeout(() => frame.focus(), 50);
  }
  if (g.external) {
    const sp = document.getElementById('splash'), a = document.createElement('a');
    a.className = 'splash'; a.href = g.url; a.target = '_blank'; a.rel = 'noopener'; a.dataset.ext = g.id;
    a.innerHTML = sp.innerHTML.replace('PLAY</span>', 'PLAY ON ' + esc(String(g.author || '').toUpperCase()) + ' ↗</span>');
    sp.replaceWith(a);
    if (g.source && g.source !== g.url) document.querySelector('.player-bar').insertAdjacentHTML('afterend', `<p class="ext-help" style="margin:10px 4px">Game not loading? <a href="${esc(g.source)}" target="_blank" rel="noopener">Open the regular ${esc(g.author)} page ↗</a></p>`);
  } else document.getElementById('splash').addEventListener('click', () => { if (autoFs()) enterFs(); else startGame(); });

  document.getElementById('restart').onclick = () => {
    if (!frame) return startGame();
    frame.src = 'about:blank';
    setTimeout(() => { frame.src = gameSrc(); }, 30);
    toast('Game restarted');
  };

  // theater mode
  const theaterBtn = document.getElementById('theater');
  const setTheater = (on) => { document.body.classList.toggle('theater', on); theaterBtn.classList.toggle('on', on); try { localStorage.setItem('vexo_theater', on ? '1' : '0'); } catch (e) {} };
  try { if (localStorage.getItem('vexo_theater') === '1') setTheater(true); } catch (e) {}
  theaterBtn.onclick = () => setTheater(!document.body.classList.contains('theater'));

  // copy link
  if (document.getElementById('share')) document.getElementById('share').onclick = async () => {
    const url = location.href;
    try { await navigator.clipboard.writeText(url); toast('Link copied - share it with a friend!', 'link'); }
    catch (e) {
      const t = document.createElement('textarea'); t.value = url; document.body.appendChild(t); t.select();
      try { document.execCommand('copy'); toast('Link copied!', 'link'); } catch (x) { window.Vexo.notice('Copy this link', `<input class="input" value="${esc(url)}" readonly onfocus="this.select()">`); }
      t.remove();
    }
  };

  // fullscreen (real API with pseudo-fullscreen fallback for iPad/iPhone)
  const fsBtn = document.getElementById('fs');
  const fsEl = () => document.fullscreenElement || document.webkitFullscreenElement;
  const isFs = () => !!fsEl() || pw.classList.contains('fake-fs');
  function paintFs() {
    const on = isFs();
    fsBtn.innerHTML = (on ? ICONS.shrink : ICONS.expand) + `<span class="lbl">${on ? 'Exit Fullscreen' : 'Fullscreen'}</span>`;
  }
  function fakeFs(on) { pw.classList.toggle('fake-fs', on); document.body.style.overflow = on ? 'hidden' : ''; paintFs(); }
  async function enterFs() {
    if (g.external) return; // these games play on their own site, so there is nothing here to make full screen
    if (!frame) startGame();
    const req = pw.requestFullscreen || pw.webkitRequestFullscreen;
    if (req) {
      try { await req.call(pw); } catch (e) { fakeFs(true); }
    } else fakeFs(true);
    setTimeout(() => frame && frame.focus(), 120);
  }
  function exitFs() {
    if (pw.classList.contains('fake-fs')) return fakeFs(false);
    const ex = document.exitFullscreen || document.webkitExitFullscreen;
    if (fsEl() && ex) ex.call(document);
  }
  fsBtn.onclick = () => (isFs() ? exitFs() : enterFs());
  document.getElementById('fsx').onclick = exitFs;
  document.addEventListener('fullscreenchange', paintFs);
  document.addEventListener('webkitfullscreenchange', paintFs);
  document.addEventListener('keydown', (e) => {
    if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return;
    if (e.key === 'f' || e.key === 'F') { e.preventDefault(); isFs() ? exitFs() : enterFs(); }
    if (e.key === 'Escape' && pw.classList.contains('fake-fs')) fakeFs(false);
  });
})();
