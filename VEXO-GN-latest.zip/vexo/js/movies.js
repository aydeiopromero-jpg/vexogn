/* VEXO-GN - Movies page (#/movies): the newest movies, with live countdowns and trailers.
   - The list comes from Wikipedia's "List of American films of <year>" pages (this year and next year),
     read in the browser, so it stays up to date by itself. Up to 200 movies: everything coming soon,
     plus the newest ones already out.
   - It is saved in this browser for 12 hours, so the page opens fast next time.
   - If Wikipedia can't be reached, it shows a backup list of big movies (dates checked by hand).
   - Vexo doesn't play these movies (theaters and paid streaming services do). Each one has
     a live countdown to its US release date, a "Watch trailer" button (YouTube search) and an Info link. */
(function () {
  'use strict';
  const { esc, toast } = window.Vexo;
  const MAX = 200, PAGE = 30;
  const CACHE_KEY = 'vexo_movies_cache_v1', CACHE_MS = 12 * 3600 * 1000;

  // backup list: big movies with US theater dates checked by hand (Nov 2026)
  const BACKUP = [
    ['Godzilla Minus Zero', '2026-11-06', 'Toho'],
    ['The Hunger Games: Sunrise on the Reaping', '2026-11-20', 'Lionsgate'],
    ['Hexed', '2026-11-25', 'Walt Disney Animation Studios'],
    ['Avengers: Doomsday', '2026-12-18', 'Marvel Studios'],
    ['Dune: Part Three', '2026-12-18', 'Warner Bros. Pictures'],
    ['Jumanji 3', '2026-12-25', 'Sony Pictures'],
    ['Sonic the Hedgehog 4', '2027-03-19', 'Paramount Pictures'],
    ['The Legend of Zelda', '2027-04-30', 'Sony Pictures · Nintendo'],
    ['Star Wars: Starfighter', '2027-05-28', 'Lucasfilm'],
    ['Spider-Man: Beyond the Spider-Verse', '2027-06-25', 'Sony Pictures Animation'],
    ['Shrek 5', '2027-06-30', 'DreamWorks Animation'],
    ['A Minecraft Movie 2', '2027-07-23', 'Warner Bros. Pictures'],
    ['The Batman Part II', '2027-10-01', 'Warner Bros. Pictures · DC Studios'],
    ['Frozen III', '2027-11-24', 'Walt Disney Animation Studios'],
    ['Avengers: Secret Wars', '2027-12-17', 'Marvel Studios']
  ].map(([title, date, studio]) => ({ title, date, studio, cast: '', wiki: '' }));

  /* ---------- reading Wikipedia's film lists ---------- */
  const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  const clean = (s) => String(s || '').replace(/\[[^\]]*\]/g, '').replace(/\s+/g, ' ').trim();
  function grid(table) { // spread out merged cells so every row has every column
    const g = [];
    Array.from(table.rows).forEach((tr, r) => {
      g[r] = g[r] || []; let c = 0;
      Array.from(tr.cells).forEach((cell) => {
        while (g[r][c]) c++;
        const rs = Math.min(Number(cell.rowSpan) || 1, 300), cs = Math.min(Number(cell.colSpan) || 1, 12);
        for (let i = 0; i < rs; i++) for (let j = 0; j < cs; j++) (g[r + i] = g[r + i] || [])[c + j] = cell;
        c += cs;
      });
    });
    return g;
  }
  function parseYear(html, year) {
    const doc = new DOMParser().parseFromString(html, 'text/html'), out = [];
    doc.querySelectorAll('table.wikitable').forEach((table) => {
      const g = grid(table); if (g.length < 2) return;
      const head = g[0].map((c) => clean(c && c.textContent).toLowerCase());
      const titleCol = head.findIndex((h) => h === 'title' || h.startsWith('title'));
      if (titleCol < 0) return;
      const openCol = head.findIndex((h) => h.startsWith('opening') || h.includes('release'));
      if (openCol < 0) return;
      const twoCols = head[openCol + 1] === head[openCol]; // "Opening" spread over month + day
      const studioCol = head.findIndex((h) => /production|distribut|studio/.test(h));
      const castCol = head.findIndex((h) => /cast|crew/.test(h));
      for (let r = 1; r < g.length; r++) {
        const row = g[r]; const tc = row[titleCol];
        if (!tc || tc.tagName !== 'TD' || (r > 1 && g[r - 1][titleCol] === tc)) continue;
        let mo = -1, day = NaN;
        if (twoCols) {
          const m = clean(row[openCol] && row[openCol].textContent).toLowerCase().replace(/[^a-z]/g, '');
          mo = MONTHS.indexOf(m.slice(0, 3)); day = parseInt(clean(row[openCol + 1] && row[openCol + 1].textContent), 10);
        } else {
          const t = clean(row[openCol] && row[openCol].textContent).toLowerCase();
          const m = t.match(/([a-z]{3})[a-z]*\.?\s+(\d{1,2})/) || t.match(/(\d{1,2})\s+([a-z]{3})/);
          if (m) { if (/\d/.test(m[1])) { day = parseInt(m[1], 10); mo = MONTHS.indexOf(m[2]); } else { mo = MONTHS.indexOf(m[1]); day = parseInt(m[2], 10); } }
        }
        if (mo < 0 || !(day >= 1 && day <= 31)) continue;
        const link = tc.querySelector('i a[href^="/wiki/"], a[href^="/wiki/"]');
        const title = clean((tc.querySelector('i') || tc).textContent).replace(/[\s†‡§*#]+$/, '');
        if (!title || title.length > 120) continue;
        const href = link && link.getAttribute('href');
        out.push({
          title, date: `${year}-${String(mo + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`,
          studio: studioCol >= 0 ? clean(row[studioCol] && row[studioCol].textContent).slice(0, 80) : '',
          cast: castCol >= 0 ? clean(row[castCol] && row[castCol].textContent).slice(0, 140) : '',
          wiki: href && /^\/wiki\/[^:?#]+$/.test(href) && !link.classList.contains('new') ? 'https://en.wikipedia.org' + href : ''
        });
      }
    });
    return out;
  }
  async function fetchYear(year) {
    const url = 'https://en.wikipedia.org/w/api.php?action=parse&prop=text&format=json&formatversion=2&redirects=1&origin=*&page=' + encodeURIComponent('List of American films of ' + year);
    const c = new AbortController(); const tm = setTimeout(() => c.abort(), 15000);
    try {
      const r = await fetch(url, { signal: c.signal }); if (!r.ok) throw new Error('http ' + r.status);
      const j = await r.json(); return parseYear((j.parse && j.parse.text) || '', year);
    } finally { clearTimeout(tm); }
  }

  /* ---------- the movie list ---------- */
  let all = null, source = 'backup', loading = null;
  const relAt = (m) => { const [y, mo, d] = m.date.split('-').map(Number); return new Date(y, mo - 1, d).getTime(); }; // midnight where you are
  const isOut = (m) => Date.now() >= relAt(m);
  function pick(list) { // everything coming soon, then the newest ones already out, up to 200
    const seen = new Set(), uniq = list.filter((m) => { const k = m.title.toLowerCase() + m.date; if (seen.has(k)) return false; seen.add(k); return true; });
    const soon = uniq.filter((m) => !isOut(m)).sort((a, b) => relAt(a) - relAt(b));
    const out = uniq.filter(isOut).sort((a, b) => relAt(b) - relAt(a));
    const s = soon.slice(0, MAX);
    return s.concat(out.slice(0, MAX - s.length));
  }
  function fromCache() {
    try { const c = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null'); if (c && Array.isArray(c.list) && c.list.length >= 20) return c; } catch (e) {}
    return null;
  }
  function current() {
    if (all) return all;
    const c = fromCache();
    if (c) { all = pick(c.list); source = 'wikipedia'; } else { all = pick(BACKUP); source = 'backup'; }
    return all;
  }
  function load(force) {
    if (loading) return loading;
    const c = fromCache();
    if (!force && c && Date.now() - c.at < CACHE_MS) { current(); return Promise.resolve(false); }
    const y = new Date().getFullYear();
    loading = Promise.allSettled([fetchYear(y), fetchYear(y + 1)]).then((res) => {
      const list = res.flatMap((r) => (r.status === 'fulfilled' ? r.value : []));
      loading = null;
      if (list.length < 20) return false; // couldn't read the lists: keep what we have
      try { localStorage.setItem(CACHE_KEY, JSON.stringify({ at: Date.now(), list })); } catch (e) {}
      all = pick(list); source = 'wikipedia';
      return true;
    }).catch(() => { loading = null; return false; });
    return loading;
  }
  const upcoming = () => current().filter((m) => !isOut(m)).sort((a, b) => relAt(a) - relAt(b));

  /* ---------- animated countdown ----------
     Smooth on purpose: only transform and opacity animate (the graphics card does those), the reflection is a
     mirrored copy that changes once a second instead of a live mirror, and only countdowns on screen update. */
  function parts(at) {
    let s = Math.max(0, Math.floor((at - Date.now()) / 1000));
    const d = Math.floor(s / 86400); s %= 86400; const h = Math.floor(s / 3600); s %= 3600; const m = Math.floor(s / 60); s %= 60;
    return [String(d).padStart(2, '0'), String(h).padStart(2, '0'), String(m).padStart(2, '0'), String(s).padStart(2, '0')];
  }
  const UNITS = ['DAYS', 'HRS', 'MIN', 'SEC'];
  const cells = (str) => str.split('').map((c) => `<span class="cd-dg" data-v="${c}"><i>${c}</i></span>`).join('');
  function countdown(at, size, label) {
    const p = parts(at);
    return `<div class="cd cd-${size}" data-cd="${at}" role="timer" aria-label="${esc(label || 'Countdown')}">${p.map((v, i) => `<span class="cd-cell${i === 3 ? ' is-sec' : ''}">
      <span class="cd-seg"><span class="cd-num">${cells(v)}</span><small>${UNITS[i]}</small><i class="cd-ring" aria-hidden="true"></i></span>
      <span class="cd-ref" aria-hidden="true"><span class="cd-num">${cells(v)}</span><small>${UNITS[i]}</small></span></span>`).join('')}</div>`;
  }
  const still = matchMedia('(prefers-reduced-motion: reduce)');
  const onScreen = new Set();
  const io = 'IntersectionObserver' in window ? new IntersectionObserver((list) => list.forEach((en) => {
    if (en.isIntersecting) { onScreen.add(en.target); sync(en.target, false); } else onScreen.delete(en.target);
  }), { rootMargin: '120px 0px' }) : null;
  function watchNew() {
    document.querySelectorAll('[data-cd]:not([data-w])').forEach((cd) => { cd.dataset.w = '1'; if (io) io.observe(cd); else onScreen.add(cd); });
  }
  function sync(cd, animate) {
    const at = Number(cd.dataset.cd);
    if (Date.now() >= at) { onScreen.delete(cd); if (io) io.unobserve(cd); cd.outerHTML = '<span class="up-out">OUT NOW IN THEATERS</span>'; return; }
    const p = parts(at), move = animate && !still.matches;
    const cellsEls = cd.children;
    for (let i = 0; i < cellsEls.length; i++) {
      const cell = cellsEls[i], v = p[i];
      const num = cell.firstElementChild.firstElementChild, ref = cell.lastElementChild.firstElementChild;
      const dg = num.children;
      if (dg.length !== v.length) { num.innerHTML = cells(v); ref.innerHTML = cells(v); continue; }
      let changed = false;
      for (let k = 0; k < v.length; k++) {
        const el = dg[k], c = v[k];
        if (el.dataset.v === c) continue;
        changed = true;
        const old = el.dataset.v; el.dataset.v = c;
        const r = ref.children[k]; if (r) r.firstElementChild.textContent = c;
        if (!move) { el.innerHTML = `<i>${c}</i>`; continue; }
        el.innerHTML = `<i class="o">${old}</i><i class="n">${c}</i>`;
        el.lastElementChild.addEventListener('animationend', () => { if (el.dataset.v === c) el.innerHTML = `<i>${c}</i>`; }, { once: true });
      }
      // swapping the animation name restarts the shine and ring without making the page re-measure itself
      if (i === 3 && changed && move) cell.dataset.t = cell.dataset.t === 'a' ? 'b' : 'a';
    }
  }
  function tickAll() {
    watchNew();
    if (!document.querySelector('[data-cd]')) return false;
    if (document.hidden) return true;
    onScreen.forEach((cd) => { if (!cd.isConnected) { onScreen.delete(cd); if (io) io.unobserve(cd); return; } sync(cd, true); });
    return true;
  }
  let ticking = 0;
  function startTicking() {
    watchNew();
    if (ticking) return;
    const loop = () => requestAnimationFrame(() => {
      if (!tickAll()) { ticking = 0; return; }
      ticking = setTimeout(loop, 1000 - (Date.now() % 1000) + 8);
    });
    ticking = setTimeout(loop, 1000 - (Date.now() % 1000) + 8);
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) onScreen.forEach((cd) => cd.isConnected && sync(cd, false)); });

  /* ---------- "Remind me": on release day Vexo says the movie is out ----------
     Saved in this browser. The alert shows when Vexo is open on or after release day (a browser notification
     if you allowed them, and a popup inside Vexo either way). */
  const REM_KEY = 'vexo_movie_reminders';
  const rems = () => { try { const v = JSON.parse(localStorage.getItem(REM_KEY) || '[]'); return Array.isArray(v) ? v.filter((r) => r && r.title && /^\d{4}-\d{2}-\d{2}$/.test(r.date)) : []; } catch (e) { return []; } };
  const saveRems = (l) => { try { localStorage.setItem(REM_KEY, JSON.stringify(l.slice(0, 100))); } catch (e) {} };
  const remKey = (m) => m.title + '|' + m.date;
  const isRem = (m) => rems().some((r) => remKey(r) === remKey(m));
  const BELL = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 16V11a6 6 0 0112 0v5l2 2H4z"/><path d="M10 20a2 2 0 004 0"/></svg>';
  function toggleRem(m) {
    let l = rems(); const on = !l.some((r) => remKey(r) === remKey(m));
    if (on) {
      l.push({ title: m.title, date: m.date, studio: m.studio || '', done: false });
      if ('Notification' in window && Notification.permission === 'default') { try { Notification.requestPermission(); } catch (e) {} }
      document.dispatchEvent(new CustomEvent('vexo:remind'));
    } else l = l.filter((r) => remKey(r) !== remKey(m));
    saveRems(l);
    return on;
  }
  function alertOut(r) {
    const daysAgo = Math.floor((Date.now() - relAt(r)) / 86400000);
    const head = daysAgo < 1 ? `${r.title} is out today!` : `${r.title} is out now!`;
    if ('Notification' in window && Notification.permission === 'granted') {
      try { const n = new Notification(head, { body: 'Now in theaters. Open Vexo Movies for the trailer.', tag: 'vexo-' + remKey(r) }); n.onclick = () => { window.focus(); location.hash = '#/movies'; n.close(); }; } catch (e) {}
    }
    const el = document.createElement('div'); el.className = 'rm-pop'; el.setAttribute('role', 'alert');
    el.innerHTML = `<span class="rm-ic">${BELL}</span><div class="rm-t"><b>${esc(head)}</b><small>Now in theaters${r.studio ? ' · ' + esc(r.studio) : ''}</small></div>
      <a class="up-trailer" href="${esc(trailerUrl(r))}" target="_blank" rel="noopener">Trailer</a><button type="button" class="rm-x" aria-label="Close">&times;</button>`;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('in'));
    el.querySelector('.rm-x').onclick = () => { el.classList.remove('in'); setTimeout(() => el.remove(), 300); };
  }
  function checkRems() {
    const l = rems(); let changed = false;
    l.forEach((r) => { if (!r.done && Date.now() >= relAt(r)) { r.done = true; changed = true; alertOut(r); } });
    if (changed) saveRems(l);
  }
  setTimeout(checkRems, 1500); setInterval(checkRems, 60000);

  /* ---------- the page ---------- */
  const PLAY = '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4.5v15l13-7.5z" fill="currentColor"/></svg>';
  const dayStr = (m) => new Date(relAt(m)).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
  const trailerUrl = (m) => 'https://www.youtube.com/results?search_query=' + encodeURIComponent(m.title + ' official trailer');
  let tab = 'soon', query = '', shown = PAGE;

  function card(m, big) {
    const out = isOut(m);
    return `<article class="up${big ? ' up-big' : ''}">
      <div class="up-top"><span class="up-date">${esc(dayStr(m))}</span>${m.studio ? `<span class="up-studio">${esc(m.studio)}</span>` : ''}</div>
      ${big ? '<p class="up-kicker">Next up in theaters</p>' : ''}
      <h3>${esc(m.title)}</h3>
      ${m.cast ? `<p class="up-desc">${esc(m.cast)}</p>` : '<p class="up-desc"></p>'}
      ${out ? '<span class="up-out">OUT NOW IN THEATERS</span>' : countdown(relAt(m), big ? 'lg' : 'sm', 'Time until ' + m.title + ' comes out')}
      <div class="up-btns"><a class="up-trailer" href="${esc(trailerUrl(m))}" target="_blank" rel="noopener">${PLAY}Watch trailer</a>${out ? '' : `<button type="button" class="up-remind${isRem(m) ? ' on' : ''}" data-remind="${esc(remKey(m))}" aria-pressed="${isRem(m)}">${BELL}<span>${isRem(m) ? 'Reminder set' : 'Remind me'}</span></button>`}${m.wiki ? `<a class="up-info" href="${esc(m.wiki)}" target="_blank" rel="noopener">Info</a>` : ''}</div>
    </article>`;
  }
  function filtered() {
    let l = current();
    if (tab === 'soon') l = l.filter((m) => !isOut(m)); else if (tab === 'out') l = l.filter(isOut);
    else if (tab === 'rem') { const keys = new Set(rems().map(remKey)); const have = l.filter((m) => keys.has(remKey(m))); const extra = rems().filter((r) => !have.some((m) => remKey(m) === remKey(r))); l = have.concat(extra).sort((a, b) => relAt(a) - relAt(b)); }
    const q = query.trim().toLowerCase();
    if (q) l = l.filter((m) => (m.title + ' ' + m.studio + ' ' + m.cast).toLowerCase().includes(q));
    return l;
  }
  function listHtml() {
    const l = filtered();
    if (!l.length) return `<p class="mvp-empty">${query ? `No movies match "<b>${esc(query)}</b>".` : tab === 'rem' ? 'No reminders yet. Tap <b>Remind me</b> on a movie and Vexo will tell you when it comes out.' : 'No movies here right now.'}</p>`;
    return `<div class="up-grid">${l.slice(0, shown).map((m) => card(m, false)).join('')}</div>
      ${l.length > shown ? `<button type="button" class="mvp-more" data-mv-more>Show more (${l.length - shown} left)</button>` : ''}`;
  }
  function page() {
    const list = current(), soon = list.filter((m) => !isOut(m)), next = soon[0];
    return `<div class="mvp">
      <header class="mvp-hero">
        <p class="mvp-kicker">New movies</p>
        <h1><span class="vx-logo">vexo</span> Movies</h1>
        <p class="mvp-sub">The newest movies: release dates, live countdowns and trailers.</p>
        <button type="button" class="mv-trailer" data-trailer>${PLAY}Watch the Vexo Movies trailer</button>
      </header>
      ${next ? card(next, true) : ''}
      <div class="mvp-bar">
        <div class="mvp-tabs" role="tablist">
          <button type="button" role="tab" data-mv-tab="soon" aria-selected="${tab === 'soon'}">Coming soon <small>${soon.length}</small></button>
          <button type="button" role="tab" data-mv-tab="out" aria-selected="${tab === 'out'}">Out now <small>${list.length - soon.length}</small></button>
          <button type="button" role="tab" data-mv-tab="all" aria-selected="${tab === 'all'}">All <small>${list.length}</small></button>
          <button type="button" role="tab" data-mv-tab="rem" aria-selected="${tab === 'rem'}">${BELL}Reminders <small data-rem-n>${rems().length}</small></button>
        </div>
        <input type="search" class="mvp-find" id="mvFind" placeholder="Find a movie" value="${esc(query)}" aria-label="Find a movie" autocomplete="off">
      </div>
      <div id="mvList">${listHtml()}</div>
      <p class="mvp-note" id="mvSource">${source === 'wikipedia' ? `${list.length} movies. Release dates are US theater dates from Wikipedia and can change.` : 'Loading the newest movies from Wikipedia...'} Trailers open on YouTube.</p>
    </div>`;
  }
  function paintList() { const el = document.getElementById('mvList'); if (el) { el.innerHTML = listHtml(); startTicking(); } }
  function mounted() {
    startTicking();
    load(false).then((changed) => {
      const box = document.querySelector('.mvp'); if (!box) return;
      if (changed) { box.outerHTML = page(); startTicking(); }
      else if (source !== 'wikipedia') { const n = document.getElementById('mvSource'); if (n) n.textContent = "Couldn't reach Wikipedia right now, so this is the backup list of big movies. Dates can change. Trailers open on YouTube."; }
    });
  }

  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-mv-tab]');
    if (t) { tab = t.dataset.mvTab; shown = PAGE; document.querySelectorAll('[data-mv-tab]').forEach((b) => b.setAttribute('aria-selected', String(b === t))); paintList(); return; }
    if (e.target.closest('[data-mv-more]')) { shown += PAGE; paintList(); return; }
    const rb = e.target.closest('[data-remind]');
    if (rb) {
      const [title, date] = rb.dataset.remind.split('|');
      const m = current().find((x) => x.title === title && x.date === date) || rems().find((x) => x.title === title && x.date === date) || { title, date };
      const on = toggleRem(m);
      document.querySelectorAll('[data-remind]').forEach((b) => { if (b.dataset.remind === rb.dataset.remind) { b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); b.querySelector('span').textContent = on ? 'Reminder set' : 'Remind me'; } });
      document.querySelectorAll('[data-rem-n]').forEach((n) => { n.textContent = rems().length; });
      toast(on ? `Reminder set. Vexo will tell you when ${title} comes out on ${new Date(relAt(m)).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}.` : 'Reminder removed');
      if (tab === 'rem' && !on) paintList();
    }
  });
  let findT = 0;
  document.addEventListener('input', (e) => {
    if (e.target.id !== 'mvFind') return;
    clearTimeout(findT); findT = setTimeout(() => { query = e.target.value; shown = PAGE; paintList(); }, 150);
  });

  window.VexoMovies = { page, mounted, list: () => current().slice(), upcoming, load, countdown, startTicking, close() {}, parseYear, reminders: rems, checkReminders: checkRems };
})();
