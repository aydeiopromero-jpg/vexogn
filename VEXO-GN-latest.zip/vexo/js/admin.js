/* VEXO-GN - admin: add, edit, hide, feature, delete, import/export games */
(function () {
  'use strict';
  const { ask, notice, dialog, Store, ICONS, CAT_COLORS, catIcon, esc, slug, shell, thumbOf, autoThumb, toast, hash } = window.Vexo;
  const view = document.getElementById('view'), modal = document.getElementById('modal');
  const CATS = window.VEXO_CATEGORIES || [];
  const today = () => new Date().toISOString().slice(0, 10);
  const pinHash = (p) => 'h' + hash('vexo-gn::' + p) + '_' + hash(p + '::salt').toString(36);
  let filter = { q: '', cat: '' };

  shell('admin');

  /* ---------------- PIN gate ---------------- */
  const unlocked = () => { try { return sessionStorage.getItem('vexo_admin_ok') === '1'; } catch (e) { return false; } };
  const setUnlocked = (v) => { try { v ? sessionStorage.setItem('vexo_admin_ok', '1') : sessionStorage.removeItem('vexo_admin_ok'); } catch (e) {} };
  // the home page shows event previews and an edit button only in the owner's browser
  const unlocked0 = unlocked();
  if (unlocked0) Store.LS.set('vexo_owner', true);
  const setOwner = (v) => { v ? Store.LS.set('vexo_owner', true) : Store.LS.del('vexo_owner'); };

  function gate() {
    const has = !!Store.LS.get(Store.KEYS.pin, null);
    view.innerHTML = `<div class="gate"><div class="panel">
      ${ICONS.lock.replace('class="ic"', 'class="ic big"')}
      <h1>${has ? 'Admin Login' : 'Set up Admin PIN'}</h1>
      <p>${has ? 'Enter your admin PIN to manage games.' : 'Create a PIN to lock the admin page on this device. You will need it next time.'}</p>
      <form id="gateForm">
        <input class="input pin" type="password" inputmode="numeric" autocomplete="${has ? 'current-password' : 'new-password'}" id="pin1" placeholder="PIN" minlength="4" maxlength="12" required aria-label="PIN">
        ${has ? '' : '<input class="input pin" type="password" inputmode="numeric" autocomplete="new-password" id="pin2" placeholder="Confirm" minlength="4" maxlength="12" required aria-label="Confirm PIN">'}
        <div class="err" id="gateErr"></div>
        <button class="btn primary big" type="submit">${has ? ICONS.lock + 'Unlock' : ICONS.plus + 'Create PIN'}</button>
      </form>
      <p style="margin-top:14px;font-size:12px">This PIN only locks the page in this browser. For real protection, put admin.html behind your web host's password protection.</p>
    </div></div>`;
    const f = document.getElementById('gateForm'), err = document.getElementById('gateErr');
    document.getElementById('pin1').focus();
    f.onsubmit = (e) => {
      e.preventDefault();
      const p1 = document.getElementById('pin1').value.trim();
      if (p1.length < 4) { err.textContent = 'PIN must be at least 4 characters.'; return; }
      if (!has) {
        if (p1 !== document.getElementById('pin2').value.trim()) { err.textContent = 'PINs do not match.'; return; }
        Store.LS.set(Store.KEYS.pin, pinHash(p1)); setUnlocked(true); setOwner(true); toast('Admin PIN created'); render();
      } else if (Store.LS.get(Store.KEYS.pin) === pinHash(p1)) { setUnlocked(true); setOwner(true); render(); }
      else { err.textContent = 'Wrong PIN. Try again.'; document.getElementById('pin1').select(); }
    };
  }

  /* ---------------- dashboard ---------------- */
  let scrolledToEvent = false;
  function render(opts) {
    if (!unlocked()) return gate();
    const keepEv = !(opts && opts.newEvent) && view.querySelector('#event');
    const all = Store.allGames();
    const visible = all.filter((g) => !g.hidden).length, featured = all.filter((g) => g.featured && !g.hidden).length;
    const defaults = new Set((window.VEXO_DEFAULT_GAMES || []).map((g) => g.id));
    const custom = all.filter((g) => !defaults.has(g.id)).length;
    const q = filter.q.toLowerCase();
    const rows = all.filter((g) => (!q || (g.title + ' ' + g.id + ' ' + (g.categories || []).join(' ')).toLowerCase().includes(q)) && (!filter.cat || (g.categories || []).includes(filter.cat)));

    view.innerHTML = `
      <div class="page-head"><h1>${ICONS.gear}Admin Dashboard</h1>
        <div class="tools"><button class="btn primary" data-act="add">${ICONS.plus}Add Game</button><button class="btn" data-act="lock">${ICONS.lock}Lock</button></div>
        <p>Add, edit, feature, hide and remove games on VEXO-GN.</p></div>
      <div class="notice">${ICONS.eye}<div>Changes save instantly <b>in this browser</b>, and you can preview them right away. To publish them for <b>every visitor</b>, click <b>Export data.js</b> below and replace <code>js/data.js</code> on your web host with the downloaded file.${Store.isCustomized() || evDraft() ? ' <b style="color:var(--cyan)">You have unpublished local changes.</b>' : ''}</div></div>
      <div class="admin-grid">
        <div class="stat"><b>${all.length}</b><span>Total games</span></div>
        <div class="stat"><b>${visible}</b><span>Visible on site</span></div>
        <div class="stat"><b>${featured}</b><span>Featured</span></div>
        <div class="stat"><b>${custom}</b><span>Added by you</span></div>
      </div>
      <div class="page-head" style="margin-bottom:12px">
        <input class="input" style="max-width:320px" type="search" placeholder="Filter games..." value="${esc(filter.q)}" data-filter="q" aria-label="Filter games">
        <select class="select" data-filter="cat" aria-label="Filter by category"><option value="">All categories</option>${CATS.map((c) => `<option${filter.cat === c ? ' selected' : ''}>${esc(c)}</option>`).join('')}</select>
        <span style="color:var(--muted);font-size:13px">${rows.length} shown</span>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>Game</th><th>Categories</th><th>Popularity</th><th>Added</th><th>Featured</th><th>Visible</th><th style="text-align:right">Actions</th></tr></thead>
        <tbody>${rows.length ? rows.map(row).join('') : `<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:30px">No games match.</td></tr>`}</tbody>
      </table></div>
      <section class="section" style="margin-top:26px">
        <div class="sec-head"><h2>${ICONS.download}Import / Export &amp; Tools</h2></div>
        <div class="panel"><div class="row-flex">
          <button class="btn primary" data-act="export-js">${ICONS.download}Export data.js</button>
          <button class="btn" data-act="export-json">${ICONS.download}Export JSON backup</button>
          <button class="btn primary" data-act="network">${ICONS.plus}Import games from a game network</button>
          <button class="btn danger" data-act="drop-links">${ICONS.trash}Remove games that open another site</button>
          <button class="btn" data-act="import">${ICONS.upload}Import JSON</button>
          <button class="btn" data-act="pin">${ICONS.lock}Change PIN</button>
          <button class="btn danger" data-act="clear-player">${ICONS.trash}Clear my player data</button>
          <button class="btn danger" data-act="reset">${ICONS.refresh}Reset games to defaults</button>
        </div>
        <p style="margin:14px 0 0;font-size:13px;color:var(--dim)">Only add games you made or have permission to embed, such as embed links that developers provide on itch.io, other HTML5 games offered for embedding, or your own games uploaded to your site.</p></div>
      </section>`;
    if (keepEv) view.querySelector('#event').replaceWith(keepEv);
    if (!scrolledToEvent && location.hash === '#event') { scrolledToEvent = true; document.getElementById('event').scrollIntoView(); }
  }
  function row(g) {
    return `<tr data-id="${esc(g.id)}">
      <td class="g"><img src="${esc(thumbOf(g))}" alt="" data-fallback="${esc(autoThumb(g.title))}"><span><b>${esc(g.title)}</b><small>${esc(g.id)}</small></span></td>
      <td><div class="tags">${(g.categories || []).map((c) => `<span class="tag" style="--c:${CAT_COLORS[c] || '#a855f7'}">${esc(c)}</span>`).join('')}</div></td>
      <td>${Number(g.popularity) || 0}</td>
      <td style="white-space:nowrap">${esc(g.added || '-')}</td>
      <td><label class="switch" title="Featured on homepage"><input type="checkbox" data-toggle="featured"${g.featured ? ' checked' : ''} aria-label="Featured"><i></i></label></td>
      <td><label class="switch" title="Visible on site"><input type="checkbox" data-toggle="visible"${!g.hidden ? ' checked' : ''} aria-label="Visible"><i></i></label></td>
      <td><div class="acts-cell">
        <a class="icon-btn" href="play.html?id=${encodeURIComponent(g.id)}" target="_blank" rel="noopener" title="Preview">${ICONS.play}</a>
        <button class="icon-btn" data-act="edit" title="Edit">${ICONS.edit}</button>
        <button class="icon-btn del" data-act="delete" title="Delete">${ICONS.trash}</button>
      </div></td></tr>`;
  }

  function save(list, msg) {
    if (!Store.saveGames(list)) { notice('Could not save', 'Browser storage is full. Use image links instead of uploaded thumbnails, or remove some games.'); return false; }
    if (msg) toast(msg);
    render();
    return true;
  }

  /* ---------------- live event (only the owner sets it; visitors only watch) ---------------- */
  const EV_DRAFT = 'vexo_event_draft';
  const FX_NAMES = [['blackhole', 'Black Hole'], ['meteor', 'Meteor Strike'], ['rift', 'The Rift'], ['glitch', 'System Glitch'], ['freeze', 'Deep Freeze']];
  const fxLabel = (t) => (FX_NAMES.find((x) => x[0] === t) || FX_NAMES[0])[1];
  const published = () => window.VEXO_EVENT || null;
  // a saved but unpublished event in this browser (cleared once data.js has the same event)
  function evDraft() {
    const d = Store.LS.get(EV_DRAFT, null);
    if (!d || typeof d !== 'object' || !('event' in d)) return null;
    if (JSON.stringify(d.event) === JSON.stringify(published())) { Store.LS.del(EV_DRAFT); return null; }
    return d;
  }
  const evNow = () => { const d = evDraft(); return d ? d.event : published(); };
  const isDateEv = (ev) => !!(ev && ev.at && !isNaN(Date.parse(ev.at)));
  const pad2 = (n) => String(n).padStart(2, '0');
  const toLocalInput = (t) => { const d = new Date(t); return isNaN(d) ? '' : `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}T${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };
  function evSummary(ev) {
    const live = Number(ev && ev.liveMinutes) || 10;
    if (isDateEv(ev)) {
      const g = Store.allGames().find((x) => x.id === ev.gameId);
      const when = new Date(ev.at).toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
      const over = Date.parse(ev.at) + live * 60000 < Date.now();
      return `<b>${esc(ev.title || fxLabel(ev.fx))}</b> (${esc(fxLabel(ev.fx))})${g ? ' with ' + esc(g.title) : ''} on ${esc(when)}, live for ${live} minutes.` +
        (over ? ' <b style="color:#f59e0b">This event is over, so visitors see "Event over" until you set a new one.</b>' : '');
    }
    const c = Number(ev && ev.minutes) || 23;
    return `Automatic events: a ${c}-minute countdown, then ${live} minutes live, over and over. Each one uses the next effect and the next featured or trending game.`;
  }
  function eventPanel() {
    const ev = evNow(), d = evDraft(), isDate = isDateEv(ev);
    const games = Store.allGames().filter((g) => !g.hidden).sort((a, b) => a.title.localeCompare(b.title));
    const gid = (isDate && ev.gameId) || ((games.find((g) => g.featured) || games[0] || {}).id);
    const hideIf = (m) => ((m === 'date') !== isDate ? ' hidden' : '');
    return `<div class="sec-head"><h2>${ICONS.clock}Live event</h2></div>
      <div class="panel">
        <p>${d ? 'In this browser only: ' : 'Visitors see: '}${evSummary(ev)}${d ? ' <b style="color:var(--cyan)">Not published yet.</b>' : ''}</p>
        <form id="evForm" novalidate style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px 14px">
          <div class="field full"><label for="evMode">When</label><select class="select" id="evMode">
            <option value="auto"${isDate ? '' : ' selected'}>Automatic, over and over all day</option>
            <option value="date"${isDate ? ' selected' : ''}>One event at a date and time I pick</option></select></div>
          <div class="field" data-evmode="date"${hideIf('date')}><label for="evFx">Event type</label><select class="select" id="evFx">${FX_NAMES.map(([t, n]) => `<option value="${t}"${isDate && ev.fx === t ? ' selected' : ''}>${n}</option>`).join('')}</select></div>
          <div class="field" data-evmode="date"${hideIf('date')}><label for="evName">Event name</label><input class="input" id="evName" maxlength="40" value="${esc(isDate ? ev.title || '' : '')}" placeholder="Same as the event type"></div>
          <div class="field" data-evmode="date"${hideIf('date')}><label for="evGame">Game</label><select class="select" id="evGame">${games.map((g) => `<option value="${esc(g.id)}"${g.id === gid ? ' selected' : ''}>${esc(g.title)}</option>`).join('')}</select></div>
          <div class="field" data-evmode="date"${hideIf('date')}><label for="evAt">Starts</label><input class="input" type="datetime-local" id="evAt" value="${isDate ? toLocalInput(ev.at) : ''}"></div>
          <div class="field" data-evmode="auto"${hideIf('auto')}><label for="evCount">Countdown (minutes)</label><input class="input" type="number" id="evCount" min="1" max="1440" step="1" value="${isDate ? 23 : Number(ev && ev.minutes) || 23}"></div>
          <div class="field"><label for="evLive">Live for (minutes)</label><input class="input" type="number" id="evLive" min="1" max="1440" step="1" value="${Number(ev && ev.liveMinutes) || 10}"></div>
          <div class="err" id="evErr" role="alert"></div>
          <div class="row-flex" style="grid-column:1/-1">
            <button type="submit" class="btn primary">Save event</button>
            <a class="btn" href="index.html" target="_blank" rel="noopener">See it on the home page</a>
            ${d ? '<button type="button" class="btn" data-act="ev-undo">Undo my changes</button>' : ''}
          </div>
        </form>
        <p style="margin:14px 0 0;font-size:13px;color:var(--dim)">Saving changes the event in this browser only, so you can check it first. To show it to every visitor, click <b>Export data.js</b> below and replace <code>js/data.js</code> on your web host. Visitors can only watch events: they can't start, change or preview them.</p>
      </div>`;
  }
  function saveEvent(form) {
    const $ = (sel) => form.querySelector(sel), err = $('#evErr');
    err.textContent = '';
    const okMin = (v) => Number.isInteger(+v) && +v >= 1 && +v <= 1440;
    const live = $('#evLive').value;
    if (!okMin(live)) { err.textContent = 'Live for: pick a whole number of minutes from 1 to 1440.'; return; }
    let ev;
    if ($('#evMode').value === 'date') {
      const t = $('#evAt').value ? new Date($('#evAt').value).getTime() : NaN;
      if (isNaN(t)) { err.textContent = 'Pick the date and time the event starts.'; return; }
      if (t + live * 60000 < Date.now()) { err.textContent = 'That event would already be over. Pick a later time.'; return; }
      if (!$('#evGame').value) { err.textContent = 'Pick a game for the event.'; return; }
      ev = { title: $('#evName').value.trim().slice(0, 40) || fxLabel($('#evFx').value), fx: $('#evFx').value, gameId: $('#evGame').value, at: new Date(t).toISOString(), liveMinutes: +live };
    } else {
      const c = $('#evCount').value;
      if (!okMin(c)) { err.textContent = 'Countdown: pick a whole number of minutes from 1 to 1440.'; return; }
      ev = +c === 23 && +live === 10 ? null : { auto: true, minutes: +c, liveMinutes: +live };
    }
    if (JSON.stringify(ev) === JSON.stringify(published())) Store.LS.del(EV_DRAFT);
    else if (!Store.LS.set(EV_DRAFT, { event: ev })) { notice('Could not save', 'Browser storage is full.'); return; }
    toast(evDraft() ? 'Event saved in this browser. Export data.js to publish it.' : 'Event matches what is published');
    render({ newEvent: true });
  }
  view.addEventListener('submit', (e) => { if (e.target.id === 'evForm') { e.preventDefault(); saveEvent(e.target); } });

  /* ---------------- events ---------------- */
  view.addEventListener('input', (e) => {
    const f = e.target.dataset.filter;
    if (f === 'q') {
      filter.q = e.target.value; const pos = e.target.selectionStart; render();
      const inp = view.querySelector('[data-filter="q"]'); inp.focus(); try { inp.setSelectionRange(pos, pos); } catch (x) {}
    }
  });
  view.addEventListener('change', (e) => {
    if (e.target.id === 'evMode') { view.querySelectorAll('[data-evmode]').forEach((el) => (el.hidden = el.dataset.evmode !== e.target.value)); return; }
    if (e.target.dataset.filter === 'cat') { filter.cat = e.target.value; render(); return; }
    const t = e.target.dataset.toggle; if (!t) return;
    const id = e.target.closest('tr').dataset.id, list = Store.allGames(), g = list.find((x) => x.id === id);
    if (!g) return;
    if (t === 'featured') g.featured = e.target.checked;
    if (t === 'visible') g.hidden = !e.target.checked;
    save(list, `${g.title}: ${t === 'featured' ? (g.featured ? 'featured' : 'not featured') : (g.hidden ? 'hidden' : 'visible')}`);
  });
  view.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const act = b.dataset.act, tr = b.closest('tr'), id = tr && tr.dataset.id;
    if (act === 'add') openEditor(null);
    else if (act === 'edit') openEditor(id);
    else if (act === 'delete') {
      const list = Store.allGames(), g = list.find((x) => x.id === id);
      if (g) ask(`Delete ${g.title}?`, 'This removes the game from the site in this browser.', 'Delete game').then((ok) => ok && save(list.filter((x) => x.id !== id), `Deleted ${g.title}`));
    }
    else if (act === 'lock') { setUnlocked(false); setOwner(false); gate(); }
    else if (act === 'export-js') exportJs();
    else if (act === 'export-json') download('vexo-games-backup-' + today() + '.json', JSON.stringify({ app: 'VEXO-GN', exported: new Date().toISOString(), games: Store.allGames() }, null, 2), 'application/json');
    else if (act === 'import') document.getElementById('importFile').click();
    else if (act === 'network') networkImport();
    else if (act === 'drop-links') {
      const list = Store.allGames(), keep = list.filter((g) => !g.external);
      ask('Remove ' + (list.length - keep.length) + ' games?', 'This removes every game that opens on another site from this browser.', 'Remove games').then((ok) => ok && save(keep, 'Removed games that open another site'));
    }
    else if (act === 'reset') { ask('Reset games to defaults?', 'Games you added or edited in this browser will be lost. Export a backup first if you need them.', 'Reset games').then((ok) => { if (ok) { Store.resetGames(); toast('Games reset to defaults'); render(); } }); }
    else if (act === 'clear-player') {
      ask('Clear player data?', 'This clears favorites, recently played, play counts and saved high scores on this device.', 'Clear data').then((ok) => { if (!ok) return;
        [Store.KEYS.favs, Store.KEYS.recent, Store.KEYS.plays].forEach((k) => Store.LS.del(k));
        try { Object.keys(localStorage).filter((k) => k.startsWith('vexo_best_')).forEach((k) => localStorage.removeItem(k)); } catch (x) {}
        document.dispatchEvent(new CustomEvent('vexo:favs')); toast('Player data cleared');
      });
    }
    else if (act === 'ev-undo') { Store.LS.del(EV_DRAFT); toast('Back to the published event'); render({ newEvent: true }); }
    else if (act === 'pin') {
      dialog({ title: 'Change admin PIN', ok: 'Save PIN', fields: [
        { label: 'New PIN', type: 'password', attrs: 'minlength="4" maxlength="12" autocomplete="new-password"', check: (v) => (v.trim().length < 4 ? 'PIN must be at least 4 characters.' : '') },
        { label: 'Confirm new PIN', type: 'password', attrs: 'maxlength="12" autocomplete="new-password"', check: (v, all) => (v !== all[0] ? 'The two PINs do not match.' : '') }
      ] }).then((vals) => { if (vals) { Store.LS.set(Store.KEYS.pin, pinHash(vals[0].trim())); toast('PIN changed'); } });
    }
  });

  document.getElementById('importFile').addEventListener('change', (e) => {
    const file = e.target.files[0]; e.target.value = '';
    if (!file) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const data = JSON.parse(r.result), list = Array.isArray(data) ? data : data.games;
        if (!Array.isArray(list)) throw new Error('No games array found');
        const clean = list.filter((g) => g && g.id && g.title && g.url).map((g) => ({ ...g, id: slug(g.id), categories: (g.categories || []).filter((c) => CATS.includes(c)) }));
        if (!clean.length) throw new Error('No valid games (each needs id, title and url)');
        ask(`Import ${clean.length} games?`, 'This replaces the current game list in this browser.', 'Import', false).then((ok) => ok && save(clean, `Imported ${clean.length} games`));
      } catch (err) { notice('Import failed', esc(err.message) + '. Choose a JSON file exported from this admin page.'); }
    };
    r.readAsText(file);
  });

  /* ---------- import from a game network feed (GameMonetize, GameDistribution, ...) ---------- */
  const CAT_WORDS = [['Racing', /rac|car|drift|moto|bike|kart|driv/i], ['Sports', /sport|soccer|football|basket|golf|tennis|ball|hockey|baseball|bowling/i],
    ['Puzzle', /puzzle|match|logic|brain|word|mahjong|sudoku|quiz|merge|block/i], ['Adventure', /adventure|rpg|escape|quest|explor/i],
    ['2 Player', /2 ?player|two ?player|2p\b/i], ['Multiplayer', /multiplayer|\.io\b|io games/i],
    ['Action', /action|shoot|fight|war|battle|gun|zombie|sniper|stickman/i], ['Arcade', /arcade|casual|clicker|hypercasual|runner|jump/i]];
  function feedItems(text) {
    text = String(text || '').trim();
    if (!text) return [];
    if (text[0] === '<') {
      const xml = new DOMParser().parseFromString(text, 'text/xml');
      return [...xml.querySelectorAll('item, game')].map((it) => {
        const o = {}; [...it.children].forEach((c) => { const k = c.localName; const v = c.getAttribute('url') || c.textContent; if (!(k in o)) o[k] = v; }); return o;
      });
    }
    let data = JSON.parse(text);
    if (!Array.isArray(data)) data = data.items || data.games || data.data || data.result || (data.channel && data.channel.item) || Object.values(data);
    return Array.isArray(data) ? data : [];
  }
  function fromFeed(it) {
    const pick = (...ks) => { for (const k of ks) { const v = it[k]; if (v != null && v !== '' && !(Array.isArray(v) && !v.length)) return v; } return ''; };
    const title = String(pick('title', 'Title', 'name', 'Name')).trim();
    let url = String(pick('url', 'Url', 'URL', 'embed', 'Embed', 'embedUrl', 'gameURL', 'game_url', 'link', 'Link')).trim();
    const md5 = pick('Md5', 'md5'); if ((!url || !/^https:\/\//.test(url)) && md5) url = 'https://html5.gamedistribution.com/' + md5 + '/';
    let thumb = pick('thumb', 'Thumb', 'thumbnail', 'Thumbnail', 'image', 'Image', 'icon', 'Icon', 'banner_image', 'Asset', 'assets', 'Assets');
    if (Array.isArray(thumb)) thumb = thumb.find((a) => /512x512|512x384|\.(png|jpe?g|webp)/i.test(a)) || thumb[0];
    thumb = String(thumb || '').trim();
    const catText = [].concat(pick('category', 'Category', 'categories', 'Categories', 'genre')).concat(pick('tags', 'Tag', 'Tags')).join(' ');
    let cats = CAT_WORDS.filter(([, rx]) => rx.test(catText + ' ' + title)).map(([c]) => c).slice(0, 2);
    if (!cats.length) cats = ['Arcade'];
    const w = Number(pick('width', 'Width')), h = Number(pick('height', 'Height'));
    const r = w && h ? w / h : 16 / 9;
    const aspect = r > 1.6 ? '16:9' : r > 1.4 ? '3:2' : r > 1.15 ? '4:3' : r > 0.85 ? '1:1' : r > 0.65 ? '3:4' : '9:16';
    const clean = (s) => String(s || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    return { title, url, thumb: /^https:\/\//.test(thumb) ? thumb : '', categories: cats, aspect,
      description: clean(pick('description', 'Description')).slice(0, 400), controls: clean(pick('instructions', 'Instructions', 'controls')).slice(0, 300) };
  }
  function networkImport() {
    let pasted = '';
    dialog({ title: 'Import games from a game network', ok: 'Import games', cancel: 'Cancel',
      text: 'Game networks like <b>GameMonetize</b> and <b>GameDistribution</b> give websites official feeds of games to embed, with icons. Paste the feed link they give you, or paste the feed text itself.',
      fields: [{ label: 'Feed link (https://...)', attrs: 'placeholder="https://..."' }],
      body: '<div class="field"><label for="feedText">Or paste the feed text (JSON or RSS)</label><textarea class="input" id="feedText" style="min-height:120px;font-family:ui-monospace,Consolas,monospace;font-size:12px"></textarea></div>' }).then(async (vals) => {
      if (!vals) return;
      let text = pasted;
      const link = (vals[0] || '').trim();
      try {
        if (!text && link) {
          if (!/^https:\/\//i.test(link)) throw new Error('The feed link must start with https://');
          const res = await fetch(link); if (!res.ok) throw new Error('The feed returned error ' + res.status);
          text = await res.text();
        }
        const items = feedItems(text).map(fromFeed).filter((g) => g.title && /^https:\/\//.test(g.url));
        if (!items.length) throw new Error('No games with an https game link were found in that feed');
        const list = Store.allGames(), have = new Set(list.map((g) => g.url));
        const add = []; const ids = new Set(list.map((g) => g.id));
        for (const g of items) {
          if (have.has(g.url)) continue;
          let id = 'n-' + slug(g.title); while (ids.has(id)) id += '-2'; ids.add(id);
          add.push({ id, ...g, embed: true, featured: false, popularity: 60, added: today(), author: 'Game network', license: 'Official embed from the feed' });
        }
        save(add.concat(list), 'Imported ' + add.length + ' games');
      } catch (err) {
        notice('Import failed', esc(err.message) + '.<br><br>If the feed link is blocked by your browser, open the link yourself, copy everything on the page, and paste it into the feed text box instead.');
      }
    });
    setTimeout(() => {
      const t = document.getElementById('feedText'); const f = document.querySelector('.vx-dialog form');
      if (t) t.addEventListener('input', () => { pasted = t.value; });
      if (t && f) f.querySelector('.modal-body').insertBefore(t.parentNode, f.querySelector('.err'));
    }, 0);
  }

  function download(name, text, type) {
    dialog({ title: 'Export ' + name, ok: 'Download file', cancel: 'Close',
      text: 'Click <b>Download file</b>, or copy the text below and save it as <b>' + esc(name) + '</b>.',
      body: `<textarea class="input" readonly style="min-height:180px;font-family:ui-monospace,Consolas,monospace;font-size:12px">${esc(text)}</textarea><button type="button" class="btn" data-copy>${ICONS.link}Copy text</button>` });
    setTimeout(() => {
      const box = document.querySelector('.vx-dialog'); if (!box) return;
      box.querySelector('[data-copy]').onclick = async () => {
        const ta = box.querySelector('textarea');
        try { await navigator.clipboard.writeText(text); toast('Copied to clipboard'); } catch (e) { ta.focus(); ta.select(); toast('Text selected - press Ctrl+C to copy'); }
      };
      box.querySelector('form').addEventListener('submit', () => saveFile(name, text, type), { capture: true });
    }, 0);
  }
  function saveFile(name, text, type) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }
  function exportJs() {
    const js = `/* VEXO-GN - game catalog (exported from admin on ${today()}).\n   Replace js/data.js on your site with this file to publish changes for all visitors. */\n` +
      `window.VEXO_EVENT = ${JSON.stringify(evNow())};\n\n` +
      `window.VEXO_CATEGORIES = ${JSON.stringify(CATS)};\n\nwindow.VEXO_DEFAULT_GAMES = ${JSON.stringify(Store.allGames(), null, 2)};\n`;
    download('data.js', js, 'text/javascript');
  }

  /* ---------------- editor modal ---------------- */
  function openEditor(id) {
    const list = Store.allGames();
    const g = id ? list.find((x) => x.id === id) : { id: '', title: '', categories: [], description: '', controls: '', thumb: '', url: '', aspect: '16:9', featured: false, popularity: 50, added: today() };
    if (!g) return;
    let thumb = g.thumb || '';
    modal.innerHTML = `<form class="modal-box" id="edForm" novalidate>
      <div class="modal-head"><h2 id="mTitle">${id ? 'Edit Game' : 'Add New Game'}</h2><button type="button" class="icon-btn" data-close aria-label="Close">${ICONS.x}</button></div>
      <div class="modal-body">
        <div class="field"><label for="fTitle">Title *</label><input class="input" id="fTitle" value="${esc(g.title)}" maxlength="60" required></div>
        <div class="field"><label for="fId">ID (used in the link)</label><input class="input" id="fId" value="${esc(g.id)}" ${id ? 'readonly title="ID cannot change after creation"' : ''} placeholder="auto from title" maxlength="60"><span class="hint">play.html?id=<b id="idPrev">${esc(g.id || 'your-game')}</b></span></div>
        <div class="field full"><span class="lbl">Categories * (pick one or more)</span><div class="checks">${CATS.map((c) => `<label class="check"><input type="checkbox" value="${esc(c)}"${(g.categories || []).includes(c) ? ' checked' : ''}><span style="color:${CAT_COLORS[c]}">${catIcon(c)}</span>${esc(c)}</label>`).join('')}</div></div>
        <div class="field full"><label for="fUrl">Game URL or embed code *</label><input class="input" id="fUrl" value="${esc(g.url)}" placeholder="games/my-game/index.html  or  https://...  or paste <iframe ...> code"><span class="hint">Use a link to your own HTML5 game or an embed link you have permission to use. Pasting a full &lt;iframe&gt; code works too.</span></div>
        <div class="field full"><label for="fDesc">Description</label><textarea class="input" id="fDesc" maxlength="600" placeholder="What is the game about?">${esc(g.description)}</textarea></div>
        <div class="field full"><label for="fCtl">Controls / How to play</label><input class="input" id="fCtl" value="${esc(g.controls)}" maxlength="200" placeholder="Arrow keys to move · Space to jump"></div>
        <div class="field"><label for="fAuthor">Made by (credit)</label><input class="input" id="fAuthor" value="${esc(g.author || '')}" maxlength="80" placeholder="Developer or studio name"></div>
        <div class="field"><label for="fLic">License / permission</label><input class="input" id="fLic" value="${esc(g.license || '')}" maxlength="60" placeholder="e.g. MIT, official embed"></div>
        <div class="field full"><label for="fSrc">Source or developer page (https://)</label><input class="input" id="fSrc" value="${esc(g.source || '')}" maxlength="300" placeholder="https://github.com/... or the developer's page"></div>
        <div class="field full"><span class="lbl">Thumbnail</span><div class="thumb-edit"><img id="tPrev" src="${esc(thumb || autoThumb(g.title))}" alt="Thumbnail preview">
          <div class="stack"><input class="input" id="fThumb" value="${esc(thumb.startsWith('data:') ? '' : thumb)}" placeholder="Image URL (square looks best, e.g. 400×400)">
          <div class="row-flex"><label class="btn" style="cursor:pointer">${ICONS.upload}Upload image<input type="file" id="fFile" accept="image/*" hidden></label><button type="button" class="btn" id="tAuto">${ICONS.spark}Auto-generate</button></div>
          <span class="hint">Uploaded images are cropped to a 400×400 square and stored with the game.</span></div></div></div>
        <div class="field"><label for="fAspect">Player shape</label><select class="select" id="fAspect">${['16:9', '4:3', '3:2', '1:1', '3:4', '9:16'].map((a) => `<option${g.aspect === a ? ' selected' : ''}>${a}</option>`).join('')}</select></div>
        <div class="field"><label for="fAdded">Date added</label><input class="input" type="date" id="fAdded" value="${esc(g.added || today())}"></div>
        <div class="field"><label for="fPop">Popularity: <b id="popVal">${Number(g.popularity) || 0}</b></label><input type="range" id="fPop" min="0" max="100" value="${Number(g.popularity) || 0}" style="accent-color:#a855f7"><span class="hint">Higher = shows earlier in Popular Games</span></div>
        <div class="field"><span class="lbl">Options</span><div class="checks"><label class="check"><input type="checkbox" id="fFeat"${g.featured ? ' checked' : ''}>${ICONS.star}Featured</label><label class="check"><input type="checkbox" id="fVis"${!g.hidden ? ' checked' : ''}>${ICONS.eye}Visible</label></div></div>
        <div class="err" id="edErr" role="alert"></div>
      </div>
      <div class="modal-foot"><button type="button" class="btn" data-close>Cancel</button><button type="submit" class="btn primary">${ICONS.plus}${id ? 'Save Changes' : 'Add Game'}</button></div>
    </form>`;
    modal.classList.add('open');
    const $ = (s) => modal.querySelector(s);
    $('#fTitle').focus();
    const updIdPrev = () => { $('#idPrev').textContent = slug($('#fId').value || $('#fTitle').value) || 'your-game'; };
    $('#fTitle').addEventListener('input', () => { updIdPrev(); if (!thumb) $('#tPrev').src = autoThumb($('#fTitle').value); });
    $('#fId').addEventListener('input', updIdPrev);
    $('#fPop').addEventListener('input', () => ($('#popVal').textContent = $('#fPop').value));
    $('#fThumb').addEventListener('change', () => { thumb = $('#fThumb').value.trim(); $('#tPrev').src = thumb || autoThumb($('#fTitle').value); });
    $('#tPrev').addEventListener('error', () => { $('#tPrev').src = autoThumb($('#fTitle').value); $('#edErr').textContent = thumb ? 'That thumbnail could not be loaded - check the URL.' : ''; });
    $('#tAuto').onclick = () => { thumb = ''; $('#fThumb').value = ''; $('#tPrev').src = autoThumb($('#fTitle').value); };
    $('#fUrl').addEventListener('change', () => {
      const v = $('#fUrl').value;
      const m = v.match(/<iframe[^>]*\ssrc\s*=\s*["']([^"']+)["']/i);
      if (m) { $('#fUrl').value = m[1]; const w = v.match(/width\s*=\s*["']?(\d+)/i), h = v.match(/height\s*=\s*["']?(\d+)/i); if (w && h) { const r = w[1] / h[1]; $('#fAspect').value = r > 1.6 ? '16:9' : r > 1.4 ? '3:2' : r > 1.15 ? '4:3' : r > 0.8 ? '1:1' : '9:16'; } toast('Embed code detected - link extracted'); }
    });
    $('#fFile').addEventListener('change', (e) => {
      const file = e.target.files[0]; if (!file) return;
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => {
        const c = document.createElement('canvas'); c.width = 400; c.height = 400;
        const s = Math.max(400 / img.width, 400 / img.height), w = img.width * s, h = img.height * s;
        const cx = c.getContext('2d'); cx.fillStyle = '#0d0b24'; cx.fillRect(0, 0, 400, 400); cx.drawImage(img, (400 - w) / 2, (400 - h) / 2, w, h);
        thumb = c.toDataURL('image/jpeg', 0.85); $('#tPrev').src = thumb; $('#fThumb').value = ''; URL.revokeObjectURL(url);
      };
      img.onerror = () => { $('#edErr').textContent = 'Could not read that image file.'; };
      img.src = url;
    });
    modal.querySelectorAll('[data-close]').forEach((b) => (b.onclick = closeEditor));
    $('#edForm').onsubmit = (e) => {
      e.preventDefault();
      const err = $('#edErr'); err.textContent = '';
      modal.querySelectorAll('.bad').forEach((x) => x.classList.remove('bad'));
      const title = $('#fTitle').value.trim();
      const cats = [...modal.querySelectorAll('.checks input[type=checkbox][value]')].filter((x) => x.checked).map((x) => x.value);
      const url = $('#fUrl').value.trim();
      const newId = id || slug($('#fId').value || title);
      const fail = (msg, el) => { err.textContent = msg; if (el) { el.classList.add('bad'); el.focus(); } };
      if (!title) return fail('Please enter a title.', $('#fTitle'));
      if (!newId) return fail('Please enter a valid ID (letters and numbers).', $('#fId'));
      if (!id && list.some((x) => x.id === newId)) return fail(`A game with ID "${newId}" already exists - choose another ID.`, $('#fId'));
      if (!cats.length) return fail('Pick at least one category.');
      if (!url) return fail('Please enter the game URL.', $('#fUrl'));
      if (/^\s*(javascript|data|vbscript):/i.test(url)) return fail('That URL type is not allowed.', $('#fUrl'));
      if (/^http:\/\//i.test(url) && location.protocol === 'https:') return fail('Use an https:// link - http games are blocked on secure sites.', $('#fUrl'));
      const typed = $('#fThumb').value.trim();
      if (typed) thumb = typed;
      // keep settings the form doesn't show (icon, embed / link-out mode, trending)
      const prev = id ? list.find((x) => x.id === id) : null, keep = {};
      if (prev) ['icon', 'external', 'embed', 'trending'].forEach((k) => { if (prev[k] != null) keep[k] = prev[k]; });
      const data = {
        ...keep,
        id: newId, title, categories: cats, description: $('#fDesc').value.trim(), controls: $('#fCtl').value.trim(),
        thumb, url, aspect: $('#fAspect').value, featured: $('#fFeat').checked, popularity: Number($('#fPop').value),
        added: $('#fAdded').value || today()
      };
      const author = $('#fAuthor').value.trim(), lic = $('#fLic').value.trim(), src = $('#fSrc').value.trim();
      if (src && !/^https:\/\//i.test(src)) return fail('The source link must start with https://', $('#fSrc'));
      if (author) data.author = author; if (lic) data.license = lic; if (src) data.source = src;
      if (!$('#fVis').checked) data.hidden = true;
      const next = id ? list.map((x) => (x.id === id ? data : x)) : [data].concat(list);
      if (save(next, id ? `Saved ${title}` : `Added ${title}`)) closeEditor();
    };
  }
  function closeEditor() { modal.classList.remove('open'); modal.innerHTML = ''; }
  modal.addEventListener('mousedown', (e) => { if (e.target === modal) closeEditor(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && modal.classList.contains('open')) closeEditor(); });

  render();
})();
