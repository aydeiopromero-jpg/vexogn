/* VEXO-GN - shared portal code: storage, icons, header/sidebar, cards, search */
(function () {
  'use strict';

  /* ---------------- storage ---------------- */
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del(k) { try { localStorage.removeItem(k); } catch (e) {} }
  };
  const KEYS = { games: 'vexo_games_v1', favs: 'vexo_favs', recent: 'vexo_recent', plays: 'vexo_plays', pin: 'vexo_admin_pin' };

  const Store = {
    KEYS, LS,
    allGames() {
      const s = LS.get(KEYS.games, null);
      return JSON.parse(JSON.stringify(Array.isArray(s) ? s : window.VEXO_DEFAULT_GAMES || []));
    },
    games() { return this.allGames().filter((g) => !g.hidden); },
    isCustomized() { return Array.isArray(LS.get(KEYS.games, null)); },
    saveGames(list) { return LS.set(KEYS.games, list); },
    resetGames() { LS.del(KEYS.games); },
    get(id) { return this.games().find((g) => g.id === id); },
    favs() { return LS.get(KEYS.favs, []); },
    isFav(id) { return this.favs().includes(id); },
    toggleFav(id) {
      let f = this.favs();
      const on = !f.includes(id);
      f = on ? [id].concat(f) : f.filter((x) => x !== id);
      LS.set(KEYS.favs, f);
      document.dispatchEvent(new CustomEvent('vexo:favs'));
      return on;
    },
    recent() { return LS.get(KEYS.recent, []); },
    pushRecent(id) {
      const r = this.recent().filter((x) => x.id !== id);
      r.unshift({ id, t: Date.now() });
      LS.set(KEYS.recent, r.slice(0, 24));
    },
    clearRecent() { LS.set(KEYS.recent, []); },
    plays() { return LS.get(KEYS.plays, {}); },
    addPlay(id) { const p = this.plays(); p[id] = (p[id] || 0) + 1; LS.set(KEYS.plays, p); document.dispatchEvent(new CustomEvent('vexo:play', { detail: { id } })); }
  };

  /* ---------------- helpers ---------------- */
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const slug = (s) => String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  const catBySlug = (s) => (window.VEXO_CATEGORIES || []).find((c) => slug(c) === s);
  const isNew = (g) => g.added && (Date.now() - new Date(g.added + 'T00:00:00').getTime()) / 864e5 <= 14;
  const hash = (s) => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return Math.abs(h); };
  const popScore = (g, plays) => (Number(g.popularity) || 0) + Math.min(30, (plays[g.id] || 0) * 2);

  // Original generic category glyphs for game tiles (drawn in a 100x100 box).
  const TILE_GLYPH = {
    'Racing': '<path d="M22 88V14" stroke="#fff" stroke-width="7" stroke-linecap="round"/><path d="M26 16h56v40H26z" fill="#fff"/><path d="M26 16h14v10H26zM54 16h14v10H54zM40 26h14v10H40zM68 26h14v10H68zM26 36h14v10H26zM54 36h14v10H54zM40 46h14v10H40zM68 46h14v10H68z" fill="#111"/>',
    'Sports': '<circle cx="50" cy="50" r="38" fill="#fff"/><path d="M50 26l14 10-5 17H41l-5-17z" fill="#111"/><path d="M50 12v14M64 36l22-6M59 53l12 18M41 53L29 71M36 36l-22-6" stroke="#111" stroke-width="4"/>',
    '2 Player': '<circle cx="32" cy="32" r="14" fill="#fff"/><circle cx="68" cy="32" r="14" fill="#fff"/><path d="M8 86c2-20 12-30 24-30s22 10 24 30zM44 86c2-20 12-30 24-30s22 10 24 30z" fill="#fff"/>',
    'Multiplayer': '<circle cx="50" cy="28" r="13" fill="#fff"/><circle cx="20" cy="40" r="10" fill="#fff" opacity=".85"/><circle cx="80" cy="40" r="10" fill="#fff" opacity=".85"/><path d="M28 88c2-20 10-30 22-30s20 10 22 30z" fill="#fff"/><path d="M2 84c1-14 8-22 18-22 5 0 9 2 12 5-6 5-9 11-10 17zM98 84c-1-14-8-22-18-22-5 0-9 2-12 5 6 5 9 11 10 17z" fill="#fff" opacity=".85"/>',
    'Action': '<path d="M58 6L18 56h26l-8 38 46-54H56z" fill="#fff"/>',
    'Puzzle': '<path d="M14 14h26a10 10 0 1120 0h26v26a10 10 0 110 20v26H60a10 10 0 10-20 0H14V60a10 10 0 100-20z" fill="#fff"/>',
    'Arcade': '<rect x="18" y="66" width="64" height="18" rx="6" fill="#fff"/><path d="M47 34h6v34h-6z" fill="#fff"/><circle cx="50" cy="28" r="14" fill="#fff"/><circle cx="74" cy="60" r="5" fill="#fff"/>',
    'Adventure': '<circle cx="50" cy="50" r="38" fill="none" stroke="#fff" stroke-width="7"/><path d="M66 34L56 56 34 66l10-22z" fill="#fff"/>'
  };
  Object.assign(TILE_GLYPH, {"kart": "<rect x=\"14\" y=\"48\" width=\"72\" height=\"18\" rx=\"6\" fill=\"#fff\"/><path d=\"M34 48l8-16h18l6 16z\" fill=\"#fff\"/><circle cx=\"28\" cy=\"72\" r=\"10\" fill=\"#fff\"/><circle cx=\"72\" cy=\"72\" r=\"10\" fill=\"#fff\"/><circle cx=\"28\" cy=\"72\" r=\"4\" fill=\"#333\"/><circle cx=\"72\" cy=\"72\" r=\"4\" fill=\"#333\"/><path d=\"M8 30h16M4 40h14\" stroke=\"#fff\" stroke-width=\"5\" stroke-linecap=\"round\"/>", "football": "<ellipse cx=\"50\" cy=\"50\" rx=\"42\" ry=\"26\" transform=\"rotate(-30 50 50)\" fill=\"#fff\"/><path d=\"M36 58l28-16M42 52l4 6M48 48l4 6M54 44l4 6\" stroke=\"#333\" stroke-width=\"4\" stroke-linecap=\"round\"/>", "hook": "<circle cx=\"78\" cy=\"16\" r=\"8\" fill=\"#fff\"/><path d=\"M78 24L50 52\" stroke=\"#fff\" stroke-width=\"4\"/><circle cx=\"44\" cy=\"58\" r=\"8\" fill=\"#fff\"/><path d=\"M44 66v14M44 70l-12 8M44 70l14 4M44 80l-10 14M44 80l8 14\" stroke=\"#fff\" stroke-width=\"5\" stroke-linecap=\"round\"/>", "cart": "<path d=\"M6 16h14l12 44h46l10-30H26\" fill=\"none\" stroke=\"#fff\" stroke-width=\"7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><circle cx=\"38\" cy=\"76\" r=\"8\" fill=\"#fff\"/><circle cx=\"72\" cy=\"76\" r=\"8\" fill=\"#fff\"/><path d=\"M40 30h40l-6 20H44z\" fill=\"#fff\"/>", "car": "<path d=\"M10 62v-12l14-4 12-14h28l16 14 10 4v12z\" fill=\"#fff\"/><circle cx=\"28\" cy=\"66\" r=\"10\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"4\"/><circle cx=\"72\" cy=\"66\" r=\"10\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"4\"/><path d=\"M40 36h22l10 10H38z\" fill=\"#333\" opacity=\".5\"/>", "driftcar": "<g transform=\"rotate(-15 50 50)\"><path d=\"M18 60v-12l12-4 10-12h24l14 12 8 4v12z\" fill=\"#fff\"/><circle cx=\"34\" cy=\"64\" r=\"9\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"4\"/><circle cx=\"70\" cy=\"64\" r=\"9\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"4\"/></g><path d=\"M4 84q20-6 40 0M2 94q24-6 46 0\" stroke=\"#fff\" stroke-width=\"4\" fill=\"none\" opacity=\".7\"/>", "bike": "<circle cx=\"24\" cy=\"66\" r=\"16\" fill=\"none\" stroke=\"#fff\" stroke-width=\"7\"/><circle cx=\"78\" cy=\"66\" r=\"16\" fill=\"none\" stroke=\"#fff\" stroke-width=\"7\"/><path d=\"M24 66l20-24h22l12 24M44 42l-4-10h-10M56 42l10-12h10\" stroke=\"#fff\" stroke-width=\"7\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>", "basketball": "<circle cx=\"50\" cy=\"50\" r=\"40\" fill=\"#fff\"/><path d=\"M10 50h80M50 10v80M22 22q18 28 0 56M78 22q-18 28 0 56\" stroke=\"#333\" stroke-width=\"4\" fill=\"none\"/>", "goal": "<path d=\"M8 72V20h84v52\" fill=\"none\" stroke=\"#fff\" stroke-width=\"6\"/><path d=\"M8 32h84M8 46h84M8 60h84M22 20v52M36 20v52M50 20v52M64 20v52M78 20v52\" stroke=\"#fff\" stroke-width=\"2\" opacity=\".5\"/><circle cx=\"50\" cy=\"84\" r=\"12\" fill=\"#fff\"/><path d=\"M50 78l5 4-2 6h-6l-2-6z\" fill=\"#333\"/>", "house": "<path d=\"M50 10L8 46h12v40h60V46h12z\" fill=\"#fff\"/><rect x=\"42\" y=\"60\" width=\"16\" height=\"26\" fill=\"#333\" opacity=\".6\"/><path d=\"M62 52l6 12-8-2 2 10-10-14 8 2z\" fill=\"#f43\"/>", "fist": "<circle cx=\"30\" cy=\"22\" r=\"10\" fill=\"#fff\"/><path d=\"M30 32l-6 28M24 60l-10 26M24 60l12 24M28 40l-18 6M28 40l26-6\" stroke=\"#fff\" stroke-width=\"7\" stroke-linecap=\"round\"/><circle cx=\"66\" cy=\"32\" r=\"12\" fill=\"#fff\"/><path d=\"M72 22l10-8M78 34l12-2M74 44l10 8\" stroke=\"#fff\" stroke-width=\"4\" stroke-linecap=\"round\"/>", "knife": "<g transform=\"rotate(-40 50 50)\"><path d=\"M20 44h46l18 6-18 6H20z\" fill=\"#fff\"/><rect x=\"4\" y=\"42\" width=\"18\" height=\"16\" rx=\"4\" fill=\"#fff\" opacity=\".8\"/></g><path d=\"M58 70l18 14M66 64l20 8\" stroke=\"#fff\" stroke-width=\"4\" opacity=\".7\" stroke-linecap=\"round\"/>", "crosshair": "<circle cx=\"50\" cy=\"50\" r=\"32\" fill=\"none\" stroke=\"#fff\" stroke-width=\"7\"/><circle cx=\"50\" cy=\"50\" r=\"6\" fill=\"#fff\"/><path d=\"M50 4v24M50 72v24M4 50h24M72 50h24\" stroke=\"#fff\" stroke-width=\"7\" stroke-linecap=\"round\"/>", "blocks": "<rect x=\"10\" y=\"10\" width=\"24\" height=\"24\" rx=\"3\" fill=\"#fff\"/><rect x=\"38\" y=\"10\" width=\"24\" height=\"24\" rx=\"3\" fill=\"#fff\" opacity=\".7\"/><rect x=\"38\" y=\"38\" width=\"24\" height=\"24\" rx=\"3\" fill=\"#fff\"/><rect x=\"66\" y=\"38\" width=\"24\" height=\"24\" rx=\"3\" fill=\"#fff\" opacity=\".7\"/><rect x=\"10\" y=\"66\" width=\"24\" height=\"24\" rx=\"3\" fill=\"#fff\" opacity=\".7\"/><rect x=\"38\" y=\"66\" width=\"24\" height=\"24\" rx=\"3\" fill=\"#fff\"/><rect x=\"66\" y=\"66\" width=\"24\" height=\"24\" rx=\"3\" fill=\"#fff\"/>", "question": "<path d=\"M32 34a18 18 0 1136 0c0 14-18 16-18 30\" fill=\"none\" stroke=\"#fff\" stroke-width=\"12\" stroke-linecap=\"round\"/><circle cx=\"50\" cy=\"86\" r=\"7\" fill=\"#fff\"/>", "bubbles": "<circle cx=\"30\" cy=\"34\" r=\"18\" fill=\"#fff\"/><circle cx=\"68\" cy=\"30\" r=\"14\" fill=\"#fff\" opacity=\".8\"/><circle cx=\"52\" cy=\"64\" r=\"20\" fill=\"#fff\" opacity=\".9\"/><circle cx=\"22\" cy=\"74\" r=\"10\" fill=\"#fff\" opacity=\".7\"/><circle cx=\"84\" cy=\"66\" r=\"10\" fill=\"#fff\" opacity=\".7\"/>", "rampcar": "<path d=\"M4 92L96 48v44z\" fill=\"#fff\" opacity=\".6\"/><g transform=\"rotate(-25 50 40)\"><path d=\"M22 44v-10l10-3 8-10h20l12 10 8 3v10z\" fill=\"#fff\"/><circle cx=\"34\" cy=\"46\" r=\"7\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"3\"/><circle cx=\"66\" cy=\"46\" r=\"7\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"3\"/></g>", "track": "<path d=\"M10 90Q10 20 50 30T90 10\" fill=\"none\" stroke=\"#fff\" stroke-width=\"16\" stroke-linecap=\"round\"/><path d=\"M10 90Q10 20 50 30T90 10\" fill=\"none\" stroke=\"#333\" stroke-width=\"2\" stroke-dasharray=\"6 6\"/>", "plane": "<path d=\"M50 6l8 30 34 16v8l-34-8-4 26 12 8v6l-16-4-16 4v-6l12-8-4-26-34 8v-8l34-16z\" fill=\"#fff\"/>", "tunnel": "<rect x=\"6\" y=\"6\" width=\"88\" height=\"88\" fill=\"none\" stroke=\"#fff\" stroke-width=\"5\" transform=\"rotate(10 50 50)\"/><rect x=\"20\" y=\"20\" width=\"60\" height=\"60\" fill=\"none\" stroke=\"#fff\" stroke-width=\"5\" opacity=\".8\" transform=\"rotate(25 50 50)\"/><rect x=\"33\" y=\"33\" width=\"34\" height=\"34\" fill=\"none\" stroke=\"#fff\" stroke-width=\"5\" opacity=\".6\" transform=\"rotate(40 50 50)\"/><circle cx=\"50\" cy=\"50\" r=\"5\" fill=\"#fff\"/>", "tank": "<rect x=\"10\" y=\"58\" width=\"80\" height=\"22\" rx=\"11\" fill=\"#fff\"/><path d=\"M24 58l6-18h38l6 18z\" fill=\"#fff\"/><path d=\"M60 46l32-14\" stroke=\"#fff\" stroke-width=\"7\" stroke-linecap=\"round\"/><circle cx=\"24\" cy=\"69\" r=\"5\" fill=\"#333\"/><circle cx=\"42\" cy=\"69\" r=\"5\" fill=\"#333\"/><circle cx=\"60\" cy=\"69\" r=\"5\" fill=\"#333\"/><circle cx=\"76\" cy=\"69\" r=\"5\" fill=\"#333\"/>", "ship": "<path d=\"M8 60h84l-14 22H22z\" fill=\"#fff\"/><path d=\"M48 14v44M48 16l26 30H48z\" fill=\"#fff\" stroke=\"#fff\" stroke-width=\"4\"/><path d=\"M4 92q12-6 24 0t24 0 24 0 24 0\" stroke=\"#fff\" stroke-width=\"4\" fill=\"none\"/>", "bug": "<ellipse cx=\"50\" cy=\"56\" rx=\"22\" ry=\"28\" fill=\"#fff\"/><circle cx=\"50\" cy=\"24\" r=\"12\" fill=\"#fff\"/><path d=\"M50 30v54\" stroke=\"#333\" stroke-width=\"3\"/><path d=\"M28 46l-18-8M28 60H8M30 74l-16 10M72 46l18-8M72 60h20M70 74l16 10M44 14l-8-10M56 14l8-10\" stroke=\"#fff\" stroke-width=\"5\" stroke-linecap=\"round\"/>", "snake": "<path d=\"M16 80c0-20 30-20 30-40S16 20 30 10M46 40c0 20 34 20 40 0\" fill=\"none\" stroke=\"#fff\" stroke-width=\"12\" stroke-linecap=\"round\"/><circle cx=\"86\" cy=\"38\" r=\"9\" fill=\"#fff\"/><circle cx=\"88\" cy=\"35\" r=\"2.5\" fill=\"#333\"/>", "candy": "<circle cx=\"50\" cy=\"50\" r=\"22\" fill=\"#fff\"/><path d=\"M28 50L8 36v28zM72 50l20-14v28z\" fill=\"#fff\" opacity=\".8\"/><path d=\"M38 38q12 12 24 24M44 32q14 14 22 22\" stroke=\"#e44\" stroke-width=\"4\" fill=\"none\"/>", "flamedrop": "<path d=\"M30 12c8 14 20 22 20 40a20 20 0 01-40 0c0-12 8-20 10-30 4 8 6 12 10 12-2-8-2-14 0-22z\" fill=\"#fff\"/><path d=\"M72 30c10 16 18 26 18 38a18 18 0 01-36 0c0-12 8-22 18-38z\" fill=\"#fff\" opacity=\".85\"/>", "runners": "<circle cx=\"28\" cy=\"20\" r=\"9\" fill=\"#fff\"/><path d=\"M26 30l-4 26M22 56l-12 22M22 56l14 16M24 38l-14 4M24 38l16 8\" stroke=\"#fff\" stroke-width=\"7\" stroke-linecap=\"round\"/><circle cx=\"70\" cy=\"26\" r=\"9\" fill=\"#fff\" opacity=\".85\"/><path d=\"M68 36l-4 24M64 60l-12 20M64 60l14 18M66 44l-14 6M66 44l16 2\" stroke=\"#fff\" stroke-width=\"7\" stroke-linecap=\"round\" opacity=\".85\"/>", "swords": "<path d=\"M16 16l58 58M84 16L26 74\" stroke=\"#fff\" stroke-width=\"8\" stroke-linecap=\"round\"/><path d=\"M64 84l20-20M16 64l20 20\" stroke=\"#fff\" stroke-width=\"8\" stroke-linecap=\"round\"/>", "buildings": "<rect x=\"8\" y=\"46\" width=\"24\" height=\"48\" fill=\"#fff\" opacity=\".8\"/><rect x=\"36\" y=\"30\" width=\"28\" height=\"64\" fill=\"#fff\"/><rect x=\"68\" y=\"56\" width=\"24\" height=\"38\" fill=\"#fff\" opacity=\".8\"/><path d=\"M50 4l14 16H56v8H44v-8h-8z\" fill=\"#fff\"/>", "hoop": "<rect x=\"56\" y=\"10\" width=\"36\" height=\"28\" fill=\"none\" stroke=\"#fff\" stroke-width=\"5\"/><path d=\"M40 40h40\" stroke=\"#fff\" stroke-width=\"6\"/><path d=\"M42 40l6 22h24l6-22M50 40l4 22M60 40v22M70 40l-4 22\" stroke=\"#fff\" stroke-width=\"3\" fill=\"none\"/><circle cx=\"24\" cy=\"70\" r=\"16\" fill=\"#fff\"/>", "trophy": "<path d=\"M28 10h44v20a22 22 0 01-44 0z\" fill=\"#fff\"/><path d=\"M28 18H14q0 18 16 20M72 18h14q0 18-16 20\" fill=\"none\" stroke=\"#fff\" stroke-width=\"6\"/><rect x=\"44\" y=\"52\" width=\"12\" height=\"18\" fill=\"#fff\"/><rect x=\"30\" y=\"70\" width=\"40\" height=\"12\" rx=\"3\" fill=\"#fff\"/>", "medical": "<rect x=\"38\" y=\"10\" width=\"24\" height=\"80\" rx=\"6\" fill=\"#fff\"/><rect x=\"10\" y=\"38\" width=\"80\" height=\"24\" rx=\"6\" fill=\"#fff\"/>", "glove": "<path d=\"M22 50c0-24 10-36 30-36s28 12 28 28v18c0 10-8 18-18 18H38c-10 0-16-8-16-18z\" fill=\"#fff\"/><rect x=\"28\" y=\"76\" width=\"42\" height=\"18\" rx=\"4\" fill=\"#fff\" opacity=\".8\"/><path d=\"M22 52c8 0 14 4 14 12\" stroke=\"#333\" stroke-width=\"4\" fill=\"none\"/>", "knight": "<path d=\"M30 90h46l-4-14H34zM36 76c-2-14 6-22 12-28-10 2-18-2-20-8 8-6 12-18 26-24l4-6 4 8c10 6 14 20 12 40l-2 18z\" fill=\"#fff\"/><circle cx=\"54\" cy=\"30\" r=\"3\" fill=\"#333\"/>", "stickflag": "<circle cx=\"30\" cy=\"22\" r=\"10\" fill=\"#fff\"/><path d=\"M30 32v30M30 62l-12 26M30 62l12 26M30 42l-16 10M30 42l18 6\" stroke=\"#fff\" stroke-width=\"7\" stroke-linecap=\"round\"/><path d=\"M70 90V14\" stroke=\"#fff\" stroke-width=\"5\"/><path d=\"M70 14l24 10-24 10z\" fill=\"#fff\"/>", "soccer": "<circle cx=\"50\" cy=\"50\" r=\"38\" fill=\"#fff\"/><path d=\"M50 26l14 10-5 17H41l-5-17z\" fill=\"#333\"/><path d=\"M50 12v14M64 36l22-6M59 53l12 18M41 53L29 71M36 36l-22-6\" stroke=\"#333\" stroke-width=\"4\"/>", "pingpong": "<circle cx=\"36\" cy=\"40\" r=\"26\" fill=\"#fff\"/><rect x=\"30\" y=\"62\" width=\"12\" height=\"30\" rx=\"5\" fill=\"#fff\"/><circle cx=\"76\" cy=\"24\" r=\"9\" fill=\"#fff\"/>"});
  const TILE_PALETTES = [['#ff512f','#dd2476'],['#7f00ff','#c026d3'],['#00c6ff','#0052d4'],['#f7971e','#e44d26'],['#11998e','#0f766e'],['#fc466b','#3f5efb'],
    ['#ee0979','#ff6a00'],['#8e2de2','#4a00e0'],['#00b09b','#3d7c1f'],['#f953c6','#b91d73'],['#2563eb','#06b6d4'],['#ff5e62','#c2410c'],['#16a34a','#065f46'],['#6d28d9','#1e3a8a']];
  Object.assign(TILE_GLYPH, {"slope": "<path d=\"M4 96L96 34v62z\" fill=\"#fff\" opacity=\".55\"/><path d=\"M4 96L96 34\" stroke=\"#fff\" stroke-width=\"5\"/><circle cx=\"38\" cy=\"58\" r=\"14\" fill=\"#fff\"/><path d=\"M14 44h12M10 54h10\" stroke=\"#fff\" stroke-width=\"4\" stroke-linecap=\"round\" opacity=\".7\"/>", "cookie": "<circle cx=\"50\" cy=\"50\" r=\"40\" fill=\"#fff\"/><circle cx=\"34\" cy=\"36\" r=\"6\" fill=\"#5b3a1e\"/><circle cx=\"60\" cy=\"30\" r=\"5\" fill=\"#5b3a1e\"/><circle cx=\"66\" cy=\"56\" r=\"7\" fill=\"#5b3a1e\"/><circle cx=\"40\" cy=\"64\" r=\"6\" fill=\"#5b3a1e\"/><circle cx=\"52\" cy=\"48\" r=\"4\" fill=\"#5b3a1e\"/>", "snow": "<path d=\"M50 6v88M12 28l76 44M12 72l76-44\" stroke=\"#fff\" stroke-width=\"7\" stroke-linecap=\"round\"/><path d=\"M40 14l10 10 10-10M40 86l10-10 10 10M14 40l14-2-4-14M86 60l-14 2 4 14M14 60l14 2-4 14M86 40l-14-2 4-14\" stroke=\"#fff\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"/>", "hardest": "<rect x=\"10\" y=\"10\" width=\"80\" height=\"80\" fill=\"none\" stroke=\"#fff\" stroke-width=\"5\"/><rect x=\"18\" y=\"42\" width=\"16\" height=\"16\" fill=\"#fff\"/><circle cx=\"50\" cy=\"26\" r=\"7\" fill=\"#fff\" opacity=\".85\"/><circle cx=\"62\" cy=\"50\" r=\"7\" fill=\"#fff\" opacity=\".85\"/><circle cx=\"50\" cy=\"74\" r=\"7\" fill=\"#fff\" opacity=\".85\"/><rect x=\"72\" y=\"18\" width=\"12\" height=\"64\" fill=\"#fff\" opacity=\".5\"/>", "music": "<path d=\"M36 74V20l46-10v52\" fill=\"none\" stroke=\"#fff\" stroke-width=\"7\" stroke-linejoin=\"round\"/><ellipse cx=\"26\" cy=\"76\" rx=\"13\" ry=\"10\" fill=\"#fff\"/><ellipse cx=\"72\" cy=\"64\" rx=\"13\" ry=\"10\" fill=\"#fff\"/><path d=\"M36 32l46-10\" stroke=\"#fff\" stroke-width=\"7\"/>", "paper": "<rect x=\"10\" y=\"10\" width=\"80\" height=\"80\" rx=\"6\" fill=\"#fff\" opacity=\".25\"/><path d=\"M14 14h40v28h26v44H14z\" fill=\"#fff\"/><path d=\"M54 42l22-22\" stroke=\"#fff\" stroke-width=\"5\" stroke-dasharray=\"6 5\"/><rect x=\"72\" y=\"12\" width=\"16\" height=\"16\" rx=\"3\" fill=\"#fff\"/>", "cube": "<path d=\"M50 8l40 20-40 20-40-20z\" fill=\"#fff\"/><path d=\"M10 28l40 20v44L10 72z\" fill=\"#fff\" opacity=\".75\"/><path d=\"M90 28L50 48v44l40-20z\" fill=\"#fff\" opacity=\".55\"/>", "maze": "<path d=\"M8 8h84v84H8z M8 30h50 M76 8v40 M30 30v40h40 M50 50v42 M8 70h22 M70 70v22\" fill=\"none\" stroke=\"#fff\" stroke-width=\"6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"20\" cy=\"19\" r=\"5\" fill=\"#fff\"/><circle cx=\"62\" cy=\"81\" r=\"5\" fill=\"#fff\"/>"});
  Object.assign(TILE_GLYPH, {"egg": "<ellipse cx=\"50\" cy=\"54\" rx=\"30\" ry=\"38\" fill=\"#fff\"/><circle cx=\"50\" cy=\"56\" r=\"14\" fill=\"none\" stroke=\"#333\" stroke-width=\"4\"/><path d=\"M50 38v8M50 66v8M32 56h8M60 56h8\" stroke=\"#333\" stroke-width=\"4\"/>", "build": "<rect x=\"8\" y=\"64\" width=\"40\" height=\"26\" fill=\"#fff\"/><rect x=\"52\" y=\"64\" width=\"40\" height=\"26\" fill=\"#fff\" opacity=\".8\"/><rect x=\"28\" y=\"36\" width=\"40\" height=\"26\" fill=\"#fff\" opacity=\".9\"/><path d=\"M48 10l20 20H56v6H40v-6H28z\" fill=\"#fff\"/>", "spikes": "<path d=\"M6 90l14-28 14 28zM34 90l14-28 14 28zM62 90l14-28 14 28z\" fill=\"#fff\"/><rect x=\"40\" y=\"16\" width=\"20\" height=\"24\" rx=\"4\" fill=\"#fff\"/><path d=\"M44 40v12M56 40v12\" stroke=\"#fff\" stroke-width=\"5\"/>", "fish": "<path d=\"M14 50c14-20 44-24 62 0-18 24-48 20-62 0z\" fill=\"#fff\"/><path d=\"M76 50l16-14v28z\" fill=\"#fff\"/><circle cx=\"30\" cy=\"46\" r=\"4\" fill=\"#333\"/><path d=\"M50 6v26\" stroke=\"#fff\" stroke-width=\"3\"/><path d=\"M50 32q-6 6 0 10\" stroke=\"#fff\" stroke-width=\"3\" fill=\"none\"/>", "road": "<rect x=\"0\" y=\"22\" width=\"100\" height=\"56\" fill=\"#fff\" opacity=\".3\"/><path d=\"M0 22h100M0 78h100\" stroke=\"#fff\" stroke-width=\"5\"/><path d=\"M10 50h16M38 50h16M66 50h16\" stroke=\"#fff\" stroke-width=\"6\"/><rect x=\"40\" y=\"2\" width=\"20\" height=\"16\" rx=\"4\" fill=\"#fff\"/><path d=\"M44 18v6M56 18v6\" stroke=\"#fff\" stroke-width=\"4\"/>", "helix": "<rect x=\"44\" y=\"4\" width=\"12\" height=\"92\" fill=\"#fff\" opacity=\".6\"/><path d=\"M10 30h80l-10 8H20zM10 58h80l-10 8H20zM10 86h80l-10 8H20z\" fill=\"#fff\"/><circle cx=\"70\" cy=\"18\" r=\"9\" fill=\"#fff\"/>", "fruit": "<path d=\"M10 40a40 40 0 0080 0z\" fill=\"#fff\"/><path d=\"M18 44a32 32 0 0064 0z\" fill=\"#fff\" opacity=\".6\"/><circle cx=\"36\" cy=\"54\" r=\"3\" fill=\"#333\"/><circle cx=\"50\" cy=\"60\" r=\"3\" fill=\"#333\"/><circle cx=\"64\" cy=\"54\" r=\"3\" fill=\"#333\"/><path d=\"M14 20L86 76\" stroke=\"#fff\" stroke-width=\"5\" stroke-linecap=\"round\"/>", "tiles": "<rect x=\"8\" y=\"8\" width=\"40\" height=\"40\" rx=\"6\" fill=\"#fff\"/><rect x=\"52\" y=\"8\" width=\"40\" height=\"40\" rx=\"6\" fill=\"#fff\" opacity=\".75\"/><rect x=\"8\" y=\"52\" width=\"40\" height=\"40\" rx=\"6\" fill=\"#fff\" opacity=\".75\"/><rect x=\"52\" y=\"52\" width=\"40\" height=\"40\" rx=\"6\" fill=\"#fff\"/><text x=\"28\" y=\"36\" text-anchor=\"middle\" font-family=\"Arial Black,Arial\" font-weight=\"900\" font-size=\"22\" fill=\"#333\">2</text><text x=\"72\" y=\"80\" text-anchor=\"middle\" font-family=\"Arial Black,Arial\" font-weight=\"900\" font-size=\"22\" fill=\"#333\">4</text>", "ball": "<circle cx=\"50\" cy=\"52\" r=\"34\" fill=\"#fff\"/><ellipse cx=\"38\" cy=\"38\" rx=\"10\" ry=\"6\" fill=\"#fff\" opacity=\".6\" transform=\"rotate(-30 38 38)\"/><path d=\"M10 92h80\" stroke=\"#fff\" stroke-width=\"6\" stroke-linecap=\"round\"/>", "parking": "<rect x=\"14\" y=\"10\" width=\"72\" height=\"80\" rx=\"14\" fill=\"#fff\"/><path d=\"M38 72V28h16a12 12 0 010 24H38\" fill=\"none\" stroke=\"#333\" stroke-width=\"9\" stroke-linejoin=\"round\"/>", "rope": "<path d=\"M50 4v40\" stroke=\"#fff\" stroke-width=\"5\"/><path d=\"M20 4q10 30 26 40M80 4q-10 30-26 40\" stroke=\"#fff\" stroke-width=\"4\" fill=\"none\" opacity=\".7\"/><circle cx=\"50\" cy=\"60\" r=\"16\" fill=\"#fff\"/><path d=\"M34 60l-14-8v16zM66 60l14-8v16z\" fill=\"#fff\"/><path d=\"M40 52q10 10 20 16\" stroke=\"#e44\" stroke-width=\"4\" fill=\"none\"/>"});
  Object.assign(TILE_GLYPH, {"bow": "<path d=\"M30 8q44 42 0 84\" fill=\"none\" stroke=\"#fff\" stroke-width=\"7\" stroke-linecap=\"round\"/><path d=\"M30 8v84\" stroke=\"#fff\" stroke-width=\"2.5\"/><path d=\"M14 50h74\" stroke=\"#fff\" stroke-width=\"5\" stroke-linecap=\"round\"/><path d=\"M88 50l-14-9v18z\" fill=\"#fff\"/><path d=\"M14 50l-8-8M14 50l-8 8\" stroke=\"#fff\" stroke-width=\"4\" stroke-linecap=\"round\"/>", "bricks": "<rect x=\"8\" y=\"10\" width=\"26\" height=\"14\" rx=\"2\" fill=\"#fff\"/><rect x=\"37\" y=\"10\" width=\"26\" height=\"14\" rx=\"2\" fill=\"#fff\" opacity=\".75\"/><rect x=\"66\" y=\"10\" width=\"26\" height=\"14\" rx=\"2\" fill=\"#fff\"/><rect x=\"22\" y=\"28\" width=\"26\" height=\"14\" rx=\"2\" fill=\"#fff\" opacity=\".75\"/><rect x=\"52\" y=\"28\" width=\"26\" height=\"14\" rx=\"2\" fill=\"#fff\"/><circle cx=\"34\" cy=\"64\" r=\"7\" fill=\"#fff\"/><circle cx=\"62\" cy=\"58\" r=\"7\" fill=\"#fff\" opacity=\".85\"/><circle cx=\"50\" cy=\"76\" r=\"7\" fill=\"#fff\" opacity=\".7\"/><rect x=\"30\" y=\"88\" width=\"40\" height=\"7\" rx=\"3\" fill=\"#fff\"/>", "truck": "<rect x=\"6\" y=\"30\" width=\"56\" height=\"36\" rx=\"3\" fill=\"#fff\"/><path d=\"M62 40h18l12 14v12H62z\" fill=\"#fff\" opacity=\".85\"/><circle cx=\"24\" cy=\"72\" r=\"9\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"4\"/><circle cx=\"76\" cy=\"72\" r=\"9\" fill=\"#fff\" stroke=\"#333\" stroke-width=\"4\"/><circle cx=\"34\" cy=\"14\" r=\"7\" fill=\"#fff\"/><path d=\"M34 21v9\" stroke=\"#fff\" stroke-width=\"5\"/>"});
  // Every game uses its real picture. If one can't load, its box just stays plain dark (no drawn icon).
  const BLANK = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><rect width="400" height="400" fill="#1b1b1f"/></svg>');
  // simple cover for games that have no picture: the game's name in big white letters and the site it opens on
  const SITE_COLOR = { CrazyGames: '#7b5cff', Poki: '#2a8cff', 'Coolmath Games': '#ff6a3d' };
  const xml = (t) => String(t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]));
  const coverCache = new Map();
  function autoThumb(title, cat, icon, site) {
    if (!title) return BLANK;
    const key = title + '|' + (site || ''); if (coverCache.has(key)) return coverCache.get(key);
    const words = String(title).toUpperCase().split(/\s+/), lines = [];
    for (const w of words) { const l = lines[lines.length - 1]; if (l && (l + ' ' + w).length <= 13) lines[lines.length - 1] = l + ' ' + w; else lines.push(w); }
    const L = lines.slice(0, 3), longest = Math.max(...L.map((l) => l.length));
    const size = Math.max(28, Math.min(L.length === 1 ? 66 : L.length === 2 ? 50 : 40, Math.floor(340 / (longest * 0.66))));
    const lh = size * 1.08, y0 = 200 - ((L.length - 1) * lh) / 2 + size * 0.35 - (site ? 14 : 0);
    const siteName = site ? String(site).replace(/ \(official\)$/, '') : '';
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><rect width='400' height='400' fill='#0d0d10'/>`
      + L.map((l, i) => `<text x='200' y='${(y0 + i * lh).toFixed(1)}' text-anchor='middle' font-family='Arial,Helvetica,sans-serif' font-weight='800' font-size='${size}' fill='#ffffff'>${xml(l)}</text>`).join('')
      + (siteName ? `<text x='200' y='336' text-anchor='middle' font-family='Arial,Helvetica,sans-serif' font-weight='700' font-size='14' letter-spacing='3' fill='#8b8b93'>${xml(siteName.toUpperCase())}</text><rect x='176' y='350' width='48' height='3' rx='1.5' fill='${SITE_COLOR[siteName] || '#ffffff'}'/>` : '')
      + `</svg>`;
    const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    coverCache.set(key, url); return url;
  }
  const thumbOf = (g) => (g.builtin && window.VEXO_BUILTIN_THUMBS && window.VEXO_BUILTIN_THUMBS[g.id]) || g.thumb || autoThumb(g.title, (g.categories || [])[0], g.icon, g.external ? g.author : '');

  /* ---------------- icons ---------------- */
  const P = (d, extra = '') => `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${d}</svg>`;
  const ICONS = {
    home: P('<path d="M3 11l9-7 9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/>'),
    search: P('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>'),
    heart: P('<path d="M12 20s-7-4.4-9.2-9A5 5 0 0112 5.6 5 5 0 0121.2 11C19 15.6 12 20 12 20z"/>'),
    heartFill: P('<path d="M12 20s-7-4.4-9.2-9A5 5 0 0112 5.6 5 5 0 0121.2 11C19 15.6 12 20 12 20z" fill="currentColor"/>'),
    clock: P('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    shuffle: P('<path d="M16 3h5v5"/><path d="M4 20L21 3"/><path d="M21 16v5h-5"/><path d="M15 15l6 6"/><path d="M4 4l5 5"/>'),
    expand: P('<path d="M4 9V4h5"/><path d="M20 9V4h-5"/><path d="M4 15v5h5"/><path d="M20 15v5h-5"/>'),
    shrink: P('<path d="M9 4v5H4"/><path d="M15 4v5h5"/><path d="M9 20v-5H4"/><path d="M15 20v-5h5"/>'),
    x: P('<path d="M6 6l12 12M18 6L6 18"/>'),
    play: P('<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>'),
    gear: P('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>'),
    menu: P('<path d="M4 6h16M4 12h16M4 18h16"/>'),
    link: P('<path d="M10 14a5 5 0 007 0l3-3a5 5 0 00-7-7l-1 1"/><path d="M14 10a5 5 0 00-7 0l-3 3a5 5 0 007 7l1-1"/>'),
    refresh: P('<path d="M20 11a8 8 0 10-2.3 5.7"/><path d="M20 4v7h-7"/>'),
    grid: P('<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>'),
    star: P('<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>'),
    fire: P('<path d="M12 22a7 7 0 007-7c0-4-3-6.5-4-10-2 1.5-3 4-3 6-1-1-2-2-2-4-2 2-5 5-5 8a7 7 0 007 7z"/>'),
    spark: P('<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6"/>'),
    chevL: P('<path d="M15 6l-6 6 6 6"/>'),
    chevR: P('<path d="M9 6l6 6-6 6"/>'),
    trash: P('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
    edit: P('<path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M14 6l4 4"/>'),
    plus: P('<path d="M12 5v14M5 12h14"/>'),
    lock: P('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/>'),
    download: P('<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>'),
    upload: P('<path d="M12 20V9M7 14l5-5 5 5M5 4h14"/>'),
    eye: P('<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    // categories
    'Action': P('<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>'),
    'Racing': P('<path d="M5 21V4"/><path d="M5 4h13l-2.5 4L18 12H5"/>'),
    'Sports': P('<circle cx="12" cy="12" r="9"/><path d="M12 3a14 14 0 000 18M3 12h18M5.5 6a14 14 0 0013 0M5.5 18a14 14 0 0113 0"/>'),
    '2 Player': P('<circle cx="8" cy="8" r="3"/><circle cx="16.5" cy="8" r="3"/><path d="M2.5 20a5.5 5.5 0 0111 0M11 20a5.5 5.5 0 0111 0"/>'),
    'Adventure': P('<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>'),
    'Arcade': P('<rect x="2" y="7" width="20" height="11" rx="5"/><path d="M7 11v3M5.5 12.5h3"/><circle cx="15.5" cy="11.5" r="1" fill="currentColor"/><circle cx="18" cy="13.5" r="1" fill="currentColor"/>'),
    'Puzzle': P('<path d="M9 3h4v2a2 2 0 104 0V3h0v6h-2a2 2 0 100 4h2v8h-6v-2a2 2 0 10-4 0v2H3v-6h2a2 2 0 100-4H3V3z"/>'),
    'Multiplayer': P('<circle cx="12" cy="7" r="3"/><circle cx="5" cy="10" r="2.3"/><circle cx="19" cy="10" r="2.3"/><path d="M7 20a5 5 0 0110 0M1.5 19a3.6 3.6 0 015.5-3M22.5 19a3.6 3.6 0 00-5.5-3"/>')
  };
  const CAT_COLORS = { 'Action': '#f43f5e', 'Racing': '#f59e0b', 'Sports': '#22c55e', '2 Player': '#22d3ee', 'Adventure': '#a3e635', 'Arcade': '#e879f9', 'Puzzle': '#60a5fa', 'Multiplayer': '#a855f7' };
  const catIcon = (c) => ICONS[c] || ICONS.grid;

  const LOGO_MARK = `<svg class="logo-mark" viewBox="0 0 40 40" aria-hidden="true"><defs><linearGradient id="lgm" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#c084fc"/><stop offset="1" stop-color="#3b82f6"/></linearGradient></defs><path d="M20 2l16 9v18l-16 9-16-9V11z" fill="#0d0b26" stroke="url(#lgm)" stroke-width="2.5"/><path d="M11 13h5l4 10 4-10h5l-7 15h-4z" fill="url(#lgm)"/></svg>`;

  /* ---------------- search ---------------- */
  function search(q, list) {
    q = String(q || '').toLowerCase().trim();
    if (!q) return [];
    // skip filler words like "games" or "play" so "racing games" finds racing games
    const FILLER = ['game', 'games', 'play', 'fun', 'online', 'free', 'the', 'a', 'an', 'some', 'best', 'good', 'cool', 'to', 'for', 'with', 'unblocked'];
    let terms = q.split(/\s+/);
    if (terms.some((w) => !FILLER.includes(w))) terms = terms.filter((w) => !FILLER.includes(w));
    return (list || Store.games()).map((g) => {
      const t = g.title.toLowerCase(), cats = (g.categories || []).join(' ').toLowerCase(), d = (g.description || '').toLowerCase();
      let s = 0;
      for (const w0 of terms) {
        const w = w0.length > 3 && w0.endsWith('s') && !t.includes(w0) && !cats.includes(w0) ? w0.slice(0, -1) : w0; // "cars" also finds "car"
        if (t.startsWith(w)) s += 10; else if (t.includes(w)) s += 7;
        else if (cats.includes(w)) s += 5; else if (d.includes(w)) s += 2; else return null;
      }
      return { g, s };
    }).filter(Boolean).sort((a, b) => b.s - a.s).map((x) => x.g);
  }

  /* ---------------- UI: cards ---------------- */
  function card(g, opts = {}) {
    const fav = Store.isFav(g.id);
    const cat = (g.categories || [])[0] || '';
    return `<div class="card${opts.big ? ' big' : ''}" data-id="${esc(g.id)}">
      ${g.external
        ? `<a class="card-link" href="${esc(g.url)}" target="_blank" rel="noopener" data-ext="${esc(g.id)}" title="Play ${esc(g.title)} on ${esc(g.author || 'its site')}">`
        : `<a class="card-link" href="play.html?id=${encodeURIComponent(g.id)}" data-open="${esc(g.id)}" title="Play ${esc(g.title)}">`}
        <div class="thumb">
          <img loading="lazy" src="${esc(thumbOf(g))}" alt="${esc(g.title)}" data-fallback="${esc(autoThumb(g.title, (g.categories || [])[0], g.icon))}">
          <span class="play-hover">${ICONS.play}</span>
        </div>
        <div class="card-body"><span class="card-title">${esc(g.title)}</span>${g.external ? `<span class="card-src">on ${esc(g.author)} ↗</span>` : ''}</div>
      </a>
      <button class="fav-btn${fav ? ' on' : ''}" data-fav="${esc(g.id)}" aria-label="${fav ? 'Remove from' : 'Add to'} favorites" title="${fav ? 'Remove from' : 'Add to'} favorites">${fav ? ICONS.heartFill : ICONS.heart}</button>
    </div>`;
  }
  // global delegated handlers
  // "Start games in full screen" setting (on unless turned off in Settings)
  const autoFs = () => { try { return localStorage.getItem('vexo_autofs') !== '0'; } catch (e) { return true; } };
  const setAutoFs = (on) => { try { localStorage.setItem('vexo_autofs', on ? '1' : '0'); } catch (e) {} };
  // games on sites without an embed open in one window sized to the whole screen
  function openFullWindow(url) {
    const W = screen.availWidth || 1280, H = screen.availHeight || 800;
    let w = null;
    try { w = window.open(url, 'vexo_game', `popup=1,left=0,top=0,width=${W},height=${H}`); } catch (e) { w = null; }
    if (!w) return false;
    try { w.opener = null; w.moveTo(0, 0); w.resizeTo(W, H); w.focus(); } catch (e) {}
    return true;
  }
  document.addEventListener('click', (e) => {
    const x = e.target.closest('a[data-ext]');
    if (!x) return;
    Store.pushRecent(x.dataset.ext); Store.addPlay(x.dataset.ext);
    if (e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0 || !autoFs()) return;
    if (openFullWindow(x.href)) {
      e.preventDefault();
      // on the hub, show the game's panel (favorite, controls, backup link) behind the game window
      if (window.VexoHub && !x.closest('.viewer')) location.hash = '#/play/' + encodeURIComponent(x.dataset.ext);
    }
  });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-fav]');
    if (b) {
      e.preventDefault(); e.stopPropagation();
      const id = b.getAttribute('data-fav'), on = Store.toggleFav(id), g = Store.get(id);
      document.querySelectorAll(`[data-fav="${CSS.escape(id)}"]`).forEach((el) => {
        el.classList.toggle('on', on);
        if (el.classList.contains('fav-btn')) el.innerHTML = on ? ICONS.heartFill : ICONS.heart;
        el.setAttribute('aria-label', (on ? 'Remove from' : 'Add to') + ' favorites');
      });
      toast(on ? `Added <b>${esc(g ? g.title : id)}</b> to favorites` : 'Removed from favorites', on ? 'heart' : null);
    }
  });
  document.addEventListener('error', (e) => {
    const img = e.target;
    if (img.tagName !== 'IMG') return;
    // GameDistribution icons: try the wide version before the drawn icon
    if (/img\.gamedistribution\.com\/[0-9a-f]{32}-512x512\.jpe?g/.test(img.src)) { img.src = img.src.replace('-512x512.', '-512x384.'); return; }
    if (img.hasAttribute('data-hide-err')) { img.hidden = true; return; } // no broken-picture icon
    if (img.dataset.fallback && img.src !== img.dataset.fallback) img.src = img.dataset.fallback;
  }, true);

  /* ---------------- toast ---------------- */
  let toastBox;
  function toast(html, icon) {
    if (!toastBox) { toastBox = document.createElement('div'); toastBox.className = 'toasts'; toastBox.setAttribute('role', 'status'); document.body.appendChild(toastBox); }
    const t = document.createElement('div'); t.className = 'toast';
    t.innerHTML = (icon && ICONS[icon] ? ICONS[icon] : '') + '<span>' + html + '</span>';
    toastBox.appendChild(t);
    requestAnimationFrame(() => t.classList.add('in'));
    setTimeout(() => { t.classList.remove('in'); setTimeout(() => t.remove(), 300); }, 2400);
  }

  /* ---------------- shell (header + sidebar + footer) ---------------- */
  // the games page links to itself; other pages (like admin) link to index.html
  const HOME = () => (window.VexoHub ? '' : 'index.html');
  function shell(active) {
    const games = Store.games();
    const counts = {};
    games.forEach((g) => (g.categories || []).forEach((c) => (counts[c] = (counts[c] || 0) + 1)));
    const favN = Store.favs().filter((id) => games.some((g) => g.id === id)).length;
    const header = document.createElement('header');
    header.className = 'topbar';
    const sortPref = (() => { try { return localStorage.getItem('vexo_sort') || 'az'; } catch (e) { return 'az'; } })();
    header.innerHTML = `
      <a class="brand" href="${HOME()}#/" data-home aria-label="VEXO-GN home">VEXO-GN</a>
      <form class="hdr-tools" role="search" autocomplete="off">
        <input type="search" id="hubFilter" name="q" placeholder="Search zones..." aria-label="Search games" spellcheck="false">
        <select id="hubSort" aria-label="Sort games">
          <option value="az"${sortPref === 'az' ? ' selected' : ''}>Name</option>
          <option value="popular"${sortPref === 'popular' ? ' selected' : ''}>Popular</option>
          <option value="new"${sortPref === 'new' ? ' selected' : ''}>Newest</option>
        </select>
        <select id="hubCat" aria-label="Category">
          <option value="">All</option>
          ${(window.VEXO_CATEGORIES || []).map((c) => `<option value="${slug(c)}"${active === 'cat:' + c ? ' selected' : ''}>${esc(c)}</option>`).join('')}
        </select>
      </form>
      <a class="hdr-link hdr-games" href="${HOME()}#/games">Games</a>
      <a class="hdr-link" href="${HOME()}#/music" data-music>Music</a>
      <a class="hdr-link" href="#" data-movies>Movies</a>
      <a class="hdr-link" href="#" data-fullscreen>Fullscreen</a>
      <a class="hdr-link" href="#" data-settings>Settings</a>`;
    document.body.prepend(header);

    // side menu (shown on computers): logo, pages, music, movies, settings
    const sb = document.createElement('aside');
    sb.className = 'sb'; sb.setAttribute('aria-label', 'Menu');
    sb.innerHTML = `<a class="sb-logo" href="${HOME()}#/" data-home>vexo</a>
      <nav class="sb-nav">
        <a class="sb-item" href="${HOME()}#/" data-home data-sb="home"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-7 9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/></svg><span>Home</span></a>
        <a class="sb-item" href="${HOME()}#/ai" data-sb="ai"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/><circle cx="12" cy="3.5" r="1"/></svg><span>Vexo AI</span></a>
        <a class="sb-item" href="${HOME()}#/web" data-sb="web"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/></svg><span>Search</span></a>
        <a class="sb-item" href="${HOME()}#/me" data-sb="me"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 4h8v5a4 4 0 01-8 0z"/><path d="M8 6H5a3 3 0 003 4M16 6h3a3 3 0 01-3 4M12 13v4M8 21h8M9 17h6"/></svg><span>Progress</span><span class="sb-lv" data-xp-lv>${window.VexoXP ? window.VexoXP.level() : 1}</span></a>
        <a class="sb-item" href="${HOME()}#/games" data-sb="games"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 7h10a5 5 0 015 5v1a4 4 0 01-7 2.6L14 15h-4l-1 .6A4 4 0 012 13v-1a5 5 0 015-5z"/><path d="M7.5 10v4M5.5 12h4"/><circle cx="16" cy="11" r=".8" fill="currentColor"/><circle cx="18" cy="13" r=".8" fill="currentColor"/></svg><span>Games</span></a>
        <a class="sb-item" href="${HOME()}#/favorites" data-sb="favorites">${ICONS.heart}<span>Favorites</span></a>
        <a class="sb-item" href="${HOME()}#/recent" data-sb="recent">${ICONS.clock}<span>Recently played</span></a>
      </nav>
      <nav class="sb-nav sb-bottom">
        <a class="sb-item" href="${HOME()}#/music" data-sb="music" data-music><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg><span>Music</span></a>
        <a class="sb-item" href="#" data-movies data-sb="movies"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/></svg><span>Movies</span></a>
        <a class="sb-item" href="#" data-settings-open>${ICONS.gear}<span>Settings</span></a>
      </nav>`;
    document.body.prepend(sb); document.body.classList.add('has-sb');
    const markSb = () => { const h0 = location.hash.replace(/^#\/?/, '').replace(/\?.*/, '').split('/')[0] || 'home', h = ({ search: 'home', category: 'games', all: 'games' })[h0] || h0; sb.querySelectorAll('[data-sb]').forEach((x) => x.classList.toggle('on', x.dataset.sb === h)); };
    markSb(); addEventListener('hashchange', markSb);
    sb.querySelector('[data-settings-open]').onclick = (e) => { e.preventDefault(); openSettings(); };
    const footer = document.createElement('footer');
    footer.className = 'site-footer';
    footer.innerHTML = `<div class="foot-inner">VEXO-GN · <a href="${HOME()}#/favorites">Favorites</a> · <a href="${HOME()}#/recent">Recently played</a> · <span>Open-source games are credited on each game's info panel.</span></div>`;
    const main = document.querySelector('main');
    if (main) main.after(footer); else document.body.appendChild(footer);

    // search / sort / category: on the hub they act live (home.js listens); elsewhere they go to the hub
    const onHub = !!document.getElementById('view') && /index\.html$|\/$/.test(location.pathname) || location.pathname.endsWith('vexo-gn.html');
    const form = header.querySelector('.hdr-tools');
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const q = header.querySelector('#hubFilter').value.trim();
      if (!window.VexoHub) location.href = 'index.html' + (q ? '#/search/' + encodeURIComponent(q) : '#/');
    });
    header.querySelector('#hubSort').addEventListener('change', (e) => {
      try { localStorage.setItem('vexo_sort', e.target.value); } catch (x) {}
      if (!window.VexoHub) location.href = 'index.html#/';
    });
    header.querySelector('#hubCat').addEventListener('change', (e) => {
      const v = e.target.value;
      if (window.VexoHub) location.hash = v ? '#/category/' + v : '#/';
      else location.href = 'index.html' + (v ? '#/category/' + v : '#/');
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { e.preventDefault(); const big = document.getElementById('heroSearch'); (big && big.offsetParent ? big : header.querySelector('#hubFilter')).focus(); }
    });
    header.querySelector('[data-settings]').onclick = (e) => { e.preventDefault(); openSettings(); };
    const fsLink = header.querySelector('[data-fullscreen]');
    const fsOn = () => !!(document.fullscreenElement || document.webkitFullscreenElement);
    const paintFs = () => { fsLink.textContent = fsOn() ? 'Exit fullscreen' : 'Fullscreen'; };
    fsLink.onclick = (e) => {
      e.preventDefault();
      const el = document.documentElement;
      try {
        if (fsOn()) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
        else {
          const req = el.requestFullscreen || el.webkitRequestFullscreen;
          if (!req) { toast('Fullscreen is not available here. Try pressing F11.'); return; }
          const pr = req.call(el); if (pr && pr.catch) pr.catch(() => toast('Fullscreen was blocked. Try pressing F11.'));
        }
      } catch (x) { toast('Fullscreen was blocked. Try pressing F11.'); }
    };
    document.addEventListener('fullscreenchange', paintFs); document.addEventListener('webkitfullscreenchange', paintFs);
    void onHub;
  }

  function openSettings() {
    const favN = Store.favs().length, recN = Store.recent().length;
    const chev = '<svg class="ic st-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>', curIc = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M5 3v15l4.2-4 3.2 7 2.8-1.2-3.1-6.9H18z"/></svg>';
    const fs = autoFs(), curName = (CUR_SHAPES[curGet().shape] || 'Realistic');
    dialog({ title: 'Settings', ok: 'Done', cancel: '', body: `
      <div class="st">
        <p class="st-lbl">Your games</p>
        <div class="st-group">
          <a class="st-row" href="${HOME()}#/favorites">${ICONS.heart}<span class="st-t">Favorites</span><span class="st-pill">${favN}</span>${chev}</a>
          <a class="st-row" href="${HOME()}#/recent">${ICONS.clock}<span class="st-t">Recently played</span><span class="st-pill">${recN}</span>${chev}</a>
          <a class="st-row" href="#" data-random>${ICONS.shuffle}<span class="st-t">Play a random game</span>${chev}</a>
        </div>
        <p class="st-lbl">Playing</p>
        <div class="st-group">
          <button type="button" class="st-row" data-autofs role="switch" aria-checked="${fs}">${ICONS.expand}<span class="st-t">Start games in full screen<small>Games fill the screen as soon as you tap them</small></span><span class="st-sw${fs ? ' on' : ''}"><i></i></span></button>
        </div>
        <p class="st-lbl">Look</p>
        <div class="st-group">
          <button type="button" class="st-row" data-bg-set><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 16l5-5 4 4 3-3 6 6"/><circle cx="16" cy="9" r="1.5"/></svg><span class="st-t">Background<small>Stars, galaxy, rain, northern lights, snow or your own picture</small></span><span class="st-val">${esc(BGS[bgGet()])}</span>${chev}</button>
          <a class="st-row" href="${HOME()}#/me"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 4h8v5a4 4 0 01-8 0z"/><path d="M8 6H5a3 3 0 003 4M16 6h3a3 3 0 01-3 4M12 13v4M8 21h8M9 17h6"/></svg><span class="st-t">Level and badges<small>See your XP, streak and badges</small></span>${chev}</a>
          <button type="button" class="st-row" data-cursor-set>${curIc}<span class="st-t">Cursor<small>Design, color, size and effects</small></span><span class="st-val">${esc(curName)}</span>${chev}</button>
        </div>
        <p class="st-lbl">Your data</p>
        <div class="st-group">
          <button type="button" class="st-row st-danger" data-clear="recent">${ICONS.trash}<span class="st-t">Clear recently played</span></button>
          <button type="button" class="st-row st-danger" data-clear="favs">${ICONS.trash}<span class="st-t">Clear favorites</span></button>
        </div>
        <p class="st-note">No account needed. Favorites, history and your settings are saved in this browser.</p>
      </div>` });
    setTimeout(() => {
      const box = document.querySelector('.vx-dialog'); if (!box) return;
      box.querySelector('[data-autofs]').onclick = (e) => {
        const on = !autoFs(); setAutoFs(on);
        e.currentTarget.setAttribute('aria-checked', String(on)); e.currentTarget.querySelector('.st-sw').classList.toggle('on', on);
        toast(on ? 'Games will start in full screen' : 'Games will start in the normal player');
      };
      const cs = box.querySelector('[data-cursor-set]'); if (cs) cs.onclick = () => { box.remove(); openCursor(); };
      const bs = box.querySelector('[data-bg-set]'); if (bs) bs.onclick = () => { box.remove(); openBackground(); };
      box.querySelector('[data-random]').onclick = (e) => {
        e.preventDefault();
        const list = Store.games(); if (!list.length) return;
        const g = list[Math.floor(Math.random() * list.length)];
        location.href = window.VexoHub ? '#/play/' + encodeURIComponent(g.id) : 'index.html#/play/' + encodeURIComponent(g.id);
        box.remove();
      };
      box.querySelectorAll('a.st-row[href*="#/"]').forEach((a) => a.addEventListener('click', () => box.remove()));
      box.querySelectorAll('[data-clear]').forEach((b) => (b.onclick = () => {
        if (b.dataset.clear === 'recent') Store.clearRecent(); else LS.set(KEYS.favs, []);
        document.dispatchEvent(new CustomEvent('vexo:favs'));
        document.dispatchEvent(new CustomEvent('vexo:refresh'));
        toast(b.dataset.clear === 'recent' ? 'Recently played cleared' : 'Favorites cleared');
        box.remove();
      }));
    }, 0);
  }

  const credit = (g) => {
    if (!g.author && !g.source) return '';
    const src = /^https:\/\//.test(g.source || '') ? ` · <a href="${esc(g.source)}" target="_blank" rel="noopener">Source code</a>` : '';
    return `By <b>${esc(g.author || 'Unknown')}</b>${g.license ? ` · ${esc(g.license)} license` : ''}${src}`;
  };

  /* ---------------- in-page dialogs (no browser pop-ups) ---------------- */
  function dialog({ title, text = '', ok = 'OK', cancel = 'Cancel', danger = false, fields = [], body = '' }) {
    return new Promise((resolve) => {
      const wrap = document.createElement('div');
      wrap.className = 'modal open vx-dialog';
      wrap.innerHTML = `<form class="modal-box" style="max-width:440px" novalidate>
        <div class="modal-head"><h2>${esc(title)}</h2><button type="button" class="vx-x" data-x-close aria-label="Close">${ICONS.x}</button></div>
        <div class="modal-body" style="grid-template-columns:1fr">
          ${text ? `<p style="margin:0;color:var(--muted)">${text}</p>` : ''}${body}
          ${fields.map((f, i) => `<div class="field"><label for="vxf${i}">${esc(f.label)}</label><input class="input" id="vxf${i}" type="${f.type || 'text'}" ${f.attrs || ''}></div>`).join('')}
          <div class="err" role="alert"></div>
        </div>
        <div class="modal-foot">${cancel ? `<button type="button" class="btn" data-x>${esc(cancel)}</button>` : ''}<button type="submit" class="btn ${danger ? 'danger' : 'primary'}">${esc(ok)}</button></div></form>`;
      document.body.appendChild(wrap);
      const form = wrap.querySelector('form');
      const done = (v) => { wrap.remove(); document.removeEventListener('keydown', esc_); resolve(v); };
      const esc_ = (e) => { if (e.key === 'Escape') done(fields.length ? null : false); };
      document.addEventListener('keydown', esc_);
      const x = wrap.querySelector('[data-x]'); if (x) x.onclick = () => done(fields.length ? null : false);
      wrap.querySelector('[data-x-close]').onclick = () => done(fields.length ? null : false);
      wrap.addEventListener('mousedown', (e) => { if (e.target === wrap) done(fields.length ? null : false); });
      form.onsubmit = (e) => {
        e.preventDefault();
        if (!fields.length) return done(true);
        const vals = fields.map((f, i) => form.querySelector('#vxf' + i).value);
        const err = fields.map((f, i) => f.check && f.check(vals[i], vals)).find(Boolean);
        if (err) { form.querySelector('.err').textContent = err; return; }
        done(vals);
      };
      (form.querySelector('input') || form.querySelector('button[type=submit]')).focus();
    });
  }
  const ask = (title, text, ok = 'Yes', danger = true) => dialog({ title, text, ok, danger });
  const notice = (title, text) => dialog({ title, text, ok: 'OK', cancel: '' });

  /* ---------------- custom cursor: a glowing ring that follows the mouse ---------------- */
  (function cursorFx() {
    if (!window.matchMedia || !matchMedia('(pointer: fine)').matches || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const ring = document.createElement('div'), dot = document.createElement('div');
    ring.className = 'vx-ring'; dot.className = 'vx-dot';
    ring.setAttribute('aria-hidden', 'true'); dot.setAttribute('aria-hidden', 'true');
    const add = () => { document.body.appendChild(ring); document.body.appendChild(dot); };
    if (document.body) add(); else document.addEventListener('DOMContentLoaded', add);
    let mx = -100, my = -100, rx = -100, ry = -100, raf = 0;
    const CLICKABLE = 'a, button, summary, select, label, [role="button"], .card-link, input[type="checkbox"], input[type="range"]';
    function tick() {
      rx += (mx - rx) * 0.2; ry += (my - ry) * 0.2;
      ring.style.transform = `translate(${rx}px, ${ry}px)`;
      raf = Math.abs(mx - rx) + Math.abs(my - ry) > 0.3 ? requestAnimationFrame(tick) : 0;
    }
    document.addEventListener('mousemove', (e) => {
      mx = e.clientX; my = e.clientY;
      dot.style.transform = `translate(${mx}px, ${my}px)`;
      ring.classList.add('on'); dot.classList.add('on');
      ring.classList.toggle('hover', !!(e.target.closest && e.target.closest(CLICKABLE)));
      if (!raf) raf = requestAnimationFrame(tick);
    }, { passive: true });
    document.addEventListener('mousedown', () => ring.classList.add('down'));
    document.addEventListener('mouseup', () => ring.classList.remove('down'));
    // hide it when the mouse leaves the page or goes into a game (the game shows its own cursor)
    const hide = () => { ring.classList.remove('on'); dot.classList.remove('on'); };
    document.addEventListener('mouseleave', hide);
    window.addEventListener('blur', hide);
    document.addEventListener('mouseover', (e) => { if (e.target.tagName === 'IFRAME') hide(); });
    // keep it above full-screen games' controls
    const lift = () => { const host = document.fullscreenElement || document.webkitFullscreenElement || document.body; if (ring.parentNode !== host) { host.appendChild(ring); host.appendChild(dot); } };
    document.addEventListener('fullscreenchange', lift); document.addEventListener('webkitfullscreenchange', lift);
  })();

  /* ---------------- backgrounds: stars (default), galaxy, rain, northern lights, snow, plain black or your own picture ----------------
     All drawn on one canvas in a few batched draw calls per frame so they stay smooth. Picked in Settings > Background. */
  const BG_KEY = 'vexo_bg', BG_PHOTO = 'vexo_bg_photo';
  const BGS = { stars: 'Stars', galaxy: 'Galaxy', rain: 'Rain', aurora: 'Northern lights', snow: 'Snow', black: 'Plain black', photo: 'Your picture' };
  const bgGet = () => { const v = LS.get(BG_KEY, 'stars'); return BGS[v] ? v : 'stars'; };
  const bgPhoto = () => { try { return localStorage.getItem(BG_PHOTO) || ''; } catch (e) { return ''; } };
  const bgEngine = (function () {
    const c = document.createElement('canvas'); c.className = 'vx-stars'; c.setAttribute('aria-hidden', 'true');
    const ph = document.createElement('div'); ph.className = 'vx-photo'; ph.setAttribute('aria-hidden', 'true');
    const add = () => { document.body.prepend(c); document.body.prepend(ph); };
    if (document.body) add(); else document.addEventListener('DOMContentLoaded', add);
    const ctx = c.getContext('2d');
    const still = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    let W = 0, H = 0, DPR = 1, mode = bgGet(), last = performance.now(), running = false;
    const mouse = { x: -999, y: -999 };
    addEventListener('mousemove', (e) => { mouse.x = e.clientX; mouse.y = e.clientY; }, { passive: true });
    addEventListener('mouseout', () => { mouse.x = mouse.y = -999; });
    const rnd = (a, b) => a + Math.random() * (b - a);
    function wrap(p) { if (p.x < -10) p.x = W + 10; if (p.x > W + 10) p.x = -10; if (p.y < -10) p.y = H + 10; if (p.y > H + 10) p.y = -10; }
    // twinkling dust, shared by several backgrounds, drawn in 5 brightness batches
    let dust = [];
    const dustBins = Array.from({ length: 5 }, () => []);
    function drawDust(time, k, scale) {
      for (const d of dustBins) d.length = 0;
      for (const p of dust) { p.x += p.vx * k; p.y += p.vy * k; wrap(p); dustBins[Math.min(4, (Math.abs(Math.sin(time / 1800 + p.t)) * 5) | 0)].push(p); }
      for (let b = 0; b < 5; b++) { const d = dustBins[b]; if (!d.length) continue; ctx.fillStyle = `rgba(255,255,255,${((.25 + .45 * (b + .5) / 5) * (scale || 1)).toFixed(3)})`; ctx.beginPath(); for (const p of d) ctx.rect(p.x, p.y, p.r, p.r); ctx.fill(); }
    }

    /* stars that link up with thin lines (the original Vexo sky) */
    const S = { nodes: [], LINK: 130, lines: Array.from({ length: 6 }, () => []) };
    function starsInit() { S.LINK = Math.max(90, Math.min(150, W / 10)); S.nodes = Array.from({ length: Math.round(Math.min(90, (W * H) / 16000)) }, () => ({ x: rnd(0, W), y: rnd(0, H), r: rnd(1, 2.4), vx: rnd(-.175, .175), vy: rnd(-.175, .175) })); }
    function starsDraw(time, k) {
      drawDust(time, k);
      const N = S.nodes, L = S.lines, B = L.length, LK = S.LINK, L2 = LK * LK, M = 180;
      for (const p of N) { p.x += p.vx * k; p.y += p.vy * k; wrap(p); }
      for (const l of L) l.length = 0;
      for (let i = 0; i < N.length; i++) { const a = N[i]; for (let j = i + 1; j < N.length; j++) { const b2 = N[j], dx = a.x - b2.x, dy = a.y - b2.y, d = dx * dx + dy * dy; if (d < L2) L[Math.min(B - 1, ((1 - Math.sqrt(d) / LK) * B) | 0)].push(a.x, a.y, b2.x, b2.y); } }
      ctx.lineWidth = 1;
      for (let b = 0; b < B; b++) { const l = L[b]; if (!l.length) continue; ctx.strokeStyle = `rgba(255,255,255,${((b + .5) / B * .22).toFixed(3)})`; ctx.beginPath(); for (let i = 0; i < l.length; i += 4) { ctx.moveTo(l[i], l[i + 1]); ctx.lineTo(l[i + 2], l[i + 3]); } ctx.stroke(); }
      if (mouse.x > -900) { // stars reach toward the mouse
        for (const l of L) l.length = 0;
        for (const a of N) { const mx = a.x - mouse.x, my = a.y - mouse.y, md = mx * mx + my * my; if (md < M * M) L[Math.min(B - 1, ((1 - Math.sqrt(md) / M) * B) | 0)].push(a.x, a.y); }
        for (let b = 0; b < B; b++) { const l = L[b]; if (!l.length) continue; ctx.strokeStyle = `rgba(255,255,255,${((b + .5) / B * .3).toFixed(3)})`; ctx.beginPath(); for (let i = 0; i < l.length; i += 2) { ctx.moveTo(l[i], l[i + 1]); ctx.lineTo(mouse.x, mouse.y); } ctx.stroke(); }
      }
      ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.beginPath(); for (const p of N) { ctx.moveTo(p.x + p.r, p.y); ctx.arc(p.x, p.y, p.r, 0, 6.283); } ctx.fill();
    }

    /* galaxy: a spiral galaxy drawn once into its own picture, then slowly turned each frame */
    let gal = null;
    function galaxyInit() {
      const size = Math.round(Math.min(1400, Math.max(W, H) * 1.1)); gal = document.createElement('canvas'); gal.width = gal.height = size;
      const g = gal.getContext('2d'), cx = size / 2, R = size / 2;
      const glow = g.createRadialGradient(cx, cx, 0, cx, cx, R * .35); glow.addColorStop(0, 'rgba(255,244,228,.95)'); glow.addColorStop(.12, 'rgba(255,225,190,.5)'); glow.addColorStop(.4, 'rgba(200,190,255,.16)'); glow.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = glow; g.fillRect(0, 0, size, size);
      const n = Math.min(9000, Math.round(size * 6));
      for (let i = 0; i < n; i++) {
        const arm = i % 2, t = Math.pow(Math.random(), .7), r = t * R * .95, spin = t * 7.5 + arm * Math.PI + rnd(-.35, .35) * (1.2 - t);
        const x = cx + Math.cos(spin) * r + rnd(-1, 1) * R * .04 * (1 - t), y = cx + Math.sin(spin) * r + rnd(-1, 1) * R * .04 * (1 - t);
        const warm = t < .25; const a = (1 - t) * .7 + .1;
        g.fillStyle = warm ? `rgba(255,${200 + (Math.random() * 40) | 0},170,${a.toFixed(2)})` : (Math.random() < .12 ? `rgba(255,170,220,${(a * .8).toFixed(2)})` : `rgba(${170 + (Math.random() * 60) | 0},${190 + (Math.random() * 50) | 0},255,${a.toFixed(2)})`);
        const sz = Math.random() < .03 ? 2 : 1; g.fillRect(x, y, sz, sz);
      }
    }
    function galaxyDraw(time, k) {
      drawDust(time, k * .3);
      if (!gal) return;
      ctx.save(); ctx.translate(W / 2, H / 2); ctx.scale(1, .55); ctx.rotate(still ? .3 : time * .00002);
      ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .75; ctx.drawImage(gal, -gal.width / 2, -gal.height / 2); ctx.restore();
    }

    /* rain: falling streaks, little splashes and the odd flash of lightning */
    let drops = [], splashes = [], flash = 0, nextFlash = 0;
    function rainInit() { drops = Array.from({ length: Math.round(Math.min(320, (W * H) / 6500)) }, () => ({ x: rnd(0, W), y: rnd(-H, H), l: rnd(10, 26), v: rnd(9, 16), a: Math.random() < .3 ? 1 : 0 })); splashes = []; nextFlash = performance.now() + rnd(8000, 16000); }
    function rainDraw(time, k) {
      const wind = 1.6, bins = [[], []];
      for (const d of drops) {
        d.x += wind * k; d.y += d.v * k;
        if (d.y > H) { if (splashes.length < 80 && Math.random() < .5) splashes.push({ x: d.x, y: H - rnd(2, 30), r: 1, life: 1 }); d.y = rnd(-60, -10); d.x = rnd(-50, W); }
        if (d.x > W + 20) d.x = -20;
        bins[d.a].push(d);
      }
      ctx.lineWidth = 1;
      bins.forEach((b, i) => { ctx.strokeStyle = i ? 'rgba(200,215,235,.45)' : 'rgba(200,215,235,.22)'; ctx.beginPath(); for (const d of b) { ctx.moveTo(d.x, d.y); ctx.lineTo(d.x - wind * d.l / d.v, d.y - d.l); } ctx.stroke(); });
      ctx.strokeStyle = 'rgba(200,215,235,.25)'; ctx.beginPath();
      splashes = splashes.filter((s2) => { s2.r += .6 * k; s2.life -= .04 * k; if (s2.life <= 0) return false; ctx.moveTo(s2.x + s2.r, s2.y); ctx.ellipse(s2.x, s2.y, s2.r, s2.r * .3, 0, 0, 6.283); return true; });
      ctx.stroke();
      if (!still && time > nextFlash) { flash = 1; nextFlash = time + rnd(9000, 20000); }
      if (flash > .01) { ctx.fillStyle = `rgba(210,220,255,${(flash * .12).toFixed(3)})`; ctx.fillRect(0, 0, W, H); flash *= Math.pow(.88, k); }
    }

    /* northern lights: soft curtains drawn small, then stretched up (which makes them glow), plus stars */
    let au = null;
    function auroraInit() { au = document.createElement('canvas'); au.width = Math.max(40, Math.ceil(W / 8)); au.height = Math.max(30, Math.ceil(H / 8)); }
    const CURTAINS = [[61, 255, 154, .42, 0], [56, 232, 208, .32, 2.1], [138, 107, 255, .18, 4.2]];
    function auroraDraw(time, k) {
      drawDust(time, k * .2, .8);
      if (!au) return;
      const a = au.getContext('2d'), w = au.width, h = au.height, t = still ? 0 : time * .00025;
      a.clearRect(0, 0, w, h); a.globalCompositeOperation = 'lighter';
      for (const [r, g, b, al, ph2] of CURTAINS) {
        const grad = a.createLinearGradient(0, h * .05, 0, h * .75);
        grad.addColorStop(0, `rgba(${r},${g},${b},0)`); grad.addColorStop(.35, `rgba(${r},${g},${b},${al})`); grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
        a.fillStyle = grad; a.beginPath();
        for (let x = 0; x <= w; x += 2) { const y = h * (.18 + .1 * Math.sin(x * .045 + t * 3 + ph2) + .05 * Math.sin(x * .11 - t * 5 + ph2 * 2)); x ? a.lineTo(x, y) : a.moveTo(x, y); }
        for (let x = w; x >= 0; x -= 2) { const y = h * (.55 + .12 * Math.sin(x * .03 - t * 2 + ph2) + .06 * Math.sin(x * .09 + t * 4)); a.lineTo(x, y); }
        a.closePath(); a.fill();
      }
      // thin bright rays
      a.globalCompositeOperation = 'destination-out'; a.fillStyle = 'rgba(0,0,0,.35)';
      for (let x = 0; x < w; x += 3) { const v = .5 + .5 * Math.sin(x * 1.7 + t * 6); a.globalAlpha = v * .6; a.fillRect(x, 0, 1.5, h); }
      a.globalAlpha = 1; a.globalCompositeOperation = 'source-over';
      ctx.save(); ctx.imageSmoothingEnabled = true; ctx.globalAlpha = .6; ctx.drawImage(au, 0, 0, W, H * .85); ctx.restore();
    }

    /* snow: soft flakes drifting down */
    let flakes = [];
    function snowInit() { flakes = Array.from({ length: Math.round(Math.min(300, (W * H) / 6000)) }, () => ({ x: rnd(0, W), y: rnd(0, H), r: rnd(.8, 3), v: rnd(.4, 1.3), ph: rnd(0, 6.28) })); }
    function snowDraw(time, k) {
      const bins = [[], []];
      for (const f of flakes) { f.y += f.v * k; f.x += Math.sin(time * .001 + f.ph) * .4 * k; if (f.y > H + 5) { f.y = -5; f.x = rnd(0, W); } if (f.x > W + 5) f.x = -5; if (f.x < -5) f.x = W + 5; bins[f.r > 2 ? 1 : 0].push(f); }
      bins.forEach((b, i) => { ctx.fillStyle = i ? 'rgba(255,255,255,.85)' : 'rgba(255,255,255,.5)'; ctx.beginPath(); for (const f of b) { ctx.moveTo(f.x + f.r, f.y); ctx.arc(f.x, f.y, f.r, 0, 6.283); } ctx.fill(); });
    }

    const MODES = { stars: [starsInit, starsDraw], galaxy: [galaxyInit, galaxyDraw], rain: [rainInit, rainDraw], aurora: [auroraInit, auroraDraw], snow: [snowInit, snowDraw] };
    function size() {
      DPR = Math.min(1.5, window.devicePixelRatio || 1); W = innerWidth; H = innerHeight;
      c.width = W * DPR; c.height = H * DPR;
      dust = Array.from({ length: Math.round(Math.min(220, (W * H) / 7000)) }, () => ({ x: rnd(0, W), y: rnd(0, H), r: rnd(.2, 1.2), t: rnd(0, 6.28), vx: rnd(-.04, .04), vy: rnd(-.04, .04) }));
      if (MODES[mode]) MODES[mode][0]();
    }
    function draw(time) {
      if (!ctx) return;
      const k = still ? 0 : Math.min(3, (time - last) / 16.7); last = time;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0); ctx.clearRect(0, 0, W, H);
      if (MODES[mode]) MODES[mode][1](time, k);
    }
    function loop(time) {
      if (!running) return;
      if (!document.hidden && !document.body.classList.contains('viewing')) draw(time); else last = time;
      if (!still) requestAnimationFrame(loop); else running = false;
    }
    function set(m) {
      mode = BGS[m] ? m : 'stars';
      const photo = mode === 'photo' ? bgPhoto() : '';
      ph.style.backgroundImage = photo ? `url("${photo}")` : '';
      document.documentElement.classList.toggle('bg-photo', !!photo);
      c.style.display = MODES[mode] ? '' : 'none';
      size();
      if (MODES[mode]) { if (!running) { running = true; last = performance.now(); requestAnimationFrame((t) => { last = t; draw(t); if (!still) requestAnimationFrame(loop); else running = false; }); } }
      else { running = false; if (ctx) ctx.clearRect(0, 0, c.width, c.height); }
    }
    addEventListener('resize', () => { size(); if (MODES[mode] && still) draw(performance.now()); });
    set(mode);
    return { set, mode: () => mode };
  })();
  function setBackground(m) { LS.set(BG_KEY, m); bgEngine.set(m); document.dispatchEvent(new CustomEvent('vexo:custom')); }

  /* the Background picker (Settings > Background) */
  function openBackground() {
    const tiles = () => Object.keys(BGS).map((k) => `<button type="button" class="bg-tile bg-${k}${bgGet() === k ? ' on' : ''}" data-bg="${k}" aria-pressed="${bgGet() === k}">
        <span class="bg-prev"${k === 'photo' && bgPhoto() ? ` style="background-image:url('${bgPhoto().replace(/'/g, '%27')}')"` : ''}>${k === 'photo' && !bgPhoto() ? '<b>+</b>' : ''}</span><span class="bg-name">${BGS[k]}</span></button>`).join('');
    dialog({ title: 'Background', ok: 'Done', cancel: '', body: `<div class="bg-pick"><div class="bg-grid">${tiles()}</div>
      <input type="file" id="bgFile" accept="image/*" hidden>
      <p class="st-note">Your picture stays on this device only. ${bgPhoto() ? '<button type="button" class="bg-del" data-bg-del>Remove my picture</button>' : ''}</p></div>` });
    setTimeout(() => {
      const box = document.querySelector('.vx-dialog'); if (!box) return;
      const repaint = () => { const g = box.querySelector('.bg-grid'); if (g) g.innerHTML = tiles(); };
      box.addEventListener('click', (e) => {
        const t = e.target.closest('[data-bg]');
        if (t) {
          if (t.dataset.bg === 'photo') { box.querySelector('#bgFile').click(); return; }
          setBackground(t.dataset.bg); repaint(); return;
        }
        if (e.target.closest('[data-bg-del]')) { try { localStorage.removeItem(BG_PHOTO); } catch (x) {} if (bgGet() === 'photo') setBackground('stars'); repaint(); e.target.remove(); toast('Picture removed'); }
      });
      box.querySelector('#bgFile').addEventListener('change', (e) => {
        const f = e.target.files && e.target.files[0]; if (!f) return;
        if (!/^image\//.test(f.type)) { toast('Pick a picture file'); return; }
        const img = new Image(), url = URL.createObjectURL(f);
        img.onload = () => {
          // shrink big photos so they fit in the browser's storage
          const max = 1920, sc = Math.min(1, max / Math.max(img.width, img.height));
          const cv = document.createElement('canvas'); cv.width = Math.round(img.width * sc); cv.height = Math.round(img.height * sc);
          cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); URL.revokeObjectURL(url);
          let data = cv.toDataURL('image/jpeg', .82);
          if (data.length > 3500000) data = cv.toDataURL('image/jpeg', .6);
          try { localStorage.setItem(BG_PHOTO, data); } catch (x) { toast('That picture is too big to save. Try a smaller one.'); return; }
          setBackground('photo'); repaint(); toast('Background set to your picture');
        };
        img.onerror = () => { URL.revokeObjectURL(url); toast("Couldn't open that picture"); };
        img.src = url;
      });
    }, 0);
  }

  /* ---------------- Movies tab: "coming soon" popup with a live countdown ---------------- */
  function moviesCountdown() {
    const at = Date.parse(window.VEXO_MOVIES_AT || '');
    const parts = () => {
      let s = Math.max(0, Math.floor((at - Date.now()) / 1000));
      const d = Math.floor(s / 86400); s %= 86400; const h = Math.floor(s / 3600); s %= 3600; const m = Math.floor(s / 60); s %= 60;
      return [[d, 'DAYS'], [h, 'HOURS'], [m, 'MIN'], [s, 'SEC']];
    };
    const clock = () => parts().map(([n, u]) => `<span class="mv-seg"><b>${String(n).padStart(2, '0')}</b><small>${u}</small></span>`).join('');
    const ready = () => isNaN(at) || Date.now() >= at;
    dialog({ title: 'Movies', ok: 'OK', cancel: '', body: `<div class="mv-box">
      <p class="mv-lead" id="mvLead">${ready() ? 'Movies are coming very soon. Check back shortly.' : 'Movies are coming soon. They open in:'}</p>
      ${ready() ? '' : `<div class="mv-clock" id="mvClock" role="timer">${clock()}</div>`}
      ${window.VexoTrailer ? `<button type="button" class="mv-trailer" data-trailer><svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4.5v15l13-7.5z" fill="currentColor"/></svg>Watch the early release trailer</button>` : ''}</div>` });
    const t = setInterval(() => {
      const el = document.getElementById('mvClock');
      if (!el) { clearInterval(t); return; }
      if (ready()) { el.remove(); document.getElementById('mvLead').textContent = 'Movies are coming very soon. Check back shortly.'; clearInterval(t); return; }
      el.innerHTML = clock();
    }, 1000);
  }
  document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-movies]'); if (!a) return;
    e.preventDefault();
    // open the Movies page (falls back to the countdown popup if the page isn't on this site)
    if (window.VexoMovies && window.VexoHub) location.hash = '#/movies';
    else if (!window.VexoHub) location.href = HOME() + '#/movies';
    else moviesCountdown();
  });

  /* ---------------- custom cursor designer: design, any color, glow, size and follow ring (saved in this browser) ---------------- */
  const CURSOR_KEY = 'vexo_cursor';
  // quick color picks; each is a list of colors (more than one makes a gradient)
  const CUR_COLORS = {
    white: ['#ffffff'], black: ['#111111'], red: ['#ff3b3b'], orange: ['#ff9f1a'], yellow: ['#ffe14d'], lime: ['#a3f54d'], green: ['#2fd67b'],
    cyan: ['#22d3ee'], blue: ['#3b82f6'], purple: ['#9b5de5'], pink: ['#ff5cc8'], gold: ['#ffd76a', '#c8962e'],
    sunset: ['#ff5f6d', '#ffc371'], ocean: ['#00c6ff', '#0052d4'], galaxy: ['#c084fc', '#3b82f6'], rainbow: ['#ff4d4d', '#ffb84d', '#ffe14d', '#3ddc84', '#22d3ee', '#7c6cff', '#ff6bcb']
  };
  const CUR_SHAPES = {
    real: 'Realistic', arrow: 'Arrow', pixel: 'Pixel', sword: 'Sword', lightning: 'Lightning', rocket: 'Rocket', pencil: 'Pencil',
    heart: 'Heart', flame: 'Flame', crown: 'Crown', paw: 'Paw', diamond: 'Diamond', ghost: 'Ghost', smiley: 'Smiley', planet: 'Planet',
    controller: 'Controller', star: 'Star', cross: 'Crosshair', dot: 'Dot', system: 'Normal'
  };
  const CUR_SIZES = { s: 24, m: 32, l: 40, xl: 48 };
  const CUR_DEFAULT = { shape: 'real', color: 'white', custom: '#ff3b3b', size: 'm', ring: false, glow: false };
  const curGet = () => { const c = Object.assign({}, CUR_DEFAULT, LS.get(CURSOR_KEY, {}) || {}); if (!CUR_SHAPES[c.shape]) c.shape = 'real'; if (!CUR_SIZES[c.size]) c.size = 'm'; return c; };
  const curStops = (o) => (o.color === 'custom' && /^#[0-9a-f]{6}$/i.test(o.custom || '') ? [o.custom] : CUR_COLORS[o.color] || CUR_COLORS.white);
  const lum = (hex) => { const n = parseInt(hex.slice(1), 16); return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; };

  // each design: a drawing in a 32x32 box plus the spot that clicks (hot spot)
  const PIXEL_ARROW = ['X', 'XX', 'XOX', 'XOOX', 'XOOOX', 'XOOOOX', 'XOOOOOX', 'XOOOOOOX', 'XOOOOOOOX', 'XOOOOOOOOX', 'XOOOOOOOOOX', 'XOOOOOOXXXXX', 'XOOOXOOX', 'XOOX XOOX', 'XOX  XOOX', 'XX    XOOX', 'X     XOOX', '       XOOX', '        XX'];
  function design(shape, F, E, hover) {
    switch (shape) {
      case 'arrow': return { hx: 4, hy: 3, b: `<path d="M4 3 L4 25 L10 19.5 L14 28 L18 26.2 L14 17.8 L22 17.8 Z" fill="${F}" stroke="${E}" stroke-width="1.6" stroke-linejoin="round"/><path d="M6.5 8 L6.5 19" stroke="#fff" stroke-opacity=".5" stroke-width="1.2" stroke-linecap="round"/>` };
      case 'pixel': {
        let r = ''; PIXEL_ARROW.forEach((row, y) => [...row].forEach((ch, x) => { if (ch === 'X' || ch === 'O') r += `<rect x="${3 + x * 1.5}" y="${2 + y * 1.5}" width="1.55" height="1.55" fill="${ch === 'X' ? E : F}"/>`; }));
        return { hx: 4, hy: 3, b: `<g shape-rendering="crispEdges">${r}</g>` };
      }
      case 'sword': return { hx: 3, hy: 3, b: `<path d="M3 3 L9 4.6 L22.5 18.1 L18.1 22.5 L4.6 9 Z" fill="${F}" stroke="${E}" stroke-width="1.4" stroke-linejoin="round"/><path d="M5 5 L20 20" stroke="#fff" stroke-opacity=".55" stroke-width="1"/><path d="M15.5 26 L26 15.5" stroke="${E}" stroke-width="4.6" stroke-linecap="round"/><path d="M15.5 26 L26 15.5" stroke="${F}" stroke-width="2.4" stroke-linecap="round"/><path d="M22 22 L27 27" stroke="${E}" stroke-width="3.4" stroke-linecap="round"/><circle cx="28.2" cy="28.2" r="2.4" fill="${F}" stroke="${E}" stroke-width="1.2"/>` };
      case 'lightning': return { hx: 7, hy: 2, b: `<path d="M7 2 H20 L15 11.5 H23.5 L9 30 L12.5 16.5 H5.5 Z" fill="${F}" stroke="${E}" stroke-width="1.6" stroke-linejoin="round"/>` };
      case 'rocket': return { hx: 6, hy: 6, b: `<g transform="rotate(-45 16 16)"><path d="M13 21 L16 ${hover ? 31 : 28} L19 21 Z" fill="#ffb84d"/><path d="M14.5 21 L16 ${hover ? 27 : 25} L17.5 21 Z" fill="#fff3a0"/><path d="M11 15 L6.5 21.5 L11 21 Z M21 15 L25.5 21.5 L21 21 Z" fill="${F}" stroke="${E}" stroke-width="1.2" stroke-linejoin="round"/><path d="M16 2 C20.5 6 21.5 12 21 21 H11 C10.5 12 11.5 6 16 2 Z" fill="${F}" stroke="${E}" stroke-width="1.4" stroke-linejoin="round"/><circle cx="16" cy="11" r="2.6" fill="#9fe7ff" stroke="${E}" stroke-width="1.2"/></g>` };
      case 'pencil': return { hx: 3, hy: 3, b: `<path d="M8.2 5.2 L27 24 L24 27 L5.2 8.2 Z" fill="${F}" stroke="${E}" stroke-width="1.4" stroke-linejoin="round"/><path d="M3 3 L8.2 5.2 L5.2 8.2 Z" fill="#f2d2a2" stroke="${E}" stroke-width="1.2" stroke-linejoin="round"/><path d="M3 3 L4.6 3.7 L3.7 4.6 Z" fill="${E}"/><path d="M27 24 L29.2 26.2 Q30 29.6 26.2 29.2 L24 27 Z" fill="#ff9cc2" stroke="${E}" stroke-width="1.2" stroke-linejoin="round"/>` };
      case 'heart': return { hx: 16, hy: 16, b: `<path d="M16 28 C10 23 3 18.5 3 11.5 C3 7.4 6.2 4.5 9.8 4.5 C12.4 4.5 14.6 5.9 16 8 C17.4 5.9 19.6 4.5 22.2 4.5 C25.8 4.5 29 7.4 29 11.5 C29 18.5 22 23 16 28 Z" fill="${F}" stroke="${E}" stroke-width="1.6" stroke-linejoin="round"/><path d="M7.5 9.5 Q8.5 7.2 11 7.2" stroke="#fff" stroke-opacity=".6" stroke-width="1.6" fill="none" stroke-linecap="round"/>` };
      case 'flame': return { hx: 16, hy: 4, b: `<path d="M16 2 C17 8 24.5 11 24.5 19.5 A8.5 8.5 0 0 1 7.5 19.5 C7.5 14 11 12 12 8 C13 11 14 12 15.5 12.5 C15 9 15.4 5 16 2 Z" fill="${F}" stroke="${E}" stroke-width="1.5" stroke-linejoin="round"/><path d="M16 15.5 C17.6 18.4 20.2 19.6 20.2 22.4 A4.2 4.2 0 0 1 11.8 22.4 C11.8 19.8 14.2 18.4 16 15.5 Z" fill="#fff" opacity=".65"/>` };
      case 'crown': return { hx: 16, hy: 16, b: `<path d="M4 23 L4 9.5 L10.5 15.5 L16 5 L21.5 15.5 L28 9.5 L28 23 Z" fill="${F}" stroke="${E}" stroke-width="1.5" stroke-linejoin="round"/><rect x="4" y="23.5" width="24" height="4" rx="1" fill="${F}" stroke="${E}" stroke-width="1.5"/><circle cx="16" cy="18" r="2" fill="#fff" opacity=".8"/><circle cx="10" cy="19.5" r="1.4" fill="#fff" opacity=".6"/><circle cx="22" cy="19.5" r="1.4" fill="#fff" opacity=".6"/>` };
      case 'paw': return { hx: 16, hy: 16, b: `<g fill="${F}" stroke="${E}" stroke-width="1.4"><ellipse cx="16" cy="21.5" rx="7" ry="6"/><circle cx="8.3" cy="13.5" r="3.1"/><circle cx="13" cy="8.4" r="3.1"/><circle cx="19" cy="8.4" r="3.1"/><circle cx="23.7" cy="13.5" r="3.1"/></g>` };
      case 'diamond': return { hx: 16, hy: 16, b: `<path d="M16 29 L3.5 12.5 L9 4 H23 L28.5 12.5 Z" fill="${F}" stroke="${E}" stroke-width="1.5" stroke-linejoin="round"/><path d="M3.5 12.5 H28.5 M9 4 L12.5 12.5 L16 4 L19.5 12.5 L23 4 M12.5 12.5 L16 29 L19.5 12.5" fill="none" stroke="${E}" stroke-width="1" stroke-opacity=".55" stroke-linejoin="round"/><path d="M11 6 L13 10.5" stroke="#fff" stroke-opacity=".7" stroke-width="1.3" stroke-linecap="round"/>` };
      case 'ghost': return { hx: 16, hy: 16, b: `<path d="M6.5 27 V14 A9.5 9.5 0 0 1 25.5 14 V27 q-1.9 3 -3.8 0 q-1.9 3 -3.8 0 q-1.9 3 -3.8 0 q-1.9 3 -3.8 0 q-1.9 3 -3.8 0 Z" fill="${F}" stroke="${E}" stroke-width="1.5" stroke-linejoin="round"/><circle cx="12.6" cy="13.8" r="${hover ? 1.2 : 1.7}" fill="${E}"/><circle cx="19.4" cy="13.8" r="${hover ? 1.2 : 1.7}" fill="${E}"/><ellipse cx="16" cy="19" rx="${hover ? 2.2 : 1.4}" ry="${hover ? 2.4 : 1.6}" fill="${E}"/><ellipse cx="10" cy="17" rx="1.6" ry="1" fill="#ff8fb3" opacity=".7"/><ellipse cx="22" cy="17" rx="1.6" ry="1" fill="#ff8fb3" opacity=".7"/>` };
      case 'smiley': return { hx: 16, hy: 16, b: `<circle cx="16" cy="16" r="12.5" fill="${F}" stroke="${E}" stroke-width="1.6"/><circle cx="11.7" cy="13" r="1.8" fill="${E}"/><circle cx="20.3" cy="13" r="1.8" fill="${E}"/><path d="${hover ? 'M10 18.5 Q16 26 22 18.5 Z' : 'M10.5 19 Q16 24.5 21.5 19'}" fill="${hover ? E : 'none'}" stroke="${E}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>` };
      case 'planet': return { hx: 16, hy: 16, b: `<ellipse cx="16" cy="16" rx="14" ry="4.6" transform="rotate(-20 16 16)" fill="none" stroke="${E}" stroke-width="3.6"/><circle cx="16" cy="16" r="8.5" fill="${F}" stroke="${E}" stroke-width="1.5"/><ellipse cx="16" cy="16" rx="14" ry="4.6" transform="rotate(-20 16 16)" fill="none" stroke="${F}" stroke-width="1.8" stroke-dasharray="22 60" stroke-dashoffset="-34"/><circle cx="13" cy="12.5" r="1.6" fill="#fff" opacity=".55"/>` };
      case 'controller': return { hx: 16, hy: 16, b: `<path d="M9 9.5 H23 C27.5 9.5 30.5 15 30.5 21.5 C30.5 25.8 27.6 27.4 25 25.2 L21.5 21.8 H10.5 L7 25.2 C4.4 27.4 1.5 25.8 1.5 21.5 C1.5 15 4.5 9.5 9 9.5 Z" fill="${F}" stroke="${E}" stroke-width="1.5" stroke-linejoin="round"/><path d="M9 13.2 V19 M6.1 16.1 H11.9" stroke="${E}" stroke-width="2.2" stroke-linecap="round"/><circle cx="22.5" cy="14" r="1.5" fill="${E}"/><circle cx="25.5" cy="17" r="1.5" fill="${E}"/><circle cx="19.5" cy="17" r="1.5" fill="${E}"/><circle cx="22.5" cy="20" r="1.5" fill="${E}"/>` };
      case 'star': return { hx: 16, hy: 16, b: `<path d="M16 2.5l3.9 8.1 8.8 1.2-6.4 6.1 1.6 8.8L16 22.5l-7.9 4.2 1.6-8.8-6.4-6.1 8.8-1.2z" fill="${F}" stroke="${E}" stroke-width="1.6" stroke-linejoin="round"/>` };
      case 'cross': return { hx: 16, hy: 16, b: `<g stroke="${E}" stroke-width="5" stroke-linecap="round"><path d="M16 3v8M16 21v8M3 16h8M21 16h8"/></g><g stroke="${F}" stroke-width="2.6" stroke-linecap="round"><path d="M16 3v8M16 21v8M3 16h8M21 16h8"/></g><circle cx="16" cy="16" r="2" fill="${F}" stroke="${E}" stroke-width="1"/>` };
      case 'dot': return { hx: 16, hy: 16, b: `<circle cx="16" cy="16" r="6" fill="${F}" stroke="${E}" stroke-width="2"/>` };
      default: return null;
    }
  }
  function cursorSvg(o, hover) {
    const stops = curStops(o), c1 = stops[0], px = CUR_SIZES[o.size] || 32, k = px / 32;
    const light = lum(c1) > 0.55, E = light ? '#000' : '#fff', F = 'url(#g)';
    const grad = `<linearGradient id="g" x1="0" y1="0" x2="1" y2="1">${(stops.length > 1 ? stops : [c1, c1]).map((s, i, a) => `<stop offset="${(i / (a.length - 1)).toFixed(3)}" stop-color="${s}"/>`).join('')}</linearGradient>`;
    const glowF = `<filter id="gl" x="-40%" y="-40%" width="180%" height="180%"><feDropShadow dx="0" dy="0" stdDeviation="1.3" flood-color="${c1}" flood-opacity=".95"/></filter>`;
    const shadowF = '<filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="0.9"/></filter>';
    let body, hx, hy;
    if (o.shape === 'real') { // realistic: classic arrow, pointing hand over things you can click
      const edge = light ? '#000' : '#fff';
      const p = hover
        ? 'M11.5 4.2a2 2 0 0 1 4 0V13a1.8 1.8 0 0 1 3.5.2v.8a1.75 1.75 0 0 1 3.5.3v.7a1.6 1.6 0 0 1 3.2.5V22c0 4.1-2.5 7-6.5 7h-3.7c-2.4 0-3.9-1-5.1-2.8l-3.8-5.7c-.9-1.4-.5-2.9.8-3.5 1.1-.5 2.3-.1 3.1.9l1 1.4z'
        : 'M4 2.5V24.2L9.4 19L13.1 27.4L16.5 25.9L12.9 17.7H20.4Z';
      body = `<path d="${p}" fill="#000" opacity=".35" transform="translate(1 1.4)" filter="url(#sh)"/><path d="${p}" fill="${F}" stroke="${edge}" stroke-width="1.3" stroke-linejoin="round"/>` +
        (hover ? `<path d="M15.5 14.2v4.2M19 14.6v3.8M22.5 15.4v3.2" stroke="${edge}" stroke-width="1" stroke-linecap="round" opacity=".55"/>` : '');
      hx = hover ? 13.5 : 4; hy = hover ? 2.4 : 2.5;
    } else {
      const d = design(o.shape, F, E, hover) || design('arrow', F, E, hover);
      hx = d.hx; hy = d.hy;
      // over something you can click, the design grows a little and glows
      body = hover ? `<g filter="url(#gl)" transform="translate(${hx} ${hy}) scale(1.1) translate(${-hx} ${-hy})">${d.b}</g>` : d.b;
    }
    if (o.glow && !hover) body = `<g filter="url(#gl)">${body}</g>`;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${px}" height="${px}" viewBox="0 0 32 32"><defs>${grad}${glowF}${shadowF}</defs>${body}</svg>`;
    return `url("data:image/svg+xml,${encodeURIComponent(svg)}") ${Math.round(hx * k)} ${Math.round(hy * k)}`;
  }
  function applyCursor() {
    const o = curGet(); let st = document.getElementById('vx-cursor-style');
    if (!st) { st = document.createElement('style'); st.id = 'vx-cursor-style'; (document.head || document.documentElement).appendChild(st); }
    const CLICK = 'a, button, summary, select, label, [role="button"], .card-link, input[type="checkbox"], input[type="range"], input[type="color"]';
    const c1 = curStops(o)[0];
    let css = '@media (pointer: fine) {';
    if (o.shape === 'system') css += `html, body { cursor: auto !important; } ${CLICK} { cursor: pointer !important; }`;
    else css += `html, body { cursor: ${cursorSvg(o, false)}, auto !important; } ${CLICK} { cursor: ${cursorSvg(o, true)}, pointer !important; }`;
    css += 'input[type="text"], input[type="search"], input[type="url"], input[type="password"], input[type="number"], input:not([type]), textarea { cursor: text !important; }';
    css += `.vx-ring { border-color: ${c1}cc !important; box-shadow: 0 0 14px ${c1}88, inset 0 0 10px ${c1}44 !important; } .vx-ring.hover { border-color: ${c1} !important; background: ${c1}1a !important; } .vx-dot { box-shadow: 0 0 8px ${c1}, 0 0 16px ${c1} !important; }`;
    if (!o.ring || o.shape === 'system') css += '.vx-ring, .vx-dot { display: none !important; }';
    st.textContent = css + '}';
  }
  applyCursor();
  function openCursor() {
    const img = (o, hover) => esc(cursorSvg(o, hover).match(/url\("(.*?)"\)/)[1]);
    const swatch = (k) => { const s = CUR_COLORS[k]; return s.length > 1 ? `linear-gradient(135deg,${s.join(',')})` : s[0]; };
    const body = () => {
      const c = curGet();
      return `<div class="cur-set">
        <div class="cur-preview">${c.shape === 'system' ? '<span class="cur-sys big">↖</span>' : `<img src="${img(c, false)}" alt="Your cursor"><img src="${img(c, true)}" alt="Your cursor over a game">`}<small>${c.shape === 'system' ? 'Your computer\'s normal cursor' : 'Normal &nbsp;·&nbsp; over a game or button'}</small></div>
        <p class="cur-lbl">Design</p><div class="cur-grid">${Object.keys(CUR_SHAPES).map((k) => `<button type="button" class="cur-opt${c.shape === k ? ' on' : ''}" data-cur-shape="${k}" title="${CUR_SHAPES[k]}">${k === 'system' ? '<span class="cur-sys">↖</span>' : `<img src="${img(Object.assign({}, c, { shape: k, size: 'm', glow: false }), false)}" alt="">`}<span>${CUR_SHAPES[k]}</span></button>`).join('')}</div>
        <p class="cur-lbl">Color</p><div class="cur-row">${Object.keys(CUR_COLORS).map((k) => `<button type="button" class="cur-sw${c.color === k ? ' on' : ''}" data-cur-color="${k}" style="background:${swatch(k)}" aria-label="${k}" title="${k[0].toUpperCase() + k.slice(1)}"></button>`).join('')}
          <label class="cur-any${c.color === 'custom' ? ' on' : ''}" title="Pick any color"><input type="color" id="curCustom" value="${esc(c.custom)}" aria-label="Pick any color"><span>Any color</span></label></div>
        <p class="cur-lbl">Size</p><div class="cur-row">${[['s', 'Small'], ['m', 'Medium'], ['l', 'Large'], ['xl', 'Extra large']].map(([k, n]) => `<button type="button" class="cur-pill${c.size === k ? ' on' : ''}" data-cur-size="${k}">${n}</button>`).join('')}</div>
        <p class="cur-lbl">Effects</p><div class="cur-row">
          <button type="button" class="cur-pill${c.glow ? ' on' : ''}" data-cur-glow="${c.glow ? 0 : 1}">Glow: ${c.glow ? 'On' : 'Off'}</button>
          <button type="button" class="cur-pill${c.ring ? ' on' : ''}" data-cur-ring="${c.ring ? 0 : 1}">Follow ring: ${c.ring ? 'On' : 'Off'}</button></div>
        <div class="cur-try">Move your mouse here to try it</div>
        <button type="button" class="cur-reset" data-cur-reset>Reset to default</button>
        <p class="cur-note">Works with a mouse or trackpad (like a Chromebook). Phones and tablets don't show a cursor. Inside a game, the game uses its own cursor.</p></div>`;
    };
    dialog({ title: 'Cursor', ok: 'Done', cancel: '', body: body() });
    setTimeout(() => {
      const box = document.querySelector('.vx-dialog'); if (!box) return;
      const save = (c) => { LS.set(CURSOR_KEY, c); applyCursor(); document.dispatchEvent(new CustomEvent('vexo:custom')); const scroll = box.querySelector('.modal-body') ? box.querySelector('.modal-body').scrollTop : 0; box.querySelector('.cur-set').outerHTML = body(); if (box.querySelector('.modal-body')) box.querySelector('.modal-body').scrollTop = scroll; };
      box.addEventListener('click', (e) => {
        const b = e.target.closest('[data-cur-shape],[data-cur-color],[data-cur-size],[data-cur-ring],[data-cur-glow],[data-cur-reset]'); if (!b) return;
        let c = curGet();
        if (b.dataset.curShape) c.shape = b.dataset.curShape;
        if (b.dataset.curColor) c.color = b.dataset.curColor;
        if (b.dataset.curSize) c.size = b.dataset.curSize;
        if (b.dataset.curRing) c.ring = b.dataset.curRing === '1';
        if (b.dataset.curGlow) c.glow = b.dataset.curGlow === '1';
        if (b.hasAttribute('data-cur-reset')) c = Object.assign({}, CUR_DEFAULT);
        save(c);
      });
      box.addEventListener('input', (e) => {
        if (e.target.id !== 'curCustom') return;
        const c = curGet(); c.color = 'custom'; c.custom = e.target.value; LS.set(CURSOR_KEY, c); applyCursor();
        const pv = box.querySelectorAll('.cur-preview img'); if (pv.length === 2) { pv[0].src = cursorSvg(c, false).match(/url\("(.*?)"\)/)[1]; pv[1].src = cursorSvg(c, true).match(/url\("(.*?)"\)/)[1]; }
      });
      box.addEventListener('change', (e) => { if (e.target.id === 'curCustom') save(curGet()); });
    }, 0);
  }

  /* ---------------- ads (Google AdSense, set up in data.js) ---------------- */
  const adCfg = () => { const c = window.VEXO_ADS || {}; return /^ca-pub-\d{10,20}$/.test(c.client || '') ? c : null; };
  function adSlot(name) {
    const c = adCfg(); const id = c && c.slots && String(c.slots[name] || '');
    if (!c || !/^\d{5,20}$/.test(id)) return '';
    return `<aside class="vx-ad" aria-label="Advertisement"><small>Ad</small><ins class="adsbygoogle" style="display:block" data-ad-client="${esc(c.client)}" data-ad-slot="${esc(id)}" data-ad-format="auto" data-full-width-responsive="true"></ins></aside>`;
  }
  let adScript = false;
  let adBlocked = false, adWaiting = null;
  function loadAdScript() {
    const c = adCfg(); if (!c || adScript) return;
    adScript = true;
    window.adsbygoogle = window.adsbygoogle || [];
    const sc = document.createElement('script'); sc.async = true; sc.crossOrigin = 'anonymous';
    sc.setAttribute('data-ad-client', c.client);
    if (c.gameAds !== false) sc.setAttribute('data-ad-frequency-hint', /^\d+(s|m)$/.test(c.gameAdEvery || '') ? c.gameAdEvery : '60s');
    if (c.adTest) sc.setAttribute('data-adbreak-test', 'on');
    sc.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(c.client);
    sc.onerror = () => { adBlocked = true; document.querySelectorAll('.vx-ad').forEach((a) => a.remove()); if (adWaiting) adWaiting(); }; // blocked: hide the empty spots
    document.head.appendChild(sc);
    // Google's Ad Placement API for game sites: get full-screen ads ready ahead of time
    if (c.gameAds !== false) window.adsbygoogle.push({ preloadAdBreaks: 'on', sound: 'on' });
  }
  /* a full-screen Google ad before a game starts (only when ads are set up in data.js).
     done() always runs: right after the ad, or right away when there's no ad, ads are blocked, or ads aren't set up. */
  function adBeforeGame(name, done) {
    const c = adCfg();
    if (!c || c.gameAds === false || adBlocked) { done(); return; }
    loadAdScript();
    let finished = false, started = false;
    const finish = () => { if (finished) return; finished = true; adWaiting = null; clearTimeout(safety); document.body.classList.remove('vx-ad-on'); done(); };
    adWaiting = finish; // if an ad blocker stops Google's script, start the game right away
    const safety = setTimeout(() => { if (!started) finish(); }, 2500); // nothing showed up: don't keep the player waiting
    try {
      window.adsbygoogle.push({
        type: 'start', name: String(name || 'game-start').slice(0, 60),
        beforeAd: () => { started = true; document.body.classList.add('vx-ad-on'); document.dispatchEvent(new CustomEvent('vexo:ad')); },
        afterAd: () => { document.body.classList.remove('vx-ad-on'); },
        adBreakDone: () => finish()
      });
    } catch (e) { finish(); }
  }
  function fillAds() {
    const c = adCfg(); if (!c) return;
    loadAdScript();
    document.querySelectorAll('.vx-ad ins.adsbygoogle:not([data-vx-filled])').forEach((ins) => {
      ins.setAttribute('data-vx-filled', '1');
      try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}
    });
  }

  window.Vexo = { adBeforeGame, setBackground, openBackground, adSlot, fillAds, autoFs, openFullWindow, dialog, ask, notice, credit, Store, ICONS, CAT_COLORS, catIcon, esc, slug, catBySlug, isNew, card, toast, shell, search, thumbOf, autoThumb, popScore, LOGO_MARK, hash };
})();
