/* VEXO-GN - Vexo AI (#/ai): a chat page.
   Two brains to pick from at the top:
   - Vexo AI: Pollinations' free text AI (no key or sign-up needed).
   - Claude: Anthropic's Claude, using the visitor's own Claude API key. The key is saved only
     in that visitor's browser and sent only to api.anthropic.com.
   When an answer mentions one of VEXO-GN's games, a Play button for it appears under the answer.
   The chat is saved in this browser. */
(function () {
  'use strict';
  const { esc, Store, toast } = window.Vexo;
  const KEY = 'vexo_ai_chat';
  const load = () => { try { const v = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(v) ? v.filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string') : []; } catch (e) { return []; } };
  const save = (l) => { try { localStorage.setItem(KEY, JSON.stringify(l.slice(-40))); } catch (e) {} };
  let msgs = load(), busy = false, keyOpen = false;

  /* which AI answers: 'vexo' (free) or 'claude' (needs the visitor's own key) */
  const ENGINE_KEY = 'vexo_ai_engine', CKEY = 'vexo_ai_claude_key';
  const CLAUDE_MODEL = 'claude-opus-5-5';
  const get = (k) => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
  const put = (k, v) => { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (e) {} };
  let engine = get(ENGINE_KEY) === 'claude' ? 'claude' : 'vexo';
  const claudeKey = () => get(CKEY);

  const BOT = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/><circle cx="12" cy="3.5" r="1"/></svg>';
  const CLAUDE = '<svg class="ic" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2.5l1.6 6.1 5.1-3.7-3.2 5.4 6 .9-6 1.6 4 4.7-5.5-2.7.2 6.2-2.2-5.9-2.2 5.9.2-6.2L4.5 17.5l4-4.7-6-1.6 6-.9L5.3 4.9l5.1 3.7z"/></svg>';
  const SEND = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
  const SUGGEST = ['Recommend a fun 2 player game', 'What should I play if I like racing?', 'Help me study for a math test', 'Tell me a joke', 'Explain photosynthesis simply', 'Give me a fun fact'];

  function system() {
    const games = Store.games().map((g) => g.title).join(', ');
    return 'You are Vexo AI, the friendly helper on VEXO-GN, a free games website. Many users are teens, so keep answers safe, kind and appropriate for school. ' +
      'Keep answers short and clear (a few sentences or a short list) unless asked for more. Help with homework by explaining, not just giving answers. ' +
      'When recommending games, prefer games on VEXO-GN and write their exact names. VEXO-GN has these games: ' + games + '. ' +
      'Do not help anyone get around school or work internet filters, and do not write out full song lyrics or long copied text from books or articles.';
  }

  /* ---------- talking to the AI ---------- */
  function withTimeout(ms) { const c = new AbortController(); setTimeout(() => c.abort(), ms); return c.signal; }
  async function ask(history) {
    const messages = [{ role: 'system', content: system() }].concat(history.slice(-12).map((m) => ({ role: m.role, content: m.content.slice(0, 4000) })));
    try {
      const r = await fetch('https://text.pollinations.ai/openai', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: 'openai', messages, private: true }), signal: withTimeout(45000) });
      if (r.ok) {
        const j = await r.json();
        const t = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
        if (t && String(t).trim()) return String(t).trim();
      }
    } catch (e) { /* try the simple way below */ }
    const last = history[history.length - 1].content.slice(0, 1500);
    const r2 = await fetch('https://text.pollinations.ai/' + encodeURIComponent(last) + '?model=openai&private=true&system=' + encodeURIComponent(system().slice(0, 1800)), { signal: withTimeout(45000) });
    if (!r2.ok) throw new Error('http ' + r2.status);
    const t2 = (await r2.text()).trim();
    if (!t2) throw new Error('empty');
    return t2;
  }

  /* ---------- talking to Claude ---------- */
  function claudeHistory(history) {
    // Claude wants turns that go user, assistant, user... and start with the user.
    const out = [];
    for (const m of history.slice(-16)) {
      if (m.err) continue;
      const content = m.content.slice(0, 4000);
      const last = out[out.length - 1];
      if (last && last.role === m.role) last.content += '\n\n' + content;
      else out.push({ role: m.role, content });
    }
    while (out.length && out[0].role !== 'user') out.shift();
    return out;
  }
  async function askClaude(history) {
    const key = claudeKey();
    if (!key) { const e = new Error('nokey'); e.kind = 'nokey'; throw e; }
    let r;
    try {
      r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': key,
          'anthropic-version': '2026-10-21',
          'anthropic-beta': 'server-side-fallback-2026-07-01',
          'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify({
          model: CLAUDE_MODEL,
          max_tokens: 16000,
          system: system(),
          messages: claudeHistory(history),
          output_config: { effort: 'low' },
          fallbacks: 'default'
        }),
        signal: withTimeout(90000)
      });
    } catch (x) { const e = new Error('net'); e.kind = 'net'; throw e; }
    let j = null; try { j = await r.json(); } catch (x) {}
    if (!r.ok) {
      const e = new Error('http ' + r.status);
      e.kind = r.status === 401 || r.status === 403 ? 'badkey' : r.status === 429 ? 'busy' : (r.status === 400 && j && j.error && /credit|billing/i.test(j.error.message || '')) ? 'credit' : r.status >= 500 ? 'down' : 'other';
      throw e;
    }
    if (!j) throw new Error('empty');
    if (j.stop_reason === 'refusal') return "I can't help with that one. Try asking something else!";
    const t = (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('').trim();
    if (!t) throw new Error('empty');
    return t;
  }
  const CLAUDE_ERR = {
    nokey: 'To use Claude, add your Claude API key first. Tap "Claude key" at the top.',
    badkey: "That Claude key didn't work. Check it and paste it again with the \"Claude key\" button at the top.",
    credit: 'Your Claude account is out of credit. Add credit at console.anthropic.com, or switch to Vexo AI (free) at the top.',
    busy: 'Claude is getting too many messages right now. Wait a minute and try again.',
    down: 'Claude is having trouble right now. Try again in a minute, or switch to Vexo AI at the top.',
    net: "I can't reach Claude right now. The network might be blocking it. Try again later, or switch to Vexo AI at the top."
  };

  /* ---------- showing messages ---------- */
  function md(text) {
    const lines = esc(text).replace(/\r/g, '').split('\n');
    let out = '', list = '';
    const inline = (s) => s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/`([^`]+)`/g, '<code>$1</code>').replace(/(^|[\s(])\*(?!\s)(.+?)\*(?=[\s).,!?]|$)/g, '$1<i>$2</i>');
    const close = () => { if (list) { out += `</${list}>`; list = ''; } };
    for (const raw of lines) {
      const l = raw.trim();
      let m;
      if ((m = l.match(/^[-*•]\s+(.*)/))) { if (list !== 'ul') { close(); out += '<ul>'; list = 'ul'; } out += `<li>${inline(m[1])}</li>`; }
      else if ((m = l.match(/^\d+[.)]\s+(.*)/))) { if (list !== 'ol') { close(); out += '<ol>'; list = 'ol'; } out += `<li>${inline(m[1])}</li>`; }
      else if ((m = l.match(/^#{1,4}\s+(.*)/))) { close(); out += `<p><b>${inline(m[1])}</b></p>`; }
      else if (!l) close();
      else { close(); out += `<p>${inline(l)}</p>`; }
    }
    close();
    return out;
  }
  function gamesIn(text) {
    const t = text.toLowerCase(), seen = new Set();
    return Store.games().filter((g) => g.title.length >= 4 && t.includes(g.title.toLowerCase()) && !seen.has(g.id) && seen.add(g.id)).slice(0, 4);
  }
  function bubble(m, i) {
    if (m.role === 'user') return `<div class="ai-msg ai-user"><div class="ai-b">${esc(m.content).replace(/\n/g, '<br>')}</div></div>`;
    const gs = gamesIn(m.content);
    return `<div class="ai-msg ai-bot"><span class="ai-av${m.by === 'claude' ? ' is-claude' : ''}">${m.by === 'claude' ? CLAUDE : BOT}</span><div class="ai-b">${m.by === 'claude' ? '<span class="ai-by">Claude</span>' : ''}${md(m.content)}
      ${gs.length ? `<div class="ai-games">${gs.map((g) => `<a class="ai-play" href="#/play/${encodeURIComponent(g.id)}" data-open="${esc(g.id)}"><svg class="ic" viewBox="0 0 24 24"><path d="M7 4.5v15l13-7.5z" fill="currentColor"/></svg>Play ${esc(g.title)}</a>`).join('')}</div>` : ''}
      <button type="button" class="ai-copy" data-ai-copy="${i}">Copy</button></div></div>`;
  }
  function thread() {
    if (!msgs.length) return `<div class="ai-hello"><span class="ai-big">${BOT}</span><h2>Hi, I'm Vexo AI</h2><p>Ask me anything: game picks, homework help, fun facts or jokes.</p>
      <div class="ai-sugs">${SUGGEST.map((s) => `<button type="button" class="ai-sug" data-ai-sug="${esc(s)}">${esc(s)}</button>`).join('')}</div></div>`;
    return msgs.map(bubble).join('') + (busy ? `<div class="ai-msg ai-bot"><span class="ai-av">${BOT}</span><div class="ai-b ai-typing" aria-label="Vexo AI is typing"><i></i><i></i><i></i></div></div>` : '');
  }
  function page() {
    return `<div class="ai">
      <header class="ai-top"><span class="ai-title">${BOT}<b>Vexo AI</b></span>
        <div class="ai-tools">
          <div class="ai-pick" role="group" aria-label="Choose which AI answers">
            <button type="button" data-ai-engine="vexo" aria-pressed="${engine === 'vexo'}">Vexo AI <small>free</small></button>
            <button type="button" data-ai-engine="claude" aria-pressed="${engine === 'claude'}">${CLAUDE}Claude</button>
          </div>
          <button type="button" class="mp-btn" data-ai-key ${engine === 'claude' ? '' : 'hidden'}>Claude key</button>
          <button type="button" class="mp-btn" data-ai-new>New chat</button>
        </div></header>
      <div id="aiKeyBox">${keyBox()}</div>
      <div class="ai-thread" id="aiThread" aria-live="polite">${thread()}</div>
      <form class="ai-form" data-ai-form novalidate>
        <textarea id="aiInput" rows="1" placeholder="${engine === 'claude' ? 'Message Claude' : 'Message Vexo AI'}" aria-label="Message the AI" maxlength="2000"></textarea>
        <button type="submit" class="ai-send" aria-label="Send">${SEND}</button>
      </form>
      <p class="ai-foot">Vexo AI can make mistakes, so double-check important stuff. Don't share private info like passwords or your address.</p>
    </div>`;
  }
  function keyBox() {
    if (!(engine === 'claude' && (keyOpen || !claudeKey()))) return '';
    const has = !!claudeKey();
    return `<form class="ai-key" data-ai-keyform novalidate>
      <b>${has ? 'Your Claude key' : 'Add your Claude API key to use Claude'}</b>
      <p>Get one at <a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener">console.anthropic.com</a>. Claude costs a little money per message, and it's billed to that key's account. Your key is saved only on this device and only sent to Anthropic. Never share it with anyone.</p>
      <div class="ai-key-row"><input id="aiKeyIn" type="password" autocomplete="off" spellcheck="false" placeholder="${has ? 'Key saved. Paste a new one to change it' : 'sk-ant-...'}" aria-label="Claude API key">
        <button type="submit" class="mp-btn is-on">Save</button>
        ${has ? '<button type="button" class="mp-btn" data-ai-keydel>Remove key</button>' : ''}</div>
    </form>`;
  }
  function paintTop() {
    document.querySelectorAll('[data-ai-engine]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.aiEngine === engine)));
    const k = document.querySelector('[data-ai-key]'); if (k) k.hidden = engine !== 'claude';
    const box = document.getElementById('aiKeyBox'); if (box) box.innerHTML = keyBox();
    const i = document.getElementById('aiInput'); if (i) i.placeholder = engine === 'claude' ? 'Message Claude' : 'Message Vexo AI';
  }
  function paint() {
    const t = document.getElementById('aiThread'); if (!t) return;
    t.innerHTML = thread(); t.scrollTop = t.scrollHeight;
    const b = document.querySelector('.ai-send'); if (b) b.disabled = busy;
  }
  function mounted() { paint(); const i = document.getElementById('aiInput'); if (i && matchMedia('(pointer: fine)').matches) i.focus(); }

  async function send(text) {
    text = String(text || '').trim(); if (!text || busy) return;
    msgs.push({ role: 'user', content: text.slice(0, 2000) }); save(msgs);
    document.dispatchEvent(new CustomEvent('vexo:ai'));
    busy = true; paint();
    const by = engine;
    try {
      const reply = by === 'claude' ? await askClaude(msgs) : await ask(msgs);
      msgs.push({ role: 'assistant', content: reply.slice(0, 8000), by }); save(msgs);
    } catch (e) {
      const t = by === 'claude' ? (CLAUDE_ERR[e.kind] || "Sorry, Claude couldn't answer that. Try again in a minute.") : "Sorry, I can't connect right now. The network might be blocking me, or the AI is busy. Try again in a minute.";
      msgs.push({ role: 'assistant', content: t, by, err: true });
      if (e.kind === 'nokey' || e.kind === 'badkey') { keyOpen = true; paintTop(); }
    }
    busy = false; paint();
  }

  /* ---------- clicks and typing ---------- */
  document.addEventListener('submit', (e) => {
    if (e.target.matches('[data-ai-keyform]')) {
      e.preventDefault();
      const v = (document.getElementById('aiKeyIn').value || '').trim();
      if (!v) { toast('Paste your Claude key first'); return; }
      if (!/^sk-ant-/.test(v)) { toast('That doesn\'t look like a Claude key. It starts with sk-ant-'); return; }
      put(CKEY, v); keyOpen = false; paintTop(); toast('Claude key saved on this device');
      const i = document.getElementById('aiInput'); if (i) i.focus();
      return;
    }
    if (!e.target.matches('[data-ai-form]')) return;
    e.preventDefault(); const i = document.getElementById('aiInput'); const v = i.value; i.value = ''; i.style.height = ''; send(v);
  });
  document.addEventListener('keydown', (e) => {
    if (e.target.id === 'aiInput' && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); e.target.form.requestSubmit ? e.target.form.requestSubmit() : e.target.form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); }
  });
  document.addEventListener('input', (e) => { if (e.target.id === 'aiInput') { e.target.style.height = ''; e.target.style.height = Math.min(160, e.target.scrollHeight) + 'px'; } });
  document.addEventListener('click', async (e) => {
    const s = e.target.closest('[data-ai-sug]'); if (s) { send(s.dataset.aiSug); return; }
    const en = e.target.closest('[data-ai-engine]');
    if (en) { engine = en.dataset.aiEngine === 'claude' ? 'claude' : 'vexo'; put(ENGINE_KEY, engine); keyOpen = false; paintTop(); return; }
    if (e.target.closest('[data-ai-key]')) { keyOpen = !keyOpen; paintTop(); const k = document.getElementById('aiKeyIn'); if (k) k.focus(); return; }
    if (e.target.closest('[data-ai-keydel]')) { put(CKEY, ''); keyOpen = false; paintTop(); toast('Claude key removed'); return; }
    if (e.target.closest('[data-ai-new]')) { if (busy) return; msgs = []; save(msgs); paint(); const i = document.getElementById('aiInput'); if (i) i.focus(); return; }
    const c = e.target.closest('[data-ai-copy]');
    if (c) { const m = msgs[Number(c.dataset.aiCopy)]; if (!m) return; try { await navigator.clipboard.writeText(m.content); toast('Copied'); } catch (x) { toast("Couldn't copy. Select the text instead."); } }
  });

  // short answer for the Vexo Search page (always the free Vexo AI, so searching never costs money)
  const answer = (q) => ask([{ role: 'user', content: String(q).slice(0, 500) + '\n\nAnswer this search in 2 to 4 short sentences.' }]);
  window.VexoAI = { page, mounted, send, answer, md, messages: () => msgs.slice(), busy: () => busy, engine: () => engine };
})();
