/* VEXO-GN - hub page: collapsible game sections + in-page game viewer (hash routed) */
(function () {
  'use strict';
  const { autoFs, openFullWindow, credit, Store, ICONS, CAT_COLORS, catIcon, esc, slug, catBySlug, card, shell, search, thumbOf, autoThumb, popScore, toast } = window.Vexo;
  const view = document.getElementById('view');
  const CATS = window.VEXO_CATEGORIES || [];

  const byPopular = (list) => { const p = Store.plays(); return list.slice().sort((a, b) => popScore(b, p) - popScore(a, p)); };
  const byNew = (list) => list.slice().sort((a, b) => String(b.added || '').localeCompare(String(a.added || '')));
  const byName = (list) => list.slice().sort((a, b) => a.title.localeCompare(b.title));
  const sorters = { az: byName, popular: byPopular, new: byNew };
  const pref = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };
  const setPref = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
  let sort = pref('vexo_sort', 'az');
  let filterText = '';
  const closed = new Set((() => { try { const v = JSON.parse(pref('vexo_closed', '[]')); return Array.isArray(v) ? v : []; } catch (e) { return []; } })());

  /* ---------- building blocks ---------- */
  const grid = (list, opts = {}) => `<div class="grid">${list.map((g, i) => card(g, { rank: opts.rank ? i + 1 : 0 })).join('')}</div>`;
  function zone(key, title, list, opts = {}) {
    const inner = opts.html || (list.length ? grid(list, opts) : opts.empty || '');
    const count = opts.count != null ? opts.count : list.length;
    return `<details class="zone" data-zone="${key}"${closed.has(key) ? '' : ' open'}>
      <summary><span class="caret">▼</span>${title} <span class="zone-count">(${count})</span>${opts.extra || ''}</summary>
      <div class="zone-body">${inner}</div></details>`;
  }
  function empty(icon, title, text) { return `<div class="empty">${ICONS[icon]}<h3>${title}</h3><p>${text}</p></div>`; }

  function syncHeader(activeCat) {
    const f = document.getElementById('hubFilter'), c = document.getElementById('hubCat'), so = document.getElementById('hubSort');
    if (f && document.activeElement !== f) f.value = filterText;
    if (so) so.value = sort;
    if (c) c.value = activeCat && CATS.includes(activeCat) ? slug(activeCat) : '';
  }

  /* ---------- GameDistribution library ---------- */
  const GD = () => window.VexoGD;
  const libGames = () => (GD() ? GD().state.list : []);
  function libFooter() {
    const S = GD() && GD().state; if (!S) return '';
    if (S.loading) return `<p class="lib-status">Loading more games from GameDistribution…</p>`;
    if (S.error && !S.list.length) return libPaste(true);
    if (S.error) return `<p class="lib-status">Couldn't load more games right now. <button class="zone-link" data-lib-retry>Try again</button></p>` + libPaste(false);
    if (!S.done) return `<div class="lib-more-wrap"><button class="btn lib-more" data-lib-more>Load more games</button></div>`;
    return `<p class="lib-status">That's every game in the list.</p>`;
  }
  function libPaste(first) {
    const pages = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((p) => `<a href="${esc(GD().feedUrl(p))}" target="_blank" rel="noopener">${p}</a>`).join(' · ');
    return `<div class="lib-paste">
      <p><b>${first ? 'This browser blocked the automatic download of the GameDistribution game list.' : 'Add more games by hand:'}</b> You can add it in a few seconds:</p>
      <ol><li>Open a page of the list: ${pages}</li><li>On that page press <b>Ctrl+A</b>, then <b>Ctrl+C</b> to copy everything.</li><li>Come back, paste it below, and click <b>Add games</b>. Each page adds 100 games.</li></ol>
      <textarea class="input" id="libPaste" rows="3" placeholder="Paste the game list here"></textarea>
      <div class="lib-acts"><button class="btn primary" data-lib-paste>Add games</button>${first ? ' <button class="btn" data-lib-retry>Try again automatically</button>' : ''}</div></div>`;
  }
  function libraryZone() {
    if (!GD()) return '';
    const list = libGames(), S = GD().state;
    const inner = (list.length ? grid(list) : '') + libFooter();
    return zone('library', 'GameDistribution Games', list, { html: inner, count: list.length + (S.done || S.error ? '' : '+') });
  }
  function catZone(c) {
    const games = Store.games().concat(libGames());
    return zone('cat', `${esc(c)} Zones`, sorters[sort](games.filter((g) => (g.categories || []).includes(c))), { empty: empty('grid', 'No ' + esc(c) + ' games yet', 'Check back soon - new games are added all the time.') });
  }
  function swapZone(key, html) {
    const d = view.querySelector(`details[data-zone="${key}"]`); if (!d) return false;
    const t = document.createElement('div'); t.innerHTML = html.trim();
    if (t.firstElementChild) d.replaceWith(t.firstElementChild);
    watchMore();
    return true;
  }
  // load the next 100 games when "Load more" scrolls into view
  let moreObs = null;
  function watchMore() {
    if (!('IntersectionObserver' in window)) return;
    if (!moreObs) moreObs = new IntersectionObserver((es) => es.forEach((en) => { if (en.isIntersecting && GD()) GD().loadMore(); }), { rootMargin: '600px' });
    moreObs.disconnect();
    const b = view.querySelector('[data-lib-more]'); if (b) moreObs.observe(b);
  }
  document.addEventListener('vexo:gd', () => {
    if (filterText) applyFilter();
    if (!swapZone('library', libraryZone())) {
      const c = catBySlug((location.hash.match(/^#\/category\/([^/?]+)/) || [])[1]);
      if (c) swapZone('cat', catZone(c));
    }
  });

  /* ---------- pages ---------- */
  function home() {
    const games = Store.games();
    if (!games.length) return empty('grid', 'No games yet', 'Check back soon - new games are on the way.');
    let featured = games.filter((g) => g.featured);
    if (!featured.length) featured = byPopular(games).slice(0, 6);
    const recent = Store.recent().map((r) => Store.get(r.id)).filter(Boolean).slice(0, 12);
    const counts = {};
    games.forEach((g) => (g.categories || []).forEach((c) => (counts[c] = (counts[c] || 0) + 1)));
    const favs = Store.favs().map((id) => Store.get(id)).filter(Boolean);
    let h = window.VexoEvent ? window.VexoEvent.html() : '';
    h += zone('featured', 'Featured Zones', featured);
    // each section shows different games
    const shown = new Set(featured.map((g) => g.id));
    const trending = games.filter((g) => g.trending && !shown.has(g.id));
    trending.forEach((g) => shown.add(g.id));
    if (trending.length) h += zone('trending', 'Trending Now', trending);
    const popular = byPopular(games).filter((g) => !shown.has(g.id)).slice(0, 14);
    if (popular.length) h += zone('popular', 'Popular Games', popular);
    if (recent.length) h += zone('recent', 'Recently Played', recent);
    if (favs.length) h += zone('favs-home', 'Favorites', favs);
    h += zone('all', 'All Zones', sorters[sort](games));
    h += libraryZone();
    return h;
  }

  /* ---------- live filter (search box on hub) ---------- */
  function applyFilter() {
    const q = filterText.trim();
    const box = view.querySelector('#filterResults'), rest = view.querySelector('#zones');
    if (!box || !rest) return;
    if (!q) { box.innerHTML = ''; rest.hidden = false; return; }
    const res = search(q, Store.games().concat(libGames())).slice(0, 240);
    rest.hidden = true;
    // on the home screen, a search with no games just shows a button to search the web instead
    if (!res.length && document.body.classList.contains('on-home')) { box.innerHTML = `<div class="px-nogames">No games match "<b>${esc(q)}</b>". <a href="${esc(webUrl(q))}">Search the web for it</a></div>`; return; }
    box.innerHTML = zone('results', `Search results`, res, { empty: empty('search', 'No games found', `Nothing matched "<b>${esc(q)}</b>". Try another word or <a href="${esc(webUrl(q))}">search the web</a>.`) });
  }

  /* ---------- router ---------- */
  let renderedKey = null;
  function route() {
    const raw = location.hash.replace(/^#\/?/, '');
    const [pathPart] = raw.split('?');
    const parts = pathPart.split('/').map((p) => { try { return decodeURIComponent(p); } catch (e) { return p; } });

    if (parts[0] === 'play') {
      if (renderedKey == null) render('');
      openViewer(parts.slice(1).join('/'));
      return;
    }
    closeViewer();
    if (renderedKey === raw) return; // coming back from the viewer: keep scroll position
    render(raw);
  }
  function render(raw) {
    const [pathPart] = raw.split('?');
    const parts = pathPart.split('/').map((p) => { try { return decodeURIComponent(p); } catch (e) { return p; } });
    const games = Store.games();
    let body = '', active = '', title = 'VEXO-GN - Free Browser Games';
    // opening a category, favorites, recent or all games clears the search so that page shows
    if (['category', 'favorites', 'recent', 'all', 'games', 'music', 'ai', 'web', 'movies', 'me'].includes(parts[0]) && filterText) { filterText = ''; const f = document.getElementById('hubFilter'); if (f) f.value = ''; }

    if (parts[0] === 'category' && catBySlug(parts[1])) {
      const c = catBySlug(parts[1]); active = c; title = c + ' Games - VEXO-GN';
      body = catZone(c);
    } else if (parts[0] === 'search') {
      filterText = parts.slice(1).join('/');
    } else if (parts[0] === 'favorites') {
      active = 'favorites'; title = 'Favorites - VEXO-GN';
      const favs = Store.favs().map((id) => Store.get(id)).filter(Boolean);
      body = zone('favs', 'My Favorites', favs, { empty: empty('heart', 'No favorites yet', 'Tap the heart on any game to save it here. Favorites are saved on this device - no account needed.') });
    } else if (parts[0] === 'recent') {
      active = 'recent'; title = 'Recently Played - VEXO-GN';
      const rec = Store.recent().map((r) => Store.get(r.id)).filter(Boolean);
      body = zone('rec', 'Recently Played', rec, {
        extra: rec.length ? `<button class="zone-link danger" data-clear-recent>Clear history</button>` : '',
        empty: empty('clock', 'Nothing played yet', 'Start a game and it will show up here so you can jump right back in.')
      });
    } else if (parts[0] === 'all') {
      title = 'All Games - VEXO-GN';
      body = zone('all', 'All Zones', sorters[sort](games));
    } else if (parts[0] === 'games') {
      title = 'Games - VEXO-GN';
      body = `<header class="pg-head"><h1>Games</h1><span>${games.length} games</span></header>
        <nav class="pg-cats" aria-label="Categories">${CATS.map((c) => `<a class="px-chip" href="#/category/${slug(c)}">${esc(c)}</a>`).join('')}</nav>` + home();
    } else if (parts[0] === 'ai') {
      title = 'Vexo AI - VEXO-GN';
      body = window.VexoAI ? window.VexoAI.page() : '';
    } else if (parts[0] === 'web') {
      const wq = (new URLSearchParams(raw.split('?')[1] || '').get('q') || '').trim();
      title = (wq ? wq + ' - ' : '') + 'Vexo Search';
      body = window.VexoSearch ? window.VexoSearch.page(wq) : '';
    } else if (parts[0] === 'me') {
      title = 'Your progress - VEXO-GN';
      body = window.VexoXP ? window.VexoXP.page() : '';
    } else if (parts[0] === 'movies') {
      title = 'Movies - VEXO-GN';
      body = window.VexoMovies ? window.VexoMovies.page() : '';
    } else if (parts[0] === 'music') {
      title = 'Music - VEXO-GN';
      body = window.VexoMusic ? window.VexoMusic.page() : '';
    } else if (!parts[0] || parts[0] === 'search') {
      body = '<span hidden></span>'; // the start screen above is the whole home page
    }
    if (!body) body = home();
    // ad spots (hidden unless ads are set up in data.js); never on the home screen, the AI chat or inside games
    const ad = window.Vexo.adSlot || (() => '');
    if (parts[0] === 'games' || parts[0] === 'category' || parts[0] === 'all') body = body.replace('</nav>', '</nav>' + ad('games'));
    else if (parts[0] === 'music') body += ad('music');
    else if (parts[0] === 'web') body = body.replace('<div class="ws-more">', ad('search') + '<div class="ws-more">');
    if (['favorites', 'recent', 'all', 'category'].includes(parts[0])) body += ad('footer');
    document.title = title;
    // proxy-style start page: big plain title, big search bar, category buttons
    const isHome = !parts[0] || parts[0] === 'search';
    const hero = isHome ? `<section class="px-hero">${window.VexoTrailer ? `<button type="button" class="px-new" data-trailer><b>NEW</b>Watch the Vexo Movies trailer</button>` : ''}<h1 class="px-title vx-logo">vexo</h1>${window.VexoSearch ? window.VexoSearch.clock() : `<p class="px-sub">${games.length} games</p>`}${window.VexoXP ? `<div class="px-xp">${window.VexoXP.chip()}</div>` : ''}
      <div class="px-search-wrap">
        <label class="px-search">${ICONS.search}<input type="search" id="heroSearch" placeholder="Search games or the web..." autocomplete="off" spellcheck="false" aria-label="Search games or the web" role="combobox" aria-expanded="false" aria-controls="pxSuggest" aria-autocomplete="list" value="${esc(filterText)}"><button type="button" class="px-go-btn" data-search-go aria-label="Play the top result">${GO_IC}</button></label>
        <div class="px-suggest" id="pxSuggest" role="listbox" aria-label="Search suggestions" hidden></div>
      </div>
      ${dock()}${window.VexoXP ? window.VexoXP.gotdCard() : ''}</section>` : '';
    view.innerHTML = hero + '<div id="filterResults"></div><div id="zones">' + body + '</div>';
    document.body.classList.toggle('on-home', isHome);
    document.body.classList.toggle('on-music', parts[0] === 'music');
    document.body.classList.toggle('on-ai', parts[0] === 'ai');
    document.body.classList.toggle('on-web', parts[0] === 'web');
    if (parts[0] === 'ai' && window.VexoAI) window.VexoAI.mounted();
    if (parts[0] === 'movies' && window.VexoMovies) window.VexoMovies.mounted();
    if (parts[0] !== 'movies' && window.VexoMovies) window.VexoMovies.close();
    if (parts[0] === 'web' && window.VexoSearch) window.VexoSearch.mounted(new URLSearchParams(raw.split('?')[1] || '').get('q') || '');
    if (isHome && window.VexoSearch) window.VexoSearch.startClock();
    syncHeader(active);
    renderedKey = raw;
    if (window.Vexo.fillAds) window.Vexo.fillAds();
    watchMore();
    if (filterText) applyFilter();
    document.querySelectorAll('.top-btn').forEach((a) => {
      const href = a.getAttribute('href') || '';
      a.classList.toggle('active', (href.endsWith('#/') && !active && !parts[0]) || (active && href.endsWith('#/' + active)));
    });
  }

  window.VexoHub = true;

  /* ---------- shortcut dock under the search bar (with your own website shortcuts) ---------- */
  const GO_IC = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  const DK = {
    games: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 7h10a5 5 0 015 5v1a4 4 0 01-7 2.6L14 15h-4l-1 .6A4 4 0 012 13v-1a5 5 0 015-5z"/><path d="M7.5 10v4M5.5 12h4"/><circle cx="16" cy="11" r=".8" fill="currentColor"/><circle cx="18" cy="13" r=".8" fill="currentColor"/></svg>',
    music: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg>',
    movies: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/></svg>',
    edit: '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M14 6l4 4"/></svg>'
  };
  const SC_KEY = 'vexo_shortcuts';
  const DEFAULT_SC = [
    { name: 'YouTube', url: 'https://www.youtube.com/' }, { name: 'TikTok', url: 'https://www.tiktok.com/' }, { name: 'Discord', url: 'https://discord.com/app' },
    { name: 'X', url: 'https://x.com/' }, { name: 'Google', url: 'https://www.google.com/' }, { name: 'GeForce NOW', url: 'https://play.geforcenow.com/' }
  ];
  const shortcuts = () => { try { const raw = localStorage.getItem(SC_KEY); if (raw == null) return DEFAULT_SC.slice(); const v = JSON.parse(raw); return Array.isArray(v) ? v.filter((x) => x && /^https?:\/\//.test(x.url)) : []; } catch (e) { return DEFAULT_SC.slice(); } };
  const saveShortcuts = (l) => { try { localStorage.setItem(SC_KEY, JSON.stringify(l.slice(0, 14))); } catch (e) {} };
  const host = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } };
  function scIcon(sc) {
    const h = host(sc.url);
    return `<span class="dk-letter">${esc((sc.name || h || '?').trim()[0].toUpperCase())}</span><img src="https://www.google.com/s2/favicons?domain=${encodeURIComponent(h)}&sz=64" alt="" data-hide-err loading="lazy">`;
  }
  function dock() {
    const item = (tag, attrs, icon, name) => `<${tag} class="dk" ${attrs} title="${esc(name)}" aria-label="${esc(name)}">${icon}</${tag}>`;
    return `<nav class="dock" aria-label="Shortcuts">
      ${shortcuts().map((sc) => item('a', `href="${esc(sc.url)}" target="_blank" rel="noopener"`, scIcon(sc), sc.name || host(sc.url))).join('')}
      ${item('a', 'href="#/web"', SEARCH_WEB_IC, 'Vexo Search')}
      ${item('a', 'href="#/ai"', '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/><circle cx="12" cy="3.5" r="1"/></svg>', 'Vexo AI')}
      ${item('a', 'href="#/games"', DK.games, 'Games')}
      ${item('a', 'href="#/music" data-music', DK.music, 'Music')}
      ${item('a', 'href="#" data-movies', DK.movies, 'Movies')}
      ${item('button type="button"', 'data-random-game', ICONS.shuffle, 'Random game').replace('</button type="button">', '</button>')}
      <span class="dk-sep" aria-hidden="true"></span>
      ${item('button type="button"', 'data-dock-edit', DK.edit, 'Edit shortcuts').replace('</button type="button">', '</button>')}
    </nav>`;
  }
  function editShortcuts() {
    const body = () => `<div class="sc-set"><p class="sc-help">These are the website buttons under the search bar. They open in a new tab. Remove any you don't want, or add your own.</p>
      <div class="sc-list">${shortcuts().map((sc, i) => `<div class="sc-row"><span class="dk dk-static">${scIcon(sc)}</span><span class="sc-t"><b>${esc(sc.name || host(sc.url))}</b><small>${esc(host(sc.url))}</small></span><button type="button" class="sc-del" data-sc-del="${i}" aria-label="Remove ${esc(sc.name || host(sc.url))}">Remove</button></div>`).join('') || '<p class="sc-empty">No shortcuts yet.</p>'}</div>
      <div class="sc-add"><input class="input" id="scName" placeholder="Name (optional)" maxlength="24"><input class="input" id="scUrl" placeholder="Website, like google.com" inputmode="url"><button type="button" class="sc-add-btn" data-sc-add>Add</button></div></div>`;
    window.Vexo.dialog({ title: 'Shortcuts', ok: 'Done', cancel: '', body: body() }).then(() => { renderedKey = null; if (!location.hash.startsWith('#/play/')) render(location.hash.replace(/^#\/?/, '')); });
    setTimeout(() => {
      const box = document.querySelector('.vx-dialog'); if (!box) return;
      const redo = () => { box.querySelector('.sc-set').outerHTML = body(); };
      box.addEventListener('click', (e) => {
        const d = e.target.closest('[data-sc-del]');
        if (d) { const l = shortcuts(); l.splice(Number(d.dataset.scDel), 1); saveShortcuts(l); redo(); return; }
        if (e.target.closest('[data-sc-add]')) {
          let url = box.querySelector('#scUrl').value.trim(); const name = box.querySelector('#scName').value.trim();
          if (!url) { box.querySelector('#scUrl').focus(); return; }
          if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
          if (!host(url) || !/\./.test(host(url))) { toast("That doesn't look like a website. Try something like google.com"); return; }
          const l = shortcuts(); if (l.length >= 14) { toast('You can have up to 12 shortcuts.'); return; }
          l.push({ name: name.slice(0, 24), url }); saveShortcuts(l); redo(); toast('Shortcut added');
        }
      });
      box.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.target.id === 'scUrl' || e.target.id === 'scName')) { e.preventDefault(); e.stopPropagation(); box.querySelector('[data-sc-add]').click(); } }, true);
    }, 0);
  }
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-dock-edit]')) { e.preventDefault(); editShortcuts(); return; }
    if (e.target.closest('[data-random-game]')) {
      e.preventDefault();
      const list = Store.games(); if (!list.length) return;
      const g = list[Math.floor(Math.random() * list.length)];
      if (g.embed && framesBlocked) { openFullWindow(g.url); }
      else { pendingFs = autoFs(); if (renderedKey == null) render(''); openViewer(g.id); }
      location.hash = '#/play/' + encodeURIComponent(g.id);
      return;
    }
    if (e.target.closest('[data-search-go]')) {
      e.preventDefault();
      const inp = document.getElementById('heroSearch'); if (!inp) return;
      if (!inp.value.trim()) { inp.focus(); return; }
      const first = search(inp.value, Store.games())[0];
      if (!first) { saveSearch(inp.value); sgClose(); location.hash = webUrl(inp.value.trim()); return; }
      saveSearch(inp.value); sgClose();
      pendingFs = autoFs(); if (renderedKey == null) render(''); openViewer(first.id);
      location.hash = '#/play/' + encodeURIComponent(first.id);
    }
  });

  /* ---------- search dropdown: matching games with pictures, recent searches, keyboard control ---------- */
  const RECENT_KEY = 'vexo_searches';
  const recentSearches = () => { try { const v = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'); return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : []; } catch (e) { return []; } };
  const saveSearch = (q) => { q = String(q || '').trim(); if (q.length < 2) return; try { localStorage.setItem(RECENT_KEY, JSON.stringify([q].concat(recentSearches().filter((x) => x.toLowerCase() !== q.toLowerCase())).slice(0, 6))); } catch (e) {} };
  let sgActive = -1;
  const sgBox = () => document.getElementById('pxSuggest');
  const sgInput = () => document.getElementById('heroSearch');
  function mark(title, q) {
    const i = q ? title.toLowerCase().indexOf(q.toLowerCase()) : -1;
    return i < 0 ? esc(title) : esc(title.slice(0, i)) + '<mark>' + esc(title.slice(i, i + q.length)) + '</mark>' + esc(title.slice(i + q.length));
  }
  const sgItem = (g, q) => `<a class="px-sg" role="option" id="sg-${esc(g.id)}" href="#/play/${encodeURIComponent(g.id)}" data-open="${esc(g.id)}" data-sg-save>
      <img src="${esc(thumbOf(g))}" alt="" loading="lazy" data-hide-err><span class="px-sg-t"><b>${mark(g.title, q)}</b><small>${esc((g.categories || []).join(' · '))}</small></span><span class="px-sg-go" aria-hidden="true">Play ↵</span></a>`;
  function sgPaint() {
    const box = sgBox(), inp = sgInput(); if (!box || !inp) return;
    const q = inp.value.trim(); sgActive = -1;
    let html = '';
    if (q) {
      const res = search(q, Store.games());
      const web = `<a class="px-sg px-sg-web" role="option" id="sg-vexo" href="${esc(webUrl(q))}" data-sg-save>${SEARCH_WEB_IC}<span class="px-sg-t"><b>Search the web for "${esc(q)}"</b><small>Results show right here in Vexo</small></span><span class="px-sg-go" aria-hidden="true">Search ↵</span></a>` + `<a class="px-sg px-sg-web" role="option" id="sg-web" href="${esc(googleUrl(q))}" target="_blank" rel="noopener" data-sg-save><svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.6 12.2c0-.7-.1-1.4-.2-2H12v3.8h5.4a4.6 4.6 0 01-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3z"/><path fill="#34A853" d="M12 22c2.7 0 5-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.8-5.6-4.1H3.1v2.6A10 10 0 0012 22z"/><path fill="#FBBC05" d="M6.4 14a6 6 0 010-3.9V7.5H3.1a10 10 0 000 9z"/><path fill="#EA4335" d="M12 5.9c1.5 0 2.8.5 3.8 1.5l2.8-2.8A10 10 0 003.1 7.5l3.3 2.6C7.2 7.7 9.4 5.9 12 5.9z"/></svg><span class="px-sg-t"><b>Search on Google instead</b><small>Opens Google in a new tab</small></span><span class="px-sg-go" aria-hidden="true">↗</span></a>`;
      html = res.length
        ? `<div class="px-sg-head">${res.length} game${res.length === 1 ? '' : 's'} found</div>` + res.slice(0, 6).map((g) => sgItem(g, q)).join('') + (res.length > 6 ? `<button type="button" class="px-sg-all" data-sg-all>See all ${res.length} results</button>` : '') + `<div class="px-sg-head">The web</div>` + web
        : `<div class="px-sg-head">No games match "${esc(q)}"</div>` + web;
    } else {
      const rec = recentSearches();
      if (rec.length) html += `<div class="px-sg-head">Recent searches <button type="button" class="px-sg-clear" data-sg-clear>Clear</button></div><div class="px-sg-chips">${rec.map((r) => `<button type="button" class="px-sg-chip" data-sg-q="${esc(r)}">${esc(r)}</button>`).join('')}</div>`;
      html += `<div class="px-sg-head">Popular games</div>` + byPopular(Store.games()).slice(0, 5).map((g) => sgItem(g, '')).join('');
    }
    box.innerHTML = html;
    box.hidden = false; inp.setAttribute('aria-expanded', 'true'); inp.removeAttribute('aria-activedescendant');
  }
  const googleUrl = (q) => 'https://www.google.com/search?q=' + encodeURIComponent(q);
  const webUrl = (q) => '#/web?q=' + encodeURIComponent(q);
  const SEARCH_WEB_IC = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/></svg>';
  function sgClose() { const box = sgBox(), inp = sgInput(); if (box) box.hidden = true; if (inp) { inp.setAttribute('aria-expanded', 'false'); inp.removeAttribute('aria-activedescendant'); } sgActive = -1; }
  function sgMove(d) {
    const items = [...(sgBox() ? sgBox().querySelectorAll('.px-sg') : [])]; if (!items.length) return;
    sgActive = (sgActive + d + items.length) % items.length;
    items.forEach((el, i) => el.classList.toggle('on', i === sgActive));
    items[sgActive].scrollIntoView({ block: 'nearest' });
    sgInput().setAttribute('aria-activedescendant', items[sgActive].id);
  }
  document.addEventListener('focusin', (e) => { if (e.target.id === 'heroSearch') sgPaint(); });
  document.addEventListener('input', (e) => { if (e.target.id === 'heroSearch') sgPaint(); });
  document.addEventListener('keydown', (e) => {
    if (e.target.id !== 'heroSearch') return;
    if (e.key === 'ArrowDown') { e.preventDefault(); if (sgBox().hidden) sgPaint(); sgMove(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); sgMove(-1); }
    else if (e.key === 'Escape') { if (!sgBox().hidden) { e.preventDefault(); e.stopPropagation(); sgClose(); } }
    else if (e.key === 'Enter') {
      e.preventDefault();
      const items = [...sgBox().querySelectorAll('.px-sg')];
      const pick = items[sgActive >= 0 ? sgActive : 0];
      if (pick && e.target.value.trim()) pick.click(); // opens the game (full screen) right away
      else if (pick && sgActive >= 0) pick.click();
    }
  }, true);
  document.addEventListener('mousedown', (e) => { if (sgBox() && !sgBox().hidden && !e.target.closest('.px-search-wrap')) sgClose(); });
  document.addEventListener('focusout', (e) => { if (e.target.id === 'heroSearch') setTimeout(() => { const a = document.activeElement; if (!a || !a.closest || !a.closest('.px-search-wrap')) sgClose(); }, 120); });
  document.addEventListener('click', (e) => {
    const sv = e.target.closest('[data-sg-save]'); if (sv) { saveSearch(sgInput() && sgInput().value); sgClose(); return; }
    const chip = e.target.closest('[data-sg-q]');
    if (chip) { const inp = sgInput(); inp.value = chip.dataset.sgQ; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.focus(); return; }
    if (e.target.closest('[data-sg-clear]')) { try { localStorage.removeItem(RECENT_KEY); } catch (x) {} sgPaint(); sgInput().focus(); return; }
    if (e.target.closest('[data-sg-all]')) { saveSearch(sgInput().value); sgClose(); const r = document.getElementById('filterResults'); if (r) r.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  });
  document.addEventListener('click', (e) => {
    const logo = e.target.closest('a[data-home]'); if (!logo || e.ctrlKey || e.metaKey || e.shiftKey) return;
    e.preventDefault();
    filterText = '';
    ['hubFilter', 'heroSearch'].forEach((id) => { const f = document.getElementById(id); if (f) f.value = ''; });
    closeViewer();
    if (location.hash === '#/' || location.hash === '') { renderedKey = null; route(); } else location.hash = '#/';
    window.scrollTo(0, 0);
  });
  document.addEventListener('input', (e) => {
    if (e.target.id === 'hubFilter' || e.target.id === 'heroSearch') {
      filterText = e.target.value;
      const other = document.getElementById(e.target.id === 'hubFilter' ? 'heroSearch' : 'hubFilter'); if (other) other.value = filterText;
      if (location.hash.startsWith('#/play/')) return;
      applyFilter();
      if (e.target.id === 'hubFilter') window.scrollTo(0, 0);
    }
  });
  document.addEventListener('change', (e) => {
    if (e.target.id === 'hubSort') { sort = e.target.value; setPref('vexo_sort', sort); const k = renderedKey; renderedKey = null; render(k || ''); }
  });
  document.addEventListener('vexo:refresh', () => { const k = renderedKey; renderedKey = null; if (!location.hash.startsWith('#/play/')) render(k || ''); });
  view.addEventListener('toggle', (e) => {
    const d = e.target; if (!d.matches || !d.matches('details.zone')) return;
    d.open ? closed.delete(d.dataset.zone) : closed.add(d.dataset.zone);
    setPref('vexo_closed', JSON.stringify([...closed]));
  }, true);
  view.addEventListener('click', (e) => {
    if (e.target.closest('[data-lib-more]')) { e.preventDefault(); GD() && GD().loadMore(); return; }
    if (e.target.closest('[data-lib-retry]')) { e.preventDefault(); if (GD()) { GD().state.error = ''; GD().loadMore(); } return; }
    if (e.target.closest('[data-lib-paste]')) {
      e.preventDefault();
      const ta = view.querySelector('#libPaste'), text = ta ? ta.value : '';
      let r = { found: 0, added: 0 };
      try { r = GD().importText(text); } catch (x) { r = { found: 0, added: 0 }; }
      if (!r.found) toast("That didn't look like the game list. Copy the whole page and try again.");
      else toast(r.added ? `Added ${r.added} games` : 'Those games were already added');
      return;
    }
    if (e.target.closest('[data-clear-recent]')) {
      e.preventDefault();
      window.Vexo.ask('Clear history?', 'This clears your recently played list on this device.', 'Clear history').then((ok) => { if (ok) { Store.clearRecent(); toast('Recently played cleared'); renderedKey = null; route(); } });
      return;
    }
    if (e.target.closest('summary .zone-link')) e.stopPropagation();
  });
  // open games in the in-page viewer (gn-style) instead of leaving the page
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-open]');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
    if (!view.contains(a) && !a.closest('.suggest')) return;
    e.preventDefault();
    const g = Store.get(a.dataset.open);
    if (g && g.embed && framesBlocked) { Store.pushRecent(g.id); Store.addPlay(g.id); openFullWindow(g.url); }
    else { pendingFs = autoFs(); if (g) { if (renderedKey == null) render(''); openViewer(g.id); } }
    location.hash = '#/play/' + encodeURIComponent(a.dataset.open);
  });
  document.addEventListener('vexo:favs', () => {
    if (location.hash.startsWith('#/favorites')) { renderedKey = null; render('favorites'); }
    syncViewerFav();
  });

  /* ---------- in-page game viewer ---------- */
  const viewer = document.createElement('div');
  viewer.className = 'viewer'; viewer.hidden = true;
  viewer.setAttribute('role', 'dialog'); viewer.setAttribute('aria-modal', 'true'); viewer.setAttribute('aria-label', 'Game player');
  document.body.appendChild(viewer);
  let current = null, frame = null, pendingFs = false;
  // Check once whether this page may show games from other sites (preview pages often block it).
  let framesBlocked = false;
  (function probeFrames() {
    const onV = (e) => {
      const d = String(e.effectiveDirective || e.violatedDirective || '');
      if (/^(frame-src|child-src|default-src)/.test(d) && /gamedistribution/.test(String(e.blockedURI || ''))) framesBlocked = true;
    };
    document.addEventListener('securitypolicyviolation', onV);
    const f = document.createElement('iframe');
    f.setAttribute('aria-hidden', 'true'); f.tabIndex = -1;
    f.style.cssText = 'position:absolute;left:-9px;top:-9px;width:1px;height:1px;border:0;opacity:0;pointer-events:none';
    f.src = 'https://html5.gamedistribution.com/robots.txt';
    document.body.appendChild(f);
    setTimeout(() => { f.remove(); document.removeEventListener('securitypolicyviolation', onV); }, 3000);
  })();
  const gameSrc = (g) => (/gamedistribution\.com/.test(g.url) ? g.url + (g.url.includes('?') ? '&' : '?') + 'gd_sdk_referrer_url=' + encodeURIComponent(location.href.split('#')[0]) : g.url);
  // games built into the site run from their own code; everything else loads its web address
  function loadGame(f, g) {
    const code = g.builtin && window.VEXO_BUILTIN && window.VEXO_BUILTIN[g.id];
    if (code) { f.removeAttribute('src'); f.srcdoc = code; } else { f.removeAttribute('srcdoc'); f.src = safeUrl(gameSrc(g)); }
  }
  const safeUrl = (u) => (/^\s*(javascript|data|vbscript):/i.test(u || '') ? 'about:blank' : u);
  const isExternal = (u) => { try { const x = new URL(u, location.href); return /^https?:$/.test(x.protocol) && x.origin !== location.origin; } catch (e) { return false; } };

  function openViewer(id) {
    const g = Store.get(id);
    if (!g) { toast('That game could not be found'); location.hash = '#/'; return; }
    if (current === id && !viewer.hidden) return;
    current = id;
    // games only play inside a site that has a real web address; opened as a file, show the launch screen instead
    const notOnline = !/^https?:$/.test(location.protocol);
    if (g.external || (g.embed && (framesBlocked || notOnline))) {
      // launch screen (proxy style) when the game can't play inside this page
      const cats = (g.categories || []).join(' · ');
      viewer.innerHTML = `<div class="px-launch">
        <button type="button" class="px-launch-x" data-v="close" title="Close" aria-label="Close game">${ICONS.x}</button>
        <div class="px-launch-box">
          <img class="px-launch-img" src="${esc(thumbOf(g))}" alt="" data-hide-err>
          ${cats ? `<p class="px-launch-cat">${esc(cats)}</p>` : ''}
          <h2 class="px-launch-title">${esc(g.title)}</h2>
          ${g.description ? `<p class="px-launch-desc">${esc(g.description)}</p>` : ''}
          <div class="px-launch-acts">
            <a class="px-go" href="${esc(g.url)}" target="_blank" rel="noopener" data-ext="${esc(g.id)}">${ICONS.play}<span>Play</span></a>
            <button type="button" class="px-ghost${Store.isFav(g.id) ? ' on' : ''}" data-fav="${esc(g.id)}">${ICONS.heart}<span>Favorite</span></button>
          </div>
          ${g.controls && !/^Opens/.test(g.controls) ? `<p class="px-launch-ctl"><span>Controls</span>${esc(g.controls)}</p>` : ''}
          <p class="px-launch-note">${notOnline ? 'Games play right inside VEXO-GN once your site is online (like on GitHub). For now, Play opens the game in a new window.' : 'Opens full screen in a new window.'}</p>
        </div></div>`;
      viewer.hidden = false; document.body.classList.add('viewing'); frame = null;
      return;
    }
    const [aw, ah] = String(g.aspect || '16:9').split(':').map(Number);
    const ar = aw && ah ? aw / ah : 16 / 9;
    viewer.innerHTML = `
      <div class="viewer-bar">
        <img src="${esc(thumbOf(g))}" alt="" data-fallback="${esc(autoThumb(g.title, (g.categories || [])[0], g.icon))}">
        <div class="vt"><b>${esc(g.title)}</b><small>${esc((g.categories || []).join(' · '))}</small></div>
        <div class="acts">
          <button class="btn${Store.isFav(g.id) ? ' on' : ''}" data-fav="${esc(g.id)}" title="Favorite">${ICONS.heart}<span class="lbl">Favorite</span></button>
          <button class="btn" data-v="restart" title="Restart">${ICONS.refresh}<span class="lbl">Restart</span></button>
          <button class="btn" data-v="info" title="About this game">${ICONS.star}<span class="lbl">Info</span></button>
          ${g.embed && g.source ? `<a class="btn" href="${esc(g.source)}" target="_blank" rel="noopener" data-ext="${esc(g.id)}" title="If the game does not load here, open it in its own window">${ICONS.link}<span class="lbl">New window</span></a>` : `<a class="btn" href="play.html?id=${encodeURIComponent(g.id)}" title="Open the game page (shareable link)">${ICONS.link}<span class="lbl">Game page</span></a>`}
          <button class="btn primary" data-v="fs" title="Fullscreen (F)">${ICONS.expand}<span class="lbl">Fullscreen</span></button>
          <button class="icon-btn close" data-v="close" title="Close game" aria-label="Close game">${ICONS.x}</button>
        </div>
      </div>
      <div class="viewer-stage"><div class="viewer-frame" style="--ar:${ar}"></div>${g.source ? `<a class="max-newwin" href="${esc(g.source)}" target="_blank" rel="noopener" data-ext="${esc(g.id)}" title="Game not loading? Open it in its own window">${ICONS.link}<span>New window</span></a>` : ''}<button class="max-exit" data-v="close" title="Close game" aria-label="Close game">${ICONS.x}</button></div>
      <div class="viewer-info" hidden><p><b>${esc(g.title)}</b> - ${esc(g.description || '')}</p><p class="ctl">${ICONS.Arcade}<span>${esc(g.controls || 'Click the game, then follow the on-screen instructions.')}</span></p>${credit(g) ? `<p class="credit">${credit(g)}</p>` : ''}</div>`;
    frame = document.createElement('iframe');
    frame.title = g.title;
    frame.setAttribute('allow', 'fullscreen; autoplay; gamepad; pointer-lock');
    frame.setAttribute('allowfullscreen', '');
    if (isExternal(g.url) && !g.embed) frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-pointer-lock allow-forms allow-modals allow-orientation-lock allow-popups');
    viewer.querySelector('.viewer-frame').appendChild(frame);
    showLoading(g);
    frame.addEventListener('load', () => { if (frame && frame.src !== 'about:blank') hideLoading(); try { frame.focus(); } catch (e) {} });
    // a full-screen ad can play first (only when ads are set up); the game loads as soon as it's done
    const fr = frame;
    if (window.Vexo.adBeforeGame) window.Vexo.adBeforeGame('start-' + g.id, () => { if (frame === fr) loadGame(fr, g); });
    else loadGame(frame, g);
    viewer.hidden = false;
    document.body.classList.add('viewing');
    document.title = g.title + ' - VEXO-GN';
    Store.pushRecent(g.id); Store.addPlay(g.id);
    setTimeout(() => frame && frame.focus(), 60);
    if (pendingFs) toggleFs();
    pendingFs = false;
  }
  // if this page is not allowed to load outside games (for example a preview page), say so instead of showing a blank box
  function frameBlocked() {
    const g = current && Store.get(current), box = viewer.querySelector('.viewer-frame');
    if (!g || !box || box.querySelector('.frame-note')) return;
    const href = g.source || g.url;
    box.insertAdjacentHTML('beforeend', `<div class="frame-note"><h3>This page can't load ${esc(g.title)}</h3>
      <p>The page you're viewing blocks games from other sites. On your own VEXO-GN site (for example GitHub Pages) it plays right here.</p>
      <a class="btn primary big" href="${esc(href)}" target="_blank" rel="noopener" data-ext="${esc(g.id)}">${ICONS.play}Play on ${esc(g.author || 'its site')}</a></div>`);
  }
  document.addEventListener('securitypolicyviolation', (e) => {
    if (!frame || viewer.hidden) return;
    const d = String(e.effectiveDirective || e.violatedDirective || '');
    if (/^(frame-src|child-src|default-src)/.test(d)) frameBlocked();
  });
  let slowTimer = 0;
  function showLoading(g) {
    const box = viewer.querySelector('.viewer-frame'); if (!box) return;
    let ld = box.querySelector('.ld');
    if (!ld) { ld = document.createElement('div'); ld.className = 'ld'; box.appendChild(ld); }
    ld.classList.remove('done', 'slow');
    ld.innerHTML = `<div class="ld-in"><div class="ld-spin" aria-hidden="true"></div><b>Loading ${esc(g.title)}</b><small class="ld-msg">Big games can take a few seconds.</small>
      <div class="ld-acts"><button type="button" class="ld-btn" data-v="retry">Try again</button>${g.source || g.url ? `<a class="ld-btn ld-main" href="${esc(g.source || g.url)}" target="_blank" rel="noopener" data-ext="${esc(g.id)}">Open in new window</a>` : ''}</div></div>`;
    ld.setAttribute('role', 'status');
    clearTimeout(slowTimer);
    slowTimer = setTimeout(() => {
      if (!ld.isConnected || ld.classList.contains('done')) return;
      ld.classList.add('slow');
      ld.querySelector('.ld-msg').textContent = 'This is taking longer than usual. The network might be blocking it.';
    }, 10000);
  }
  function hideLoading() {
    clearTimeout(slowTimer);
    const ld = viewer.querySelector('.viewer-frame .ld'); if (!ld) return;
    ld.classList.add('done'); setTimeout(() => { if (ld.classList.contains('done')) ld.remove(); }, 350);
  }
  function closeViewer() {
    clearTimeout(slowTimer);
    if (viewer.hidden) return;
    const ex = document.exitFullscreen || document.webkitExitFullscreen;
    if ((document.fullscreenElement || document.webkitFullscreenElement) && ex) { try { const r = ex.call(document); if (r && r.catch) r.catch(() => {}); } catch (e) {} }
    viewer.hidden = true; viewer.innerHTML = ''; viewer.classList.remove('max'); frame = null; current = null;
    document.body.classList.remove('viewing');
    renderedKey = null; // refresh lists (recently played changed)
  }
  function syncViewerFav() {
    const b = viewer.querySelector('[data-fav]'); if (b && current) b.classList.toggle('on', Store.isFav(current));
  }
  function toggleFs() {
    const el = viewer.querySelector('.viewer-stage');
    if (viewer.classList.contains('max')) { viewer.classList.remove('max'); return; }
    if (document.fullscreenElement || document.webkitFullscreenElement) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); return; }
    const req = el.requestFullscreen || el.webkitRequestFullscreen;
    if (!req) viewer.classList.toggle('max');
    else { try { const p = req.call(el); if (p && p.catch) p.catch(() => viewer.classList.add('max')); } catch (x) { viewer.classList.add('max'); } }
    setTimeout(() => frame && frame.focus(), 150);
  }
  viewer.addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    const v = b.dataset.v;
    if (v === 'close') goBack();
    if (v === 'restart' && frame) { const g = Store.get(current); frame.src = 'about:blank'; showLoading(g); setTimeout(() => loadGame(frame, g), 30); toast('Game restarted'); }
    if (v === 'retry' && frame) { const g = Store.get(current); frame.src = 'about:blank'; showLoading(g); setTimeout(() => loadGame(frame, g), 60); }
    if (v === 'info') { const i = viewer.querySelector('.viewer-info'); i.hidden = !i.hidden; b.classList.toggle('on', !i.hidden); }
    if (v === 'fs') toggleFs();
  });
  // remember the page you came from, so closing the game takes you back there
  let backTo = '#/';
  window.addEventListener('hashchange', (e) => {
    const from = (e.oldURL || '').split('#')[1] || '';
    if (location.hash.startsWith('#/play/') && !from.startsWith('/play/')) backTo = '#' + (from || '/');
  }, true);
  function goBack() {
    closeViewer();
    if (location.hash.startsWith('#/play/')) location.hash = backTo;
    else route();
  }
  document.addEventListener('keydown', (e) => {
    if (viewer.hidden || /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return;
    if (e.key === 'Escape' && !document.fullscreenElement) { e.preventDefault(); if (viewer.classList.contains('max')) viewer.classList.remove('max'); else goBack(); }
    if (e.key === 'f' || e.key === 'F') { e.preventDefault(); toggleFs(); }
  });

  shell('home');
  window.addEventListener('hashchange', route);
  route();
})();
